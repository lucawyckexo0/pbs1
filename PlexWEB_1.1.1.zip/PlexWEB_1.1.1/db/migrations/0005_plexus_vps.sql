-- Plexus VPS provisioning: machine id per order, and the Plexus account id per customer (server-only).
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS plexus_machine_id text;
CREATE INDEX IF NOT EXISTS orders_plexus_machine_idx ON public.orders (plexus_machine_id) WHERE plexus_machine_id IS NOT NULL;
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS public.plexus_accounts (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  account_id integer NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);
--> statement-breakpoint
REVOKE ALL ON public.plexus_accounts FROM anon, authenticated;
GRANT ALL ON public.plexus_accounts TO service_role;
ALTER TABLE public.plexus_accounts ENABLE ROW LEVEL SECURITY;
