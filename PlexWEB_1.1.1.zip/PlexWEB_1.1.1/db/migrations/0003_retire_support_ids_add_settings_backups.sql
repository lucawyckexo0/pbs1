-- Support IDs are retired. Alerts keep an internal random key only so the existing unique column stays valid.
CREATE OR REPLACE FUNCTION public.random_alert_key() RETURNS text
LANGUAGE sql VOLATILE SET search_path = public
AS $$
  SELECT string_agg(substr('ABCDEFGHJKLMNPQRSTUVWXYZ23456789', 1 + floor(random() * 32)::int, 1), '')
  FROM generate_series(1, 6);
$$;
REVOKE ALL ON FUNCTION public.random_alert_key() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.random_alert_key() TO service_role;

ALTER TABLE public.panel_alerts ALTER COLUMN support_id SET DEFAULT public.random_alert_key();
COMMENT ON COLUMN public.panel_alerts.support_id IS 'DEPRECATED: Support IDs are no longer shown to anyone; internal random key only.';
COMMENT ON FUNCTION public.record_panel_alert(text, text, uuid, uuid, text, text, integer, text, text, text) IS 'DEPRECATED: replaced by record_panel_alert_v2';

-- One open alert per order and action: repeats bump the count. Returns the alert id.
CREATE OR REPLACE FUNCTION public.record_panel_alert_v2(
  _action text, _order_id uuid, _user_id uuid, _user_email text, _product text,
  _http_status integer, _panel_code text, _panel_detail text, _raw text
) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE aid uuid;
BEGIN
  IF _order_id IS NOT NULL THEN
    UPDATE public.panel_alerts
      SET count = count + 1, last_seen_at = now(), http_status = _http_status, panel_code = _panel_code, panel_detail = _panel_detail, raw = _raw
      WHERE order_id = _order_id AND action = _action AND status = 'open'
      RETURNING id INTO aid;
    IF aid IS NOT NULL THEN RETURN aid; END IF;
  END IF;
  FOR i IN 1..5 LOOP
    BEGIN
      INSERT INTO public.panel_alerts (action, order_id, user_id, user_email, product, http_status, panel_code, panel_detail, raw)
        VALUES (_action, _order_id, _user_id, _user_email, _product, _http_status, _panel_code, _panel_detail, _raw)
        ON CONFLICT (order_id, action) WHERE status = 'open'
        DO UPDATE SET count = public.panel_alerts.count + 1, last_seen_at = now()
        RETURNING id INTO aid;
      RETURN aid;
    EXCEPTION WHEN unique_violation THEN
      -- The internal random key collided; try again with a fresh one.
      NULL;
    END;
  END LOOP;
  RAISE EXCEPTION 'could not record panel alert';
END;
$$;
REVOKE ALL ON FUNCTION public.record_panel_alert_v2(text, uuid, uuid, text, text, integer, text, text, text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.record_panel_alert_v2(text, uuid, uuid, text, text, integer, text, text, text) TO service_role;

-- The automated dependency update runner was removed; history is kept read-only.
COMMENT ON TABLE public.stack_update_runs IS 'DEPRECATED: automated dependency updates were removed; kept for history only.';

-- ========== Settings backups (site + panel settings, newest 3 kept) ==========
CREATE TABLE public.settings_backups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid,
  reason text NOT NULL CHECK (reason IN ('manual', 'before_restore')),
  site jsonb NOT NULL,
  panel jsonb NOT NULL
);
CREATE INDEX settings_backups_created_idx ON public.settings_backups (created_at DESC);
GRANT SELECT ON public.settings_backups TO authenticated;
GRANT ALL ON public.settings_backups TO service_role;
ALTER TABLE public.settings_backups ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins read settings backups" ON public.settings_backups FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));

-- Copies the live settings into a backup and keeps only the newest 3.
CREATE OR REPLACE FUNCTION public.create_settings_backup(_by uuid, _reason text) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE bid uuid;
BEGIN
  PERFORM pg_advisory_xact_lock(hashtext('settings_backups'));
  INSERT INTO public.settings_backups (created_by, reason, site, panel)
    VALUES (
      _by, _reason,
      coalesce((SELECT data FROM public.site_settings WHERE id = 1), '{}'::jsonb),
      coalesce((SELECT data FROM public.panel_settings WHERE id = 1), '{}'::jsonb)
    )
    RETURNING id INTO bid;
  DELETE FROM public.settings_backups
    WHERE id NOT IN (SELECT id FROM public.settings_backups ORDER BY created_at DESC, id DESC LIMIT 3);
  RETURN bid;
END;
$$;
REVOKE ALL ON FUNCTION public.create_settings_backup(uuid, text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.create_settings_backup(uuid, text) TO service_role;

-- Restores a backup in one step. The current settings are backed up first, and maintenance mode stays as it is now.
CREATE OR REPLACE FUNCTION public.restore_settings_backup(_id uuid, _by uuid) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE b public.settings_backups; safety uuid; cur_maint jsonb;
BEGIN
  PERFORM pg_advisory_xact_lock(hashtext('settings_backups'));
  SELECT * INTO b FROM public.settings_backups WHERE id = _id;
  IF NOT FOUND THEN RAISE EXCEPTION 'backup not found' USING ERRCODE = 'P0002'; END IF;
  INSERT INTO public.settings_backups (created_by, reason, site, panel)
    VALUES (
      _by, 'before_restore',
      coalesce((SELECT data FROM public.site_settings WHERE id = 1), '{}'::jsonb),
      coalesce((SELECT data FROM public.panel_settings WHERE id = 1), '{}'::jsonb)
    )
    RETURNING id INTO safety;
  SELECT data->'maintenance' INTO cur_maint FROM public.site_settings WHERE id = 1 FOR UPDATE;
  UPDATE public.site_settings
     SET data = CASE WHEN cur_maint IS NULL THEN b.site ELSE b.site || jsonb_build_object('maintenance', cur_maint) END,
         updated_at = now()
   WHERE id = 1;
  UPDATE public.panel_settings SET data = b.panel, updated_at = now() WHERE id = 1;
  DELETE FROM public.settings_backups
    WHERE id NOT IN (SELECT id FROM public.settings_backups ORDER BY created_at DESC, id DESC LIMIT 3);
  RETURN safety;
END;
$$;
REVOKE ALL ON FUNCTION public.restore_settings_backup(uuid, uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.restore_settings_backup(uuid, uuid) TO service_role;
