-- ========== Admin access granted by verified email ==========
-- Server only: nobody reads this list from the app.
CREATE TABLE public.admin_email_grants (
  email text PRIMARY KEY CHECK (email = lower(email) AND length(email) BETWEEN 3 AND 254),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.admin_email_grants TO service_role;
ALTER TABLE public.admin_email_grants ENABLE ROW LEVEL SECURITY;

-- Grants the admin role once the account's email is confirmed (Google accounts are confirmed at sign-up).
CREATE OR REPLACE FUNCTION public.grant_admin_by_email()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF NEW.email IS NOT NULL AND NEW.email_confirmed_at IS NOT NULL
     AND EXISTS (SELECT 1 FROM public.admin_email_grants g WHERE g.email = lower(NEW.email)) THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'admin')
    ON CONFLICT (user_id, role) DO NOTHING;
  END IF;
  RETURN NEW;
END;
$$;
REVOKE ALL ON FUNCTION public.grant_admin_by_email() FROM PUBLIC, anon, authenticated;

CREATE TRIGGER on_auth_user_admin_grant_insert AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.grant_admin_by_email();
CREATE TRIGGER on_auth_user_admin_grant_confirm AFTER UPDATE OF email_confirmed_at, email ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.grant_admin_by_email();

-- When a grant is added for an account that already exists and is confirmed, apply it right away.
CREATE OR REPLACE FUNCTION public.apply_admin_email_grant()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, auth
AS $$
BEGIN
  INSERT INTO public.user_roles (user_id, role)
  SELECT u.id, 'admin' FROM auth.users u
  WHERE lower(u.email) = NEW.email AND u.email_confirmed_at IS NOT NULL
  ON CONFLICT (user_id, role) DO NOTHING;
  RETURN NEW;
END;
$$;
REVOKE ALL ON FUNCTION public.apply_admin_email_grant() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER on_admin_email_grant_added AFTER INSERT ON public.admin_email_grants
  FOR EACH ROW EXECUTE FUNCTION public.apply_admin_email_grant();

-- ========== Dependency update runs (admin Updates tab) ==========
CREATE TABLE public.stack_update_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid,
  packages jsonb NOT NULL DEFAULT '[]'::jsonb,
  status text NOT NULL DEFAULT 'running' CHECK (status IN ('running', 'succeeded', 'failed', 'timed_out', 'cancelled')),
  finished_at timestamptz,
  message text CHECK (message IS NULL OR length(message) <= 2000),
  run_url text CHECK (run_url IS NULL OR length(run_url) <= 500),
  maintenance_was_on boolean NOT NULL DEFAULT false
);
GRANT SELECT ON public.stack_update_runs TO authenticated;
GRANT ALL ON public.stack_update_runs TO service_role;
ALTER TABLE public.stack_update_runs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins read update runs" ON public.stack_update_runs FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));
-- Only one update may run at a time.
CREATE UNIQUE INDEX stack_update_runs_one_running ON public.stack_update_runs ((true)) WHERE status = 'running';
CREATE INDEX stack_update_runs_created_at ON public.stack_update_runs (created_at DESC);
