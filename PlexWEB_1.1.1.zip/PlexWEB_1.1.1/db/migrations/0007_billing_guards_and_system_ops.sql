-- Billing guards: renewals, late payments and top-ups are settled in single locked steps.

-- Records a renewal payment and extends the service in one transaction.
-- Returns 'extended_active', 'extended_suspended', 'review' (money kept, refund queued) or 'noop' (already applied).
CREATE OR REPLACE FUNCTION public.apply_renewal(_order_id uuid, _payment_id text)
RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE r public.orders%ROWTYPE; p public.orders%ROWTYPE; m integer;
BEGIN
  IF _payment_id IS NULL OR _payment_id !~ '^(pay_[A-Za-z0-9]{6,40}|credits_[0-9a-f-]{36})$' THEN RAISE EXCEPTION 'renewal_payment_invalid'; END IF;
  SELECT * INTO r FROM public.orders WHERE id = _order_id FOR UPDATE;
  IF NOT FOUND OR r.kind <> 'renewal' OR r.status NOT IN ('pending', 'failed') OR r.razorpay_payment_id IS NOT NULL THEN RETURN 'noop'; END IF;
  m := CASE r.billing WHEN 'monthly' THEN 1 WHEN 'quarterly' THEN 3 WHEN 'semiannual' THEN 6 WHEN 'yearly' THEN 12 END;
  IF r.parent_order_id IS NOT NULL THEN SELECT * INTO p FROM public.orders WHERE id = r.parent_order_id FOR UPDATE; END IF;
  UPDATE public.orders SET status = 'renewed', razorpay_payment_id = _payment_id, paid_at = now() WHERE id = r.id;
  IF m IS NULL OR p.id IS NULL OR p.kind <> 'new' OR p.user_id <> r.user_id OR p.status NOT IN ('active', 'suspended')
     OR p.plan_id <> r.plan_id OR p.billing <> r.billing THEN
    INSERT INTO public.refunds (order_id, user_id, reason, status)
      VALUES (r.id, r.user_id, 'Renewal paid after the service changed or closed. Needs administrator review.', 'requested')
      ON CONFLICT (order_id) DO NOTHING;
    RETURN 'review';
  END IF;
  UPDATE public.orders SET renews_at = greatest(coalesce(renews_at, now()), now()) + make_interval(months => m) WHERE id = p.id;
  RETURN 'extended_' || p.status;
END;
$$;
REVOKE ALL ON FUNCTION public.apply_renewal(uuid, text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.apply_renewal(uuid, text) TO service_role;
--> statement-breakpoint

-- Accepts a payment that arrived after a new order's checkout was closed.
-- A coupon is re-checked under lock, so expired checkouts cannot be used to dodge use limits.
-- Returns 'revived', 'review' (money kept, refund queued) or 'noop'.
CREATE OR REPLACE FUNCTION public.revive_paid_order(_order_id uuid, _payment_id text, _renews_at timestamptz)
RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE o public.orders%ROWTYPE; c public.coupons%ROWTYPE; used integer; mine integer;
BEGIN
  IF _payment_id IS NULL OR _payment_id !~ '^pay_[A-Za-z0-9]{6,40}$' THEN RAISE EXCEPTION 'revive_payment_invalid'; END IF;
  SELECT * INTO o FROM public.orders WHERE id = _order_id FOR UPDATE;
  IF NOT FOUND OR o.kind <> 'new' OR o.status <> 'failed' OR o.razorpay_payment_id IS NOT NULL THEN RETURN 'noop'; END IF;
  IF o.coupon_id IS NOT NULL THEN
    SELECT * INTO c FROM public.coupons WHERE id = o.coupon_id FOR UPDATE;
    SELECT count(*) INTO used FROM public.orders WHERE coupon_id = o.coupon_id AND status <> 'failed' AND id <> o.id;
    SELECT count(*) INTO mine FROM public.orders WHERE coupon_id = o.coupon_id AND user_id = o.user_id AND status <> 'failed' AND id <> o.id;
    IF c.id IS NULL OR NOT c.active OR (c.max_uses IS NOT NULL AND used >= c.max_uses) OR mine >= c.per_user_limit THEN
      UPDATE public.orders SET razorpay_payment_id = _payment_id, paid_at = now() WHERE id = o.id;
      INSERT INTO public.refunds (order_id, user_id, reason, status)
        VALUES (o.id, o.user_id, 'Paid after the checkout expired and the coupon is no longer available. Needs administrator review.', 'requested')
        ON CONFLICT (order_id) DO NOTHING;
      RETURN 'review';
    END IF;
  END IF;
  UPDATE public.orders SET status = 'provisioning', razorpay_payment_id = _payment_id, paid_at = now(), renews_at = _renews_at WHERE id = o.id;
  RETURN 'revived';
END;
$$;
REVOKE ALL ON FUNCTION public.revive_paid_order(uuid, text, timestamptz) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.revive_paid_order(uuid, text, timestamptz) TO service_role;
--> statement-breakpoint

-- Opens a top-up checkout under a per-customer lock. Every unpaid top-up counts towards the balance limit.
CREATE OR REPLACE FUNCTION public.create_topup_order(_user_id uuid, _amount integer, _max_balance integer, _max_open integer)
RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE bal integer; open_n integer; reserved integer; new_id uuid;
BEGIN
  IF _amount IS NULL OR _amount <= 0 OR _amount > 500000 THEN RAISE EXCEPTION 'topup_amount_invalid'; END IF;
  IF _max_balance IS NULL OR _max_balance <= 0 OR _max_balance > 1000000 THEN RAISE EXCEPTION 'topup_limit_invalid'; END IF;
  PERFORM pg_advisory_xact_lock(hashtext('topup:' || _user_id::text));
  SELECT coalesce((SELECT balance FROM public.credit_wallets WHERE user_id = _user_id), 0) INTO bal;
  SELECT count(*), coalesce(sum(amount), 0) INTO open_n, reserved FROM public.orders
    WHERE user_id = _user_id AND kind = 'credits' AND status = 'pending' AND razorpay_payment_id IS NULL;
  IF open_n >= greatest(_max_open, 1) THEN RAISE EXCEPTION 'topup_too_many_open'; END IF;
  IF bal + reserved + _amount > _max_balance THEN RAISE EXCEPTION 'topup_over_limit'; END IF;
  INSERT INTO public.orders (user_id, kind, product, plan_id, plan_name, billing, location, amount, server_name, paid_with)
    VALUES (_user_id, 'credits', 'credits', 'credits', 'PlexScale Credits', 'once', 'online', _amount, '', 'razorpay')
    RETURNING id INTO new_id;
  RETURN new_id;
END;
$$;
REVOKE ALL ON FUNCTION public.create_topup_order(uuid, integer, integer, integer) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.create_topup_order(uuid, integer, integer, integer) TO service_role;
--> statement-breakpoint

-- Top-up settlement with a hard balance ceiling. A payment that would pass the ceiling is kept for review (returns -1).
CREATE OR REPLACE FUNCTION public.credit_topup(_order_id uuid, _payment_id text)
RETURNS integer
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE o public.orders%ROWTYPE; bal integer; nb integer;
BEGIN
  IF _payment_id IS NULL OR _payment_id !~ '^pay_[A-Za-z0-9]{6,40}$' THEN RAISE EXCEPTION 'credits_payment_invalid'; END IF;
  SELECT * INTO o FROM public.orders WHERE id = _order_id FOR UPDATE;
  IF NOT FOUND OR o.kind <> 'credits' OR o.status NOT IN ('pending', 'failed') OR o.razorpay_payment_id IS NOT NULL THEN RETURN NULL; END IF;
  PERFORM pg_advisory_xact_lock(hashtext('topup:' || o.user_id::text));
  SELECT coalesce((SELECT balance FROM public.credit_wallets WHERE user_id = o.user_id FOR UPDATE), 0) INTO bal;
  IF bal + o.amount > 1000000 THEN
    UPDATE public.orders SET status = 'failed', razorpay_payment_id = _payment_id, paid_at = now() WHERE id = o.id;
    INSERT INTO public.refunds (order_id, user_id, reason, status)
      VALUES (o.id, o.user_id, 'Top-up would pass the maximum credit balance. Needs administrator review.', 'requested')
      ON CONFLICT (order_id) DO NOTHING;
    RETURN -1;
  END IF;
  UPDATE public.orders SET status = 'credited', razorpay_payment_id = _payment_id, paid_at = now() WHERE id = o.id;
  INSERT INTO public.credit_wallets (user_id, balance) VALUES (o.user_id, o.amount)
    ON CONFLICT (user_id) DO UPDATE SET balance = public.credit_wallets.balance + EXCLUDED.balance, updated_at = now()
    RETURNING balance INTO nb;
  INSERT INTO public.credit_transactions (user_id, amount, balance_after, kind, order_id, note)
    VALUES (o.user_id, o.amount, nb, 'topup', o.id, 'Razorpay top-up');
  RETURN nb;
END;
$$;
REVOKE ALL ON FUNCTION public.credit_topup(uuid, text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.credit_topup(uuid, text) TO service_role;
--> statement-breakpoint

-- System operations: data backups, restore and stack update runs. Server only; no app role can read these tables.
DROP TABLE IF EXISTS public.settings_backups;
DROP TABLE IF EXISTS public.stack_update_runs;

CREATE TABLE IF NOT EXISTS public.system_backups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid,
  reason text NOT NULL CHECK (reason IN ('manual', 'before_update', 'before_restore')),
  note text CHECK (note IS NULL OR char_length(note) <= 200),
  code_ref text CHECK (code_ref IS NULL OR code_ref ~ '^[A-Za-z0-9._/-]{1,100}$'),
  code_status text NOT NULL DEFAULT 'skipped' CHECK (code_status IN ('skipped', 'queued', 'done', 'failed')),
  row_counts jsonb NOT NULL DEFAULT '{}'::jsonb,
  size_bytes bigint NOT NULL DEFAULT 0,
  data jsonb NOT NULL
);
CREATE INDEX IF NOT EXISTS system_backups_created_idx ON public.system_backups (created_at DESC);
REVOKE ALL ON public.system_backups FROM anon, authenticated;
GRANT ALL ON public.system_backups TO service_role;
ALTER TABLE public.system_backups ENABLE ROW LEVEL SECURITY;

CREATE TABLE IF NOT EXISTS public.system_update_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid,
  kind text NOT NULL CHECK (kind IN ('update', 'restore_code', 'code_backup')),
  backup_id uuid REFERENCES public.system_backups(id) ON DELETE SET NULL,
  packages jsonb NOT NULL DEFAULT '[]'::jsonb,
  ref text CHECK (ref IS NULL OR ref ~ '^[A-Za-z0-9._/-]{1,100}$'),
  status text NOT NULL DEFAULT 'queued' CHECK (status IN ('queued', 'running', 'succeeded', 'failed')),
  holds_maintenance boolean NOT NULL DEFAULT false,
  message text CHECK (message IS NULL OR char_length(message) <= 300),
  finished_at timestamptz
);
-- Only one run at a time.
CREATE UNIQUE INDEX IF NOT EXISTS system_update_runs_one_active ON public.system_update_runs ((true)) WHERE status IN ('queued', 'running');
CREATE INDEX IF NOT EXISTS system_update_runs_created_idx ON public.system_update_runs (created_at DESC);
REVOKE ALL ON public.system_update_runs FROM anon, authenticated;
GRANT ALL ON public.system_update_runs TO service_role;
ALTER TABLE public.system_update_runs ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint

-- Turns maintenance on or off without touching other settings. Returns the previous state.
CREATE OR REPLACE FUNCTION public.set_maintenance(_on boolean)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE was boolean;
BEGIN
  SELECT coalesce((data->'maintenance'->>'enabled')::boolean, false) INTO was FROM public.site_settings WHERE id = 1 FOR UPDATE;
  UPDATE public.site_settings
     SET data = data || jsonb_build_object('maintenance', coalesce(data->'maintenance', '{}'::jsonb) || jsonb_build_object('enabled', _on)),
         updated_at = now()
   WHERE id = 1;
  RETURN coalesce(was, false);
END;
$$;
REVOKE ALL ON FUNCTION public.set_maintenance(boolean) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.set_maintenance(boolean) TO service_role;
--> statement-breakpoint

-- Tables included in a backup, in restore order (parents first).
CREATE OR REPLACE FUNCTION public.backup_tables()
RETURNS text[]
LANGUAGE sql IMMUTABLE SET search_path = public
AS $$ SELECT ARRAY[
  'profiles', 'user_roles', 'admin_email_grants', 'coupons', 'orders', 'refunds', 'invoices',
  'site_settings', 'panel_settings', 'email_settings', 'email_events', 'support_tickets', 'ticket_messages',
  'panel_alerts', 'webhook_events', 'plexus_accounts', 'credit_wallets', 'credit_transactions', 'audit_log'
] $$;
REVOKE ALL ON FUNCTION public.backup_tables() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.backup_tables() TO service_role;
--> statement-breakpoint

-- Copies every business table into one backup row. Keeps the newest 5.
CREATE OR REPLACE FUNCTION public.create_system_backup(_by uuid, _reason text, _note text)
RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE t text; rows jsonb; d jsonb := '{}'::jsonb; counts jsonb := '{}'::jsonb; new_id uuid;
BEGIN
  IF _reason NOT IN ('manual', 'before_update', 'before_restore') THEN RAISE EXCEPTION 'backup_reason_invalid'; END IF;
  PERFORM pg_advisory_xact_lock(hashtext('system_backups'));
  FOREACH t IN ARRAY public.backup_tables() LOOP
    IF to_regclass('public.' || t) IS NULL THEN CONTINUE; END IF;
    EXECUTE format('SELECT coalesce(jsonb_agg(to_jsonb(x)), ''[]''::jsonb) FROM public.%I x', t) INTO rows;
    d := d || jsonb_build_object(t, rows);
    counts := counts || jsonb_build_object(t, jsonb_array_length(rows));
  END LOOP;
  d := d || jsonb_build_object('_meta', jsonb_build_object('format', 1, 'created_at', now()));
  INSERT INTO public.system_backups (created_by, reason, note, row_counts, size_bytes, data)
    VALUES (_by, _reason, nullif(btrim(coalesce(_note, '')), ''), counts, octet_length(d::text), d)
    RETURNING id INTO new_id;
  DELETE FROM public.system_backups
   WHERE id NOT IN (SELECT id FROM public.system_backups ORDER BY created_at DESC, id DESC LIMIT 5);
  RETURN new_id;
END;
$$;
REVOKE ALL ON FUNCTION public.create_system_backup(uuid, text, text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.create_system_backup(uuid, text, text) TO service_role;
--> statement-breakpoint

-- Restores every table from a backup in one transaction. A safety backup is taken first, the current
-- maintenance switch is kept, the audit log is merged (never wiped) and the restoring admin keeps access.
CREATE OR REPLACE FUNCTION public.restore_system_backup(_id uuid, _by uuid)
RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, auth
AS $$
DECLARE
  b public.system_backups%ROWTYPE; safety uuid; t text; cols text; rows jsonb; maint jsonb;
  tables text[] := public.backup_tables(); i integer; ucol text; idc record;
BEGIN
  SELECT * INTO b FROM public.system_backups WHERE id = _id;
  IF NOT FOUND THEN RAISE EXCEPTION 'backup_not_found'; END IF;
  safety := public.create_system_backup(_by, 'before_restore', 'Automatic copy before restore');
  PERFORM pg_advisory_xact_lock(hashtext('system_backups'));
  SELECT data->'maintenance' INTO maint FROM public.site_settings WHERE id = 1 FOR UPDATE;

  FOR i IN REVERSE array_length(tables, 1)..1 LOOP
    t := tables[i];
    IF t = 'audit_log' OR to_regclass('public.' || t) IS NULL OR NOT (b.data ? t) THEN CONTINUE; END IF;
    EXECUTE format('DELETE FROM public.%I', t);
  END LOOP;

  FOREACH t IN ARRAY tables LOOP
    IF to_regclass('public.' || t) IS NULL OR NOT (b.data ? t) THEN CONTINUE; END IF;
    rows := b.data->t;
    IF jsonb_array_length(rows) = 0 THEN CONTINUE; END IF;
    SELECT string_agg(quote_ident(c.column_name), ', ' ORDER BY c.ordinal_position) INTO cols
      FROM information_schema.columns c
     WHERE c.table_schema = 'public' AND c.table_name = t AND c.is_generated = 'NEVER'
       AND c.column_name IN (SELECT jsonb_object_keys(rows->0));
    IF cols IS NULL THEN CONTINUE; END IF;
    -- Rows for accounts that no longer exist are skipped.
    ucol := CASE t WHEN 'profiles' THEN 'id' WHEN 'user_roles' THEN 'user_id' WHEN 'plexus_accounts' THEN 'user_id'
                   WHEN 'credit_wallets' THEN 'user_id' WHEN 'credit_transactions' THEN 'user_id' ELSE NULL END;
    EXECUTE format(
      'INSERT INTO public.%1$I (%2$s) OVERRIDING SYSTEM VALUE SELECT %2$s FROM jsonb_populate_recordset(NULL::public.%1$I, $1) r %3$s ON CONFLICT DO NOTHING',
      t, cols, CASE WHEN ucol IS NULL THEN '' ELSE format('WHERE EXISTS (SELECT 1 FROM auth.users u WHERE u.id = r.%I)', ucol) END
    ) USING rows;
  END LOOP;

  -- Keep identity counters (invoice and ticket numbers) ahead of restored rows.
  FOR idc IN SELECT c.table_name, c.column_name FROM information_schema.columns c
              WHERE c.table_schema = 'public' AND c.is_identity = 'YES' AND c.table_name = ANY (tables) LOOP
    EXECUTE format('SELECT setval(pg_get_serial_sequence(%L, %L), greatest((SELECT coalesce(max(%I), 0) FROM public.%I), 1), true)',
      'public.' || idc.table_name, idc.column_name, idc.column_name, idc.table_name);
  END LOOP;

  INSERT INTO public.site_settings (id, data) VALUES (1, '{}'::jsonb) ON CONFLICT (id) DO NOTHING;
  INSERT INTO public.panel_settings (id, data) VALUES (1, '{}'::jsonb) ON CONFLICT (id) DO NOTHING;
  INSERT INTO public.email_settings (id, data) VALUES (1, '{}'::jsonb) ON CONFLICT (id) DO NOTHING;
  IF maint IS NOT NULL THEN
    UPDATE public.site_settings SET data = data || jsonb_build_object('maintenance', maint), updated_at = now() WHERE id = 1;
  END IF;
  IF _by IS NOT NULL AND EXISTS (SELECT 1 FROM auth.users WHERE id = _by) THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (_by, 'admin') ON CONFLICT (user_id, role) DO NOTHING;
  END IF;
  RETURN safety;
END;
$$;
REVOKE ALL ON FUNCTION public.restore_system_backup(uuid, uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.restore_system_backup(uuid, uuid) TO service_role;
