# PlexScale Web - project rules

## Runtime and build
- Self-hosted only: a plain Vite build (`vite.config.ts`) served by `server/index.mjs` (Node.js built-ins only) on 127.0.0.1; the internet reaches it only through the Cloudflare tunnel. Never bind another interface.
- pnpm with exact versions only (`pnpm-lock.yaml`); dependency build scripts are blocked (`allowBuilds` in `pnpm-workspace.yaml`), new versions wait 24 hours, and `pnpm audit --audit-level high` must pass. Never add a version range.
- The browser talks to the self-hosted API (`VITE_SUPABASE_URL`, https://api.<domain>); the server uses `SUPABASE_URL` (127.0.0.1). The page script policy names that API host instead of a wildcard (`src/lib/csp.ts`).
- Email goes over SMTP with Node's `net`/`tls` (`src/lib/smtp.server.ts`); Administrator SMTP settings win over the `SMTP_*` environment fallback.

## Database
- Migrations live in `db/migrations/NNNN_name.sql`, are add-only and run with `scripts/migrate.mjs` against `DATABASE_URL` in one transaction with a checksum ledger (`plexscale_meta.schema_migrations`). Never edit, rename or delete a migration that shipped; add a new numbered file and regenerate `db/migrations.sha256`.
- `src/test/migrator.test.ts` freezes the checksums of shipped migrations; a new release adds lines, it never changes them.

## Versioning
- `VERSION` and `package.json` carry the same strict semantic version (`scripts/migrate.mjs` reads `VERSION`).

## Project rules
- Email is sent over admin-configured SMTP (`src/lib/smtp.server.ts`, TLS verified); credentials live encrypted in a server-only table — never expose them to the browser.
- Invoice PDFs are generated in pure JS on the server (`src/lib/invoice.server.ts`); no native modules.
- Prices, upgrade costs and order totals are always recomputed on the server from plan config; never trust amounts from the browser.
- Scheduled jobs live under `/api/internal/jobs/*` and are reachable only through the server's local Unix socket (`server/index.mjs`, systemd timers in `deploy/systemd`); the public listener answers 404 and `src/lib/internal-jobs.server.ts` rejects any request carrying Cloudflare or forwarding headers. Keep jobs idempotent.
- Sign-in is Google and Discord only, through the self-hosted auth service (`supabase.auth.signInWithOAuth`, PKCE). Email, magic-link and OTP sign-in are disabled in the auth service and refused by the gateway; do not add them.
- The human check (Turnstile) fails closed: without both keys sign-in and new tickets are unavailable; test keys are never used.
- Visitor IP comes only from `CF-Connecting-IP` (`cloudflareIp` in `src/lib/ip.ts`); other forwarding headers are ignored because the only way in is the Cloudflare tunnel.
- Panel failures go through `reportPanelFailure` (`src/lib/panel-errors.server.ts`): customers only ever see the short friendly line (no Support ID); full scrubbed detail goes to `panel_alerts` for admins. Never store panel request bodies.
- There is no installer, updater or backup feature in the app or the repository; servers are set up and backed up by the operator (see `deploy/docs/SETUP.md`).
- Extra game ports are reserved by egg variable name (`extraPortVariables` in `src/config/egg-env.ts`); when a game needs extra ports and reservation fails, provisioning fails loudly instead of falling back to auto placement.
- Server deletion passes claim the order row with a conditional update before calling the panel and revert the claim on failure, so the daily job is safe to rerun.
- Money and renewal state changes are single conditional updates or SECURITY DEFINER database functions; Razorpay webhook events are deduplicated by event id and an hourly reconcile job catches missed ones.
- Coupon rules live in `src/config/coupon-rules.ts`; the server recomputes and locks the coupon when the order is created, never trusting browser totals.
- Rate limits are database-backed (`src/lib/rate-limit.server.ts`) so they hold across restarts.
- The production script policy uses a per-request nonce set in `src/server.ts` and passed to the router via `src/lib/csp-nonce.ts`; never add `'unsafe-inline'` to script-src.
- The service-role client is only imported from `*.server.ts` files (enforced by ESLint).
- VPS services are provisioned on Plexus (`src/lib/plexus.server.ts`, env `PLEXUS_URL` + `PLEXUS_API_KEY`); location→cluster and OS→image mappings live in private panel settings (`plexus`), the customer-visible OS list in site settings (`vpsOs`), both edited only from Administrator → Plexus so other saves preserve them.
- Plexus create/delete return 202 (queued); customer Plexus accounts are tracked server-only in `plexus_accounts` and removed by the daily job once no VPS remains, retrying on 409.
- Panel access credentials are generated server-side on demand and returned once; they are never stored.
- Both button style factories must explicitly pair hover backgrounds with readable text colors, because custom button classes merge with the default Button variant.
- Optimize raster assets only when decoded RGBA pixels and dimensions remain identical and the replacement is smaller; retain existing formats and import paths.
- Credits are whole-rupee wallet balances changed only by SECURITY DEFINER functions in migration 0006 (`credit_topup`, `spend_credits`, `refund_order_to_credits`, `admin_adjust_credits`) with an append-only ledger; customers have read-only access, so a balance can never be edited or double-spent from the app.
- Credit top-ups are `orders` rows (`kind='credits'`, `billing='once'`) so the existing Razorpay verification, webhook, reconcile job and invoices cover them; credit-paid orders carry `paid_with='credits'` and are never closed by unpaid-order cleanup.
- Shared page building blocks (`src/components/ui-px/page.tsx`, `form.ts`) and the `panel`/`panel-inset` utilities define the page look; page backgrounds stay flat (no glow layers) and new pages reuse these instead of ad hoc card or input classes.
- Errors reaching the browser are generic: throw `PublicError` for messages customers may see; every other server error is logged and replaced by the function middleware in `src/start.ts`.
- Server functions are served under `/_px` and the client bundle is obfuscated in `vite.config.ts`; keep `x-tss-raw`/`x-tsr-redirect` headers, the client depends on them.
- Renewal settlement, coupon re-checks on revived orders and top-up ceilings live in database functions (migration 0007) so concurrent payments cannot bypass them.
