# Changelog

PlexScale Web follows [Semantic Versioning](https://semver.org). Database migrations are add-only.

## 1.1.1 - self-hosted

Upgrade from: 1.1.0 or newer.

### Added
- Runs on your own VPS behind a Cloudflare tunnel; set-up is manual (see `deploy/docs/SETUP.md`).
- Self-hosted database stack (database, sign-in, data API, gateway) bound to 127.0.0.1.
- Google and Discord sign-in through the self-hosted sign-in service.
- Migration runner with a checksum ledger (`pnpm migrate`); migrations moved to `db/migrations`.
- Migration 0008 removes the old in-database backup tables.

### Changed
- Node.js 26 LTS production server listening on 127.0.0.1 only; pnpm with exact versions, blocked build
  scripts, a 24-hour wait for new package versions and audits that fail on high severity.
- Email uses Node's built-in network and TLS modules, with installer SMTP settings as a fallback.
- Visitor IP is read only from Cloudflare's `CF-Connecting-IP` header.
- The human check refuses sign-in and new tickets when its keys are missing (no test keys).
- The page script policy names the API host instead of a wildcard database host.
- Scheduled jobs are accepted only from the server itself, never through the tunnel.

### Fixed
- A plan bought or paid on the 29th-31st no longer renews a few days late when the next month is shorter
  (31 Jan + 1 month is now 28 Feb, matching the database's renewal rule).

### Removed
- Administrator -> Updates & backups page, the GitHub workflow, the ops callback and the stack-check rules.
- Installer, updater, `plexscale` command, backup scripts and their tests, release manifest and `release.json`.
- Hosted-platform integrations, preview session storage and error reporting.
- Drizzle, the beta Nitro package and all version ranges.
- Unused wordmark images.
