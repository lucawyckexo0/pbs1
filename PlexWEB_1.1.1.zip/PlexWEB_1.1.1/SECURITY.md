# PlexScale Web security runbook

## How the server is exposed
- Nothing listens on a public interface. The website (127.0.0.1:3000), API gateway (127.0.0.1:8000) and database (127.0.0.1:54322) are loopback-only; the internet reaches the first two only through the Cloudflare tunnel. Keep the VPS firewall closed to everything except SSH.
- The gateway routes only `/auth/v1` and `/rest/v1`. Email, magic-link, OTP, SSO and MFA endpoints are refused, and the auth service has email/phone/anonymous sign-in switched off: only Google and Discord can sign in.
- Scheduled jobs are served only on a local Unix socket (`/run/plexscale/internal.sock`, owner-only). Requests through the tunnel get 404, even with a valid secret, and any request carrying Cloudflare or forwarding headers is refused. The job units cannot open network connections.
- systemd sandboxing on every service (no new privileges, read-only system, private /tmp, no capabilities, syscall filter); the tunnel runs as a throw-away user with no access to PlexScale files.
- Container images are pinned by digest in `deploy/supabase/docker-compose.yml`.

## Secrets and rotation
All secrets live in root-only files in `/etc/plexscale` (mode 600), as listed in `deploy/docs/SETUP.md`; `.env` files are git-ignored. Rotate on staff changes, suspected leaks, and at least yearly. After editing a file restart the service (`sudo systemctl restart plexscale-web`).

| Secret | File | How to rotate |
|---|---|---|
| `RAZORPAY_KEY_ID` / `RAZORPAY_KEY_SECRET` | plexscale.env | Generate a new key pair in Razorpay, update both, confirm a test checkout, then revoke the old key. |
| `RAZORPAY_WEBHOOK_SECRET` | plexscale.env | Set a new secret on the webhook and update it here within a minute. Missed events are caught by the reconcile job. |
| `PTERODACTYL_API_KEY` | plexscale.env | Create a new application key with only: Servers (read/write), Nodes (read), Allocations (read/write), Nests/Eggs (read), Users (read/write), Locations (read). Update, test a provision, delete the old key. |
| `PLEXUS_API_KEY` | plexscale.env | Create a new key in Plexus, update, test, revoke the old one. |
| `TURNSTILE_SITE_KEY` / `TURNSTILE_SECRET_KEY` | plexscale.env | Rotate the secret in Cloudflare, update here and restart the service (`sudo systemctl restart plexscale-web`). |
| `SETTINGS_ENCRYPTION_KEY` | plexscale.env | Encrypted settings are versioned (`v1:`/`v2:`). Add the new key, re-save SMTP settings in Administrator so they are rewritten, then remove the old key. |
| `CRON_SECRET` | plexscale.env and jobs.env | Move the old value to `CRON_SECRET_PREVIOUS` in plexscale.env, set the new value in both files, restart, then clear the previous value. |
| `GOOGLE_SECRET` / `DISCORD_SECRET` | supabase.env | Create a new client secret with the provider, update, `sudo systemctl restart plexscale-supabase`, revoke the old one. |
| `TUNNEL_TOKEN` | cloudflared.env | Refresh the token in Zero Trust, update, `sudo systemctl restart plexscale-cloudflared`. |
| Database passwords, `JWT_SECRET` | supabase.env, migrate.env | Changing these requires coordinated updates of the database roles and API keys (mint new keys with `deploy/bin/gen-keys.mjs`). Never reuse them elsewhere. |

## Built-in protections
- Every public table has row level security; `src/test/rls-static.test.ts` fails if a table lacks it, and `src/test/rls-live.test.ts` (run with `RLS_LIVE=1`) checks anonymous and cross-user access against the live database.
- The service-role client may only be imported from `*.server.ts` files (ESLint rule).
- Payments: webhook events are deduplicated by Razorpay event id; paid/renewal state changes are conditional single updates or database functions; an hourly job reconciles missed payments and retries failed provisioning.
- Abuse: database-backed rate limits on sign-in checks, orders, renewals, upgrades, coupons, tickets and the webhook, keyed on the visitor address from `CF-Connecting-IP` only (other forwarding headers are ignored). Turnstile guards sign-in and new tickets and fails closed: without real keys both are unavailable.
- Headers: nonce-based script policy, no framing, same-origin resource policy, HSTS.
- The admin audit log is append-only for the app (insert and read only).
- Credits: balances and the ledger are read-only to customers; every change is one locked database function callable only by the server. Double top-ups, double spends, double refunds and overdrafts are rejected by the database itself (`src/test/credits-db.test.ts` runs these rules against real Postgres).
- Admin server functions share one guard (`src/lib/admin-guard.ts`) that re-checks the administrator role on every call and rate-limits writes.
- Money-moving endpoints (checkout, renewals, upgrades, top-ups, payment verification) use fail-closed rate limits: if the limiter cannot be reached, the request is refused rather than allowed.
- Billing guards in the database (migration 0007): an expired or used-up coupon is re-checked before a late payment revives an order; a renewal quote is void once the plan changed; renewal payments settle in one locked function; top-ups are capped against balance plus open top-ups.
- Errors: customers only ever see short generic messages. Server functions run behind an error mask, framework errors on the RPC path are replaced, and identifying response headers are removed.
- Client: production builds ship without source maps, the client code is obfuscated, the console is silenced, and right-click, drag and common developer-tool shortcuts are blocked. This slows casual copying; it cannot stop a determined visitor, so never put secrets or business rules in browser code.
