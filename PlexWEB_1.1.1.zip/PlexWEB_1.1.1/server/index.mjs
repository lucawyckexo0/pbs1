// PlexScale Web production server. Node.js built-ins only, no dependencies.
//
// Two listeners:
// - Public:   127.0.0.1:PORT (default 3000). The only way in from the internet is the Cloudflare tunnel,
//             which connects to this loopback address. It can never bind to another interface.
// - Internal: a Unix socket (default /run/plexscale/internal.sock, mode 0600) used only by the
//             scheduled-job timers on this machine. It serves /api/internal/jobs/* and /api/public/health.
//
// The public listener answers 404 for /api/internal/* and strips the internal marker header, so a request
// through the tunnel can never reach a scheduled job.
import { randomBytes } from "node:crypto";
import { createReadStream, existsSync, chmodSync, unlinkSync, lstatSync } from "node:fs";
import { stat } from "node:fs/promises";
import http from "node:http";
import path from "node:path";
import { Readable, Transform } from "node:stream";
import { fileURLToPath, pathToFileURL } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const CLIENT_DIR = path.join(ROOT, "dist", "client");
const SERVER_ENTRY = path.join(ROOT, "dist", "server", "server.js");
const INTERNAL_MARKER_HEADER = "x-plexscale-internal";
const NONCE_HEADER = "x-plexscale-csp-nonce";
const MAX_BODY_BYTES = 2 * 1024 * 1024; // webhooks and server functions are small; anything larger is refused

function fail(message) {
  console.error(`[plexscale] ${message}`);
  process.exit(1);
}

const HOST = process.env.HOST ?? "127.0.0.1";
if (HOST !== "127.0.0.1" && HOST !== "::1") fail(`HOST must be 127.0.0.1 or ::1 (got ${JSON.stringify(HOST)}). The site is published only through the Cloudflare tunnel.`);
const PORT = Number(process.env.PORT ?? "3000");
if (!Number.isInteger(PORT) || PORT < 1024 || PORT > 65535) fail("PORT must be an integer between 1024 and 65535.");
const INTERNAL_SOCKET = process.env.PLEXSCALE_INTERNAL_SOCKET ?? "/run/plexscale/internal.sock";
if (!path.isAbsolute(INTERNAL_SOCKET)) fail("PLEXSCALE_INTERNAL_SOCKET must be an absolute path.");

// Every request URL is built on the site's own origin, never on the Host header.
let ORIGIN;
try {
  const u = new URL(process.env.SITE_URL ?? `http://127.0.0.1:${PORT}`);
  if (u.protocol !== "https:" && u.hostname !== "127.0.0.1" && u.hostname !== "localhost") throw new Error("SITE_URL must use https");
  ORIGIN = u.origin;
} catch (e) {
  fail(`SITE_URL is invalid: ${e instanceof Error ? e.message : e}`);
}

// Per-process marker for the internal listener; src/lib/internal-jobs.server.ts compares against it.
const INTERNAL_MARKER = randomBytes(32).toString("hex");
globalThis[Symbol.for("plexscale.internalMarker")] = INTERNAL_MARKER;

if (!existsSync(SERVER_ENTRY)) fail(`Build output missing: ${SERVER_ENTRY}. Run the build first.`);
const app = (await import(pathToFileURL(SERVER_ENTRY).href)).default;
if (!app || typeof app.fetch !== "function") fail("dist/server/server.js does not export a fetch handler.");

const MIME = {
  ".js": "text/javascript; charset=utf-8", ".mjs": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8",
  ".html": "text/html; charset=utf-8", ".json": "application/json; charset=utf-8", ".txt": "text/plain; charset=utf-8",
  ".svg": "image/svg+xml", ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp",
  ".gif": "image/gif", ".ico": "image/x-icon", ".avif": "image/avif", ".woff": "font/woff", ".woff2": "font/woff2",
  ".ttf": "font/ttf", ".webmanifest": "application/manifest+json", ".xml": "application/xml; charset=utf-8",
};

/** Resolves a URL path to a file inside dist/client, or null. Refuses traversal, dotfiles and symlinks. */
async function staticFile(pathname) {
  let decoded;
  try { decoded = decodeURIComponent(pathname); } catch { return null; }
  if (decoded.includes("\0") || decoded.includes("\\") || decoded.split("/").some((seg) => seg.startsWith("."))) return null;
  const file = path.resolve(CLIENT_DIR, `.${decoded}`);
  if (!file.startsWith(CLIENT_DIR + path.sep)) return null;
  try {
    const st = await stat(file);
    if (!st.isFile() || lstatSync(file).isSymbolicLink()) return null;
    return { file, size: st.size, mtime: st.mtime };
  } catch {
    return null;
  }
}

function sendStatic(req, res, hit, pathname) {
  const type = MIME[path.extname(hit.file).toLowerCase()] ?? "application/octet-stream";
  res.statusCode = 200;
  res.setHeader("content-type", type);
  res.setHeader("content-length", hit.size);
  res.setHeader("last-modified", hit.mtime.toUTCString());
  res.setHeader("cache-control", pathname.startsWith("/assets/") ? "public, max-age=31536000, immutable" : "public, max-age=3600");
  res.setHeader("x-content-type-options", "nosniff");
  res.setHeader("cross-origin-resource-policy", "same-origin");
  res.setHeader("referrer-policy", "strict-origin-when-cross-origin");
  if (req.method === "HEAD") return res.end();
  createReadStream(hit.file).on("error", () => res.destroy()).pipe(res);
}

/** Caps the request body; the stream errors once the limit is passed. */
function limitedBody(req) {
  let seen = 0;
  const cap = new Transform({
    transform(chunk, _enc, cb) {
      seen += chunk.length;
      if (seen > MAX_BODY_BYTES) cb(new Error("body too large")); else cb(null, chunk);
    },
  });
  req.on("error", (e) => cap.destroy(e));
  return Readable.toWeb(req.pipe(cap));
}

function plain(res, status, text) {
  res.writeHead(status, { "content-type": "text/plain; charset=utf-8", "cache-control": "no-store", "x-content-type-options": "nosniff" });
  res.end(text);
}

async function handle(req, res, internal) {
  const raw = req.url ?? "/";
  if (!raw.startsWith("/") || raw.startsWith("//")) return plain(res, 400, "Bad request");
  const url = new URL(raw, ORIGIN);
  const { pathname } = url;

  if (internal) {
    // The socket serves the scheduled jobs and the health check, nothing else.
    if (!pathname.startsWith("/api/internal/jobs/") && pathname !== "/api/public/health") return plain(res, 404, "Not found");
  } else if (pathname === "/api/internal" || pathname.startsWith("/api/internal/")) {
    return plain(res, 404, "Not found");
  }

  if (!internal && (req.method === "GET" || req.method === "HEAD") && pathname !== "/") {
    const hit = await staticFile(pathname);
    if (hit) return sendStatic(req, res, hit, pathname);
  }

  const declared = Number(req.headers["content-length"] ?? "0");
  if (Number.isFinite(declared) && declared > MAX_BODY_BYTES) return plain(res, 413, "Payload too large");

  const headers = new Headers();
  for (const [k, v] of Object.entries(req.headers)) {
    if (v === undefined || k.startsWith(":")) continue;
    if (Array.isArray(v)) for (const item of v) headers.append(k, item); else headers.set(k, v);
  }
  headers.delete(INTERNAL_MARKER_HEADER);
  headers.delete(NONCE_HEADER);
  if (internal) headers.set(INTERNAL_MARKER_HEADER, INTERNAL_MARKER);

  const controller = new AbortController();
  res.on("close", () => { if (!res.writableFinished) controller.abort(); });
  const hasBody = req.method !== "GET" && req.method !== "HEAD";
  const request = new Request(url, {
    method: req.method,
    headers,
    signal: controller.signal,
    ...(hasBody ? { body: limitedBody(req), duplex: "half" } : {}),
  });

  let response;
  try {
    response = await app.fetch(request, {}, {});
  } catch (e) {
    console.error("[plexscale] request failed", e instanceof Error ? e.message : e);
    return plain(res, 500, "Something went wrong");
  }

  res.statusCode = response.status;
  if (response.statusText) res.statusMessage = response.statusText;
  const cookies = typeof response.headers.getSetCookie === "function" ? response.headers.getSetCookie() : [];
  response.headers.forEach((value, key) => { if (key !== "set-cookie") res.setHeader(key, value); });
  if (cookies.length) res.setHeader("set-cookie", cookies);
  if (!response.body || req.method === "HEAD") return res.end();
  Readable.fromWeb(response.body).on("error", () => res.destroy()).pipe(res);
}

function makeServer(internal) {
  const server = http.createServer({ requestTimeout: 30_000, headersTimeout: 15_000, keepAliveTimeout: 5_000, maxHeaderSize: 16_384 }, (req, res) => {
    handle(req, res, internal).catch((e) => {
      console.error("[plexscale] unhandled", e instanceof Error ? e.message : e);
      if (!res.headersSent) plain(res, 500, "Something went wrong"); else res.destroy();
    });
  });
  server.on("clientError", (_e, socket) => { if (socket.writable) socket.end("HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n"); else socket.destroy(); });
  return server;
}

const publicServer = makeServer(false);
const internalServer = makeServer(true);

publicServer.listen(PORT, HOST, () => console.log(`[plexscale] web listening on http://${HOST}:${PORT}`));
publicServer.on("error", (e) => fail(`public listener: ${e.message}`));

if (existsSync(INTERNAL_SOCKET)) {
  if (!lstatSync(INTERNAL_SOCKET).isSocket()) fail(`${INTERNAL_SOCKET} exists and is not a socket.`);
  unlinkSync(INTERNAL_SOCKET);
}
const oldMask = process.umask(0o177);
internalServer.listen(INTERNAL_SOCKET, () => {
  process.umask(oldMask);
  chmodSync(INTERNAL_SOCKET, 0o600);
  console.log(`[plexscale] internal jobs listening on ${INTERNAL_SOCKET}`);
});
internalServer.on("error", (e) => fail(`internal listener: ${e.message}`));

let stopping = false;
function shutdown(signal) {
  if (stopping) return;
  stopping = true;
  console.log(`[plexscale] ${signal}: shutting down`);
  const done = () => { try { unlinkSync(INTERNAL_SOCKET); } catch { /* already gone */ } process.exit(0); };
  publicServer.close(); internalServer.close();
  publicServer.closeIdleConnections?.(); internalServer.closeIdleConnections?.();
  setTimeout(done, 10_000).unref();
  Promise.all([new Promise((r) => publicServer.on("close", r)), new Promise((r) => internalServer.on("close", r))]).then(done);
}
process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));
