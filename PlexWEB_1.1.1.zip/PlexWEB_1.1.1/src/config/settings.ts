import { z } from "zod";
import { locations } from "./site";
import { productKeys } from "./plans";
import { minecraftVersions } from "./software";
import { creditsSettingsSchema, defaultCreditsSettings } from "./credits";

export const minecraftVersionSchema = z.string().trim().max(20).regex(/^(latest|\d{1,3}\.\d{1,3}(\.\d{1,3})?)$/, "Use a release number such as 26.3");
const locationSchema = z.object({
  id: z.string().trim().min(1).max(40).regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/),
  city: z.string().trim().min(1).max(60),
  region: z.string().trim().min(1).max(60),
  country: z.string().trim().regex(/^[A-Z]{2}$/),
  x: z.number().min(0).max(100),
  y: z.number().min(0).max(100),
  mockPing: z.number().int().min(0).max(2000),
}).strict();

const httpsUrl = z.string().trim().max(300).url().refine((u) => u.startsWith("https://"), "Must start with https://");
const optionalHttpsUrl = z.union([z.literal(""), httpsUrl]);

const planOverride = z.object({
  product: z.enum(productKeys as [string, ...string[]]).optional(),
  custom: z.boolean().optional(),
  name: z.string().trim().max(40).optional(),
  vcpu: z.number().int().min(1).max(64).optional(),
  monthly: z.number().int().min(1).max(1_000_000).optional(),
  cpuPercent: z.number().int().min(5).max(6400).optional(),
  ramGb: z.number().min(0.25).max(1024).optional(),
  diskGb: z.number().int().min(1).max(10_000).optional(),
  hidden: z.boolean().optional(),
  popular: z.boolean().optional(),
  deploy: z.object({
    memoryMib: z.number().int().min(64).max(1_048_576).optional(),
    diskMib: z.number().int().min(0).max(10_485_760).optional(),
    cpu: z.number().int().min(0).max(6400).optional(),
    swapMib: z.number().int().min(-1).max(1_048_576).optional(),
    io: z.number().int().min(10).max(1000).optional(),
    threads: z.string().trim().max(60).regex(/^[0-9,\- ]*$/).optional(),
    databases: z.number().int().min(0).max(50).optional(),
    backups: z.number().int().min(0).max(50).optional(),
    allocations: z.number().int().min(1).max(20).optional(),
  }).strict().optional(),
  lines: z.array(z.string().trim().min(1).max(120)).max(12).optional(),
}).strict();

const vpsOsSchema = z.object({
  key: z.string().trim().min(1).max(40).regex(/^[a-z0-9]+(?:[.-][a-z0-9]+)*$/, "Use lowercase letters, numbers, dots and dashes"),
  family: z.enum(["ubuntu", "debian", "other"]),
  name: z.string().trim().min(1).max(30),
  version: z.string().trim().min(1).max(30),
  hint: z.string().trim().max(80),
  hidden: z.boolean(),
}).strict();
export type VpsOs = z.infer<typeof vpsOsSchema>;

export const defaultVpsOs: VpsOs[] = [
  { key: "ubuntu-26.10", family: "ubuntu", name: "Ubuntu", version: "26.10", hint: "Latest Ubuntu release.", hidden: false },
  { key: "ubuntu-26.04", family: "ubuntu", name: "Ubuntu", version: "26.04 LTS", hint: "Long-term support.", hidden: false },
  { key: "ubuntu-24.04", family: "ubuntu", name: "Ubuntu", version: "24.04 LTS", hint: "Most popular choice.", hidden: false },
  { key: "ubuntu-22.04", family: "ubuntu", name: "Ubuntu", version: "22.04 LTS", hint: "Long-term support.", hidden: false },
  { key: "debian-13", family: "debian", name: "Debian", version: "13", hint: "Current stable release.", hidden: false },
  { key: "debian-12", family: "debian", name: "Debian", version: "12", hint: "Stable and minimal.", hidden: false },
];

/** Public site settings: safe for anyone to read, editable in Administrator. */
export const siteSettingsSchema = z.object({
  locations: z.array(locationSchema).min(1).max(20).refine((ls) => new Set(ls.map((l) => l.id)).size === ls.length, "Location IDs must be unique"),
  minecraftVersions: z.array(minecraftVersionSchema).min(1).max(200).refine((vs) => new Set(vs).size === vs.length && vs.includes("latest"), "Keep latest and use unique versions"),
  discordUrl: httpsUrl,
  discordLabel: z.string().trim().min(1).max(60),
  supportEmail: z.string().trim().email().max(120),
  gamePanelUrl: httpsUrl,
  vpsPanelUrl: httpsUrl,
  announcement: z.object({
    enabled: z.boolean(),
    tone: z.enum(["info", "success", "warning", "danger"]),
    message: z.string().trim().max(240),
    linkLabel: z.string().trim().max(40),
    linkUrl: optionalHttpsUrl,
  }),
  maintenance: z.object({
    enabled: z.boolean(),
    title: z.string().trim().max(80),
    message: z.string().trim().max(400),
  }),
  ordering: z.object({
    enabled: z.boolean(),
    pausedMessage: z.string().trim().max(240),
    disabledProducts: z.array(z.enum(productKeys as [string, ...string[]])).max(10),
    disabledLocations: z.array(z.string().max(40)).max(20),
    /** Locations each product can be deployed in. A missing or empty list means every location. */
    productLocations: z.record(z.string().max(20), z.array(z.string().max(40)).max(20))
      .refine((r) => Object.keys(r).every((k) => (productKeys as string[]).includes(k)), "Unknown product")
      .default({}),
  }),
  plans: z.record(z.string().max(40), planOverride).refine((r) => Object.keys(r).length <= 300, "Too many plans"),
  /** VPS operating systems shown on the deploy page. Image ids live in the private panel settings. */
  vpsOs: z.array(vpsOsSchema).min(1).max(30).refine((l) => new Set(l.map((o) => o.key)).size === l.length, "OS keys must be unique"),
  /** Prepaid credits: limits and whether customers can buy and spend them. */
  credits: creditsSettingsSchema,
});

export type SiteSettings = z.infer<typeof siteSettingsSchema>;

export const defaultSiteSettings: SiteSettings = {
  locations,
  minecraftVersions,
  discordUrl: "https://discord.gg/plexscale",
  discordLabel: "discord.gg/plexscale",
  supportEmail: "help@plexscale.com",
  gamePanelUrl: "https://panel.plexscale.com",
  vpsPanelUrl: "https://vps.plexscale.com",
  announcement: { enabled: false, tone: "info", message: "", linkLabel: "", linkUrl: "" },
  maintenance: { enabled: false, title: "We’ll be right back", message: "PlexScale is undergoing scheduled maintenance. Your servers keep running. Please check back shortly." },
  ordering: { enabled: true, pausedMessage: "New orders are paused for a short while. Please check back soon.", disabledProducts: [], disabledLocations: [], productLocations: {} },
  plans: {},
  vpsOs: defaultVpsOs,
  credits: defaultCreditsSettings,
};

/** Operating systems a customer can pick when deploying a VPS. */
export const visibleVpsOs = (settings: Pick<SiteSettings, "vpsOs">) => settings.vpsOs.filter((o) => !o.hidden);
export const vpsOsLabel = (o: Pick<VpsOs, "name" | "version">) => `${o.name} ${o.version}`;

/** Locations offered for a product, honouring the admin's per-product location list. */
export function locationsForProduct(settings: Pick<SiteSettings, "locations" | "ordering">, product: string) {
  const allowed = settings.ordering.productLocations?.[product];
  if (!allowed || allowed.length === 0) return settings.locations;
  return settings.locations.filter((l) => allowed.includes(l.id));
}

/** Never throws: each bad or missing section falls back to its default. */
export function normalizeSiteSettings(raw: unknown): SiteSettings {
  const src = raw && typeof raw === "object" ? (raw as Record<string, unknown>) : {};
  const out: Record<string, unknown> = {};
  for (const key of Object.keys(siteSettingsSchema.shape) as (keyof SiteSettings)[]) {
    const r = siteSettingsSchema.shape[key].safeParse(src[key] ?? defaultSiteSettings[key]);
    out[key] = r.success ? r.data : defaultSiteSettings[key];
  }
  return out as SiteSettings;
}

/** Private Pterodactyl mapping. Only server code and admins see this. */
export const panelSettingsSchema = z.object({
  eggs: z.record(z.string().max(40), z.object({
    nestId: z.number().int().min(1),
    eggId: z.number().int().min(1),
    versionVariable: z.string().trim().max(60).regex(/^[A-Z0-9_]*$/, "Use CAPITAL_LETTERS"),
    dockerImage: z.string().trim().max(200),
    /** Fixed startup values for this software, e.g. SRCDS_BETAID=staging. */
    env: z.record(z.string().regex(/^[A-Z0-9_]{1,60}$/), z.string().max(500)).refine((r) => Object.keys(r).length <= 40, "Too many values").default({}),
  })),
  locations: z.record(z.string().max(40), z.number().int().min(1)),
  databases: z.number().int().min(0).max(50),
  backups: z.number().int().min(0).max(50),
  extraAllocations: z.number().int().min(0).max(20),
  io: z.number().int().min(10).max(1000),
  /** Optional port pools per product (e.g. "25565-25665"), so Minecraft and bots stay out of game port ranges. */
  portRanges: z.record(z.string().max(20), z.array(z.string().trim().regex(/^\d{1,5}(-\d{1,5})?$/, "Use 25565 or 25565-25665")).max(10))
    .refine((r) => Object.keys(r).every((k) => (productKeys as string[]).includes(k)), "Unknown product")
    .default({}),
  /** Plexus VPS mapping: site location id → cluster id, OS key → image id. */
  plexus: z.object({
    clusters: z.record(z.string().max(40), z.number().int().min(1)).default({}),
    images: z.record(z.string().max(40), z.number().int().min(1)).default({}),
  }).default({ clusters: {}, images: {} }),
});
export type PanelSettings = z.infer<typeof panelSettingsSchema>;

export const defaultPanelSettings: PanelSettings = {
  eggs: {},
  locations: {},
  databases: 1,
  backups: 2,
  extraAllocations: 0,
  io: 500,
  portRanges: {},
  plexus: { clusters: {}, images: {} },
};

export function normalizePanelSettings(raw: unknown): PanelSettings {
  const r = panelSettingsSchema.safeParse({ ...defaultPanelSettings, ...(raw && typeof raw === "object" ? raw : {}) });
  return r.success ? r.data : defaultPanelSettings;
}
