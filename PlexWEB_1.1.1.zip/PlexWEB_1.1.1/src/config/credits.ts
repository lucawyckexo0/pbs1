import { z } from "zod";

/** Balances and amounts are whole rupees. */
export const CREDIT_HARD_MAX_BALANCE = 1_000_000;

export const creditsSettingsSchema = z.object({
  /** Customers can buy credits. */
  enabled: z.boolean(),
  /** Customers can pay for new services, renewals and upgrades with their balance. */
  payWithCredits: z.boolean(),
  minTopup: z.number().int().min(1).max(500_000),
  maxTopup: z.number().int().min(1).max(500_000),
  maxBalance: z.number().int().min(100).max(CREDIT_HARD_MAX_BALANCE),
  presets: z.array(z.number().int().min(1).max(500_000)).max(6),
  /** Products whose orders, renewals and upgrades cannot be paid with credits. */
  disabledProducts: z.array(z.string().regex(/^[a-z0-9]{1,20}$/)).max(20).default([]),
}).refine((c) => c.minTopup <= c.maxTopup, { message: "Minimum top-up must not be above the maximum", path: ["minTopup"] })
  .refine((c) => c.maxTopup <= c.maxBalance, { message: "Maximum top-up must not be above the balance limit", path: ["maxTopup"] })
  .refine((c) => c.presets.every((p) => p >= c.minTopup && p <= c.maxTopup), { message: "Quick amounts must be between the minimum and maximum top-up", path: ["presets"] });

export type CreditsSettings = z.infer<typeof creditsSettingsSchema>;

export const defaultCreditsSettings: CreditsSettings = {
  enabled: true,
  payWithCredits: true,
  minTopup: 100,
  maxTopup: 25_000,
  maxBalance: 100_000,
  presets: [250, 500, 1000, 2500],
  disabledProducts: [],
};

export const creditTopupInput = z.object({ amount: z.number().int().positive().max(500_000) });

/** Why a top-up of `amount` is not allowed right now, or null when it is. */
export function topupProblem(amount: number, balance: number, s: CreditsSettings): string | null {
  if (!s.enabled) return "Credits are not available right now.";
  if (!Number.isInteger(amount) || amount <= 0) return "Enter a whole number of rupees.";
  if (amount < s.minTopup) return `The minimum top-up is ₹${s.minTopup.toLocaleString("en-IN")}.`;
  if (amount > s.maxTopup) return `The maximum top-up is ₹${s.maxTopup.toLocaleString("en-IN")}.`;
  if (balance + amount > s.maxBalance) return `Your balance can hold up to ₹${s.maxBalance.toLocaleString("en-IN")} in credits.`;
  return null;
}

/** True when credits are switched on and allowed for this product (game, VPS or bot hosting). */
export function creditsAllowedFor(product: string | null | undefined, s: Pick<CreditsSettings, "payWithCredits"> & { disabledProducts?: string[] | undefined }): boolean {
  if (!s.payWithCredits) return false;
  return !product || !(s.disabledProducts ?? []).includes(product);
}

/** True when the whole order can be paid from the balance (no split payments) and credits are allowed for the product. */
export function canPayWithCredits(balance: number, total: number, s: Pick<CreditsSettings, "payWithCredits"> & { disabledProducts?: string[] | undefined }, product?: string): boolean {
  return creditsAllowedFor(product, s) && Number.isInteger(total) && total > 0 && balance >= total;
}

export const creditKindLabel: Record<string, string> = {
  topup: "Top-up",
  spend: "Payment",
  refund: "Refund",
  admin_grant: "Added by PlexScale",
  admin_deduct: "Removed by PlexScale",
};

/** Customer-safe text for errors raised by the credit database functions. */
export function creditsErrorMessage(dbMessage: string | undefined | null): string {
  const m = dbMessage ?? "";
  if (m.includes("credits_insufficient")) return "Your credit balance is too low for this payment.";
  if (m.includes("credits_order_invalid")) return "This order can no longer be paid with credits.";
  if (m.includes("credits_refund_done")) return "This order was already refunded to credits.";
  if (m.includes("credits_amount_invalid")) return "Enter an amount between ₹1 and ₹10,00,000.";
  if (m.includes("credits_note_required")) return "Add a short reason (at least 3 characters).";
  if (m.includes("credits_user_unknown")) return "That account no longer exists.";
  return "The credit payment could not be completed. Nothing was charged.";
}
