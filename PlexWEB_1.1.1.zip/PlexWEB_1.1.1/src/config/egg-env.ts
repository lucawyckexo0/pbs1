import { cs2Modes, MAX_SEED, type GameOptions } from "./game-options";

/**
 * Turns a panel egg's default variables into the values a real server needs.
 * Pure on purpose: the server passes in the egg defaults, the order and a random source.
 * Only variables the egg actually defines are ever set.
 */
export interface EggEnvContext {
  product: string;
  serverName: string;
  description: string;
  ramMb: number;
  options: GameOptions;
  /** Extra ports given to this server, in the order `extraPortVariables` lists the variables. */
  ports: number[];
  /** Admin-set fixed values for this software; they win over everything except customer choices. */
  adminEnv?: Record<string, string>;
  random: { password: () => string; seed: () => number };
}

/** Port variables each game may need, in reservation order. Minecraft and bots need none. */
const PORT_VARIABLES: Record<string, readonly string[]> = {
  cs2: ["TV_PORT"],
  rust: ["RCON_PORT", "APP_PORT", "QUERY_PORT"],
  hytale: ["QUERY_PORT"],
};

/**
 * Names of the extra port variables this egg defines, in order. Only variables the egg actually
 * has are listed. Hytale skips its query port when the query plugin variable is "0".
 */
export function extraPortVariables(product: string, defaults: Record<string, string>): string[] {
  if (product === "hytale" && defaults["INSTALL_SOURCEQUERY_PLUGIN"] === "0") return [];
  return (PORT_VARIABLES[product] ?? []).filter((name) => name in defaults);
}

/** How many extra ports this egg needs (CS2 SourceTV, Rust RCON / Rust+ / query, Hytale query). */
export function extraPortsFor(product: string, defaults: Record<string, string>): number {
  return extraPortVariables(product, defaults).length;
}

/** Parses admin port ranges such as "25565-25665" or "27015". Bad entries are ignored. */
export function parsePortRanges(ranges: readonly string[] | undefined): { from: number; to: number }[] {
  const out: { from: number; to: number }[] = [];
  for (const r of ranges ?? []) {
    const m = /^(\d{1,5})(?:-(\d{1,5}))?$/.exec(r.trim());
    if (!m) continue;
    const from = Number(m[1]);
    const to = Number(m[2] ?? m[1]);
    if (from >= 1 && to <= 65535 && from <= to) out.push({ from, to });
  }
  return out;
}

/** True when no ranges are set, or the port falls inside one of them. */
export function portAllowed(port: number, ranges: readonly { from: number; to: number }[]): boolean {
  return ranges.length === 0 || ranges.some((r) => port >= r.from && port <= r.to);
}

/** Strips characters that could break out of the quoted values in a startup command. */
// eslint-disable-next-line no-control-regex -- strips control characters on purpose
export const safeText = (s: string, max: number) => s.replace(/[\u0000-\u001f"'`$\\{}<>|;&]/g, "").replace(/\s+/g, " ").trim().slice(0, max);

/** Rust player slots scale with memory. */
export function rustMaxPlayers(ramMb: number): number {
  const gb = ramMb / 1024;
  if (gb >= 32) return 300;
  if (gb >= 24) return 200;
  if (gb >= 16) return 150;
  if (gb >= 12) return 100;
  return 50;
}

export function buildEggEnvironment(defaults: Record<string, string>, ctx: EggEnvContext): Record<string, string> {
  const env = { ...defaults };
  const set = (key: string, value: string | number | undefined) => {
    if (value !== undefined && key in env) env[key] = String(value);
  };
  const name = safeText(ctx.serverName, 40) || "PlexScale server";
  const about = safeText(ctx.description, 120);
  const o = ctx.options;

  if (ctx.product === "cs2") {
    const mode = cs2Modes[o.mode ?? "competitive"];
    set("SERVER_NAME", name);
    set("RCON_PASSWORD", ctx.random.password());
    set("GAME_TYPE", mode.type);
    set("GAME_MODE", mode.mode);
    set("MAX_PLAYERS", mode.players);
    set("SRCDS_MAP", o.map ?? "de_dust2");
    set("SERVER_PASSWORD", o.password ?? "");
  } else if (ctx.product === "rust") {
    set("HOSTNAME", name);
    set("DESCRIPTION", about || "Hosted by PlexScale");
    set("SERVER_URL", "");
    set("SERVER_IMG", "");
    set("SERVER_LOGO", "");
    set("WORLD_SIZE", o.worldSize ?? 3500);
    set("WORLD_SEED", o.seed ?? ctx.random.seed());
    set("MAX_PLAYERS", rustMaxPlayers(ctx.ramMb));
    set("RCON_PASS", ctx.random.password());
    set("SAVEINTERVAL", 300);
    // Public release branch so normal Rust players can join; an admin can switch it to "staging".
    set("SRCDS_BETAID", "");
  } else if (ctx.product === "hytale") {
    set("HYTALE_PATCHLINE", o.patchline ?? "release");
    set("HYTALE_AUTH_MODE", "authenticated");
  }

  for (const [k, v] of Object.entries(ctx.adminEnv ?? {})) set(k, v);
  // Reserved ports go in by variable name, after admin values, so they always match the server's allocations.
  extraPortVariables(ctx.product, env).forEach((name, i) => set(name, ctx.ports[i]));
  // The customer's own Steam token is applied last so an admin default can never replace it.
  if (ctx.product === "cs2") set("STEAM_GSLT", o.gslt);
  return env;
}

/** Egg defaults with the admin's fixed values applied (only for variables the egg defines). */
export function withAdminEnv(defaults: Record<string, string>, adminEnv: Record<string, string> | undefined): Record<string, string> {
  const out = { ...defaults };
  for (const [k, v] of Object.entries(adminEnv ?? {})) if (k in out) out[k] = v;
  return out;
}

/** Random values for secrets in the server's startup settings. */
export function cryptoRandom() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";
  return {
    password: () => {
      const bytes = crypto.getRandomValues(new Uint8Array(24));
      return Array.from(bytes, (b) => alphabet[b % alphabet.length]).join("");
    },
    seed: () => 1 + ((crypto.getRandomValues(new Uint32Array(1))[0] ?? 1) % MAX_SEED),
  };
}

export interface FreeAllocation { id: number; ip: string; port: number }

/**
 * Picks a main port plus `extra` more on the same IP, preferring a run of
 * consecutive ports (e.g. 25000, 25001, 25002) so they are easy to read.
 */
export function pickAllocations(free: FreeAllocation[], extra: number): { primary: FreeAllocation; additional: FreeAllocation[] } | null {
  const byIp = new Map<string, FreeAllocation[]>();
  for (const a of free) byIp.set(a.ip, [...(byIp.get(a.ip) ?? []), a]);
  let fallback: { primary: FreeAllocation; additional: FreeAllocation[] } | null = null;
  for (const list of byIp.values()) {
    if (list.length < extra + 1) continue;
    const sorted = [...list].sort((a, b) => a.port - b.port);
    const byPort = new Map(sorted.map((a) => [a.port, a]));
    for (const a of sorted) {
      const run = Array.from({ length: extra }, (_, i) => byPort.get(a.port + i + 1));
      if (run.every(Boolean)) return { primary: a, additional: run as FreeAllocation[] };
    }
    fallback ??= { primary: sorted[0]!, additional: sorted.slice(1, extra + 1) };
  }
  return fallback;
}
