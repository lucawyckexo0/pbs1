import { z } from "zod";

export const ticketCategories = [
  { key: "technical", label: "Technical support" },
  { key: "billing", label: "Billing and payments" },
  { key: "sales", label: "Sales and upgrades" },
  { key: "abuse", label: "Abuse report" },
  { key: "other", label: "Something else" },
] as const;
export const ticketPriorities = [
  { key: "low", label: "Low" },
  { key: "normal", label: "Normal" },
  { key: "high", label: "High" },
  { key: "urgent", label: "Urgent (service down)" },
] as const;
export type TicketStatus = "open" | "answered" | "customer_reply" | "closed";
export const ticketStatusTone: Record<TicketStatus, string> = { open: "border-azure/50 text-azure", answered: "border-ok/50 text-ok", customer_reply: "border-steel text-muted-foreground", closed: "border-steel text-muted-foreground" };
export const ticketStatusLabel: Record<TicketStatus, string> = { open: "Open", answered: "Answered", customer_reply: "Awaiting staff", closed: "Closed" };

const categoryKeys = ticketCategories.map((c) => c.key) as [string, ...string[]];
const priorityKeys = ticketPriorities.map((p) => p.key) as [string, ...string[]];

/** Strips control characters (except line breaks and tabs) from customer text. */
// eslint-disable-next-line no-control-regex -- strips control characters on purpose
const clean = (s: string) => s.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, "").replace(/\r\n?/g, "\n");

export const ticketBody = z.string().transform(clean).pipe(z.string().trim().min(10, "Please describe the issue in at least 10 characters.").max(5000, "Keep messages under 5000 characters."));
export const replyBody = z.string().transform(clean).pipe(z.string().trim().min(1, "Write a message first.").max(5000, "Keep messages under 5000 characters."));

export const newTicketInput = z.object({
  subject: z.string().transform(clean).pipe(z.string().trim().min(3, "Add a short subject.").max(120)),
  category: z.enum(categoryKeys),
  priority: z.enum(priorityKeys),
  orderId: z.union([z.string().uuid(), z.literal("")]).optional(),
  body: ticketBody,
  /** Cloudflare Turnstile token, verified on the server. */
  turnstileToken: z.string().min(10).max(2048),
});
export type NewTicketInput = z.infer<typeof newTicketInput>;

/** Anti-spam limits. */
export const MAX_OPEN_TICKETS = 5;
export const MAX_TICKETS_PER_HOUR = 3;
export const MAX_REPLIES_PER_10_MIN = 10;
