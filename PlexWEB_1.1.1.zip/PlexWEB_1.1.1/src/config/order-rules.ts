import { z } from "zod";
import { isBilling, isProduct, type ProductKey } from "./plans";
import { softwareFor } from "./software";
import { gameOptionsInput, gameOptionsIssue } from "./game-options";
import { locationsForProduct, minecraftVersionSchema, visibleVpsOs, type SiteSettings } from "./settings";

export const SERVER_NAME_RE = /^[A-Za-z0-9][A-Za-z0-9 _.-]{2,39}$/;

export const checkoutInput = z.object({
  product: z.string().refine(isProduct, "Unknown product"),
  plan: z.string().min(1).max(40),
  billing: z.string().refine(isBilling, "Unknown billing period"),
  location: z.string().min(1).max(40).regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/),
  serverName: z.string().trim().regex(SERVER_NAME_RE, "3 to 40 letters, numbers, spaces, dots, dashes or underscores"),
  description: z.string().trim().max(160).default(""),
  software: z.string().min(1).max(40),
  version: minecraftVersionSchema.default("latest"),
  eula: z.boolean().default(false),
  /** Game-specific choices (CS2 token, Rust world, Hytale branch). */
  game: gameOptionsInput.optional(),
  /** Optional coupon code. Checked and applied on the server only. */
  coupon: z.string().trim().max(40).optional(),
}).superRefine((d, ctx) => {
  const product = d.product as ProductKey;
  // VPS operating systems are admin-editable and checked against live settings in deploymentError.
  if (product !== "vps" && !softwareFor(product).some((s) => s.key === d.software)) ctx.addIssue({ code: "custom", path: ["software"], message: "Pick a supported software" });
  if (product === "minecraft") {
    if (!d.eula) ctx.addIssue({ code: "custom", path: ["eula"], message: "You must accept the Minecraft EULA" });
  } else if (d.version !== "latest") {
    ctx.addIssue({ code: "custom", path: ["version"], message: "Version is only for Minecraft" });
  }
  const gameIssue = gameOptionsIssue(product, d.game);
  if (gameIssue) ctx.addIssue({ code: "custom", path: ["game", gameIssue.path], message: gameIssue.message });
});

export type CheckoutInput = z.infer<typeof checkoutInput>;

/** Live administrator choices are checked on the server before creating any order. */
export function deploymentError(data: Pick<CheckoutInput, "product" | "location" | "version"> & { software?: string }, settings: SiteSettings): string | null {
  if (data.product === "vps" && data.software !== undefined && !visibleVpsOs(settings).some((o) => o.key === data.software)) return "Pick a supported operating system.";
  if (!settings.locations.some((l) => l.id === data.location)) return "Unknown location. Please pick another.";
  if (!locationsForProduct(settings, data.product).some((l) => l.id === data.location)) return "That location is not offered for this product. Please pick another.";
  if (settings.ordering.disabledLocations.includes(data.location)) return "That location is out of stock. Please pick another.";
  if (data.product === "minecraft" && !settings.minecraftVersions.includes(data.version)) return "Pick a supported Minecraft version.";
  return null;
}

/** Pending checkouts a single account may open per hour, to stop order spam. */
export const MAX_PENDING_PER_HOUR = 5;

/** A service still unrenewed this many days after expiry is deleted with all its files. */
export const DELETE_AFTER_EXPIRY_DAYS = 7;

/** A refunded service's server is deleted this many hours after the refund. */
export const DELETE_AFTER_REFUND_HOURS = 24;
