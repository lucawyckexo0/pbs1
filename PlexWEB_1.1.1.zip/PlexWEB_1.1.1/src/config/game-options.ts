import { z } from "zod";

/** Counter Strike 2 match presets, as the CS2 egg's GAME_TYPE / GAME_MODE pairs. */
export const cs2Modes = {
  competitive: { label: "Competitive", type: "0", mode: "1", players: 12 },
  casual: { label: "Casual", type: "0", mode: "0", players: 20 },
  wingman: { label: "Wingman", type: "0", mode: "2", players: 6 },
  deathmatch: { label: "Deathmatch", type: "1", mode: "2", players: 16 },
  armsrace: { label: "Arms Race", type: "1", mode: "0", players: 16 },
} as const;
export type Cs2Mode = keyof typeof cs2Modes;
export const cs2Maps = ["de_dust2", "de_mirage", "de_inferno", "de_nuke", "de_ancient", "de_anubis", "de_overpass", "de_vertigo", "de_train", "cs_italy", "cs_office", "ar_baggage", "ar_shoots"] as const;
export const rustWorldSizes = [2000, 2500, 3000, 3500, 4000, 4500] as const;
export const hytalePatchlines = { release: "Release", "pre-release": "Pre-release" } as const;

/** Steam Game Server Login Token: 32 letters and numbers (CS2 egg rule alpha_num|size:32). */
export const GSLT_RE = /^[A-Za-z0-9]{32}$/;
/** Join password allowed by the CS2 egg (alpha_dash, 1 to 30). */
export const JOIN_PASSWORD_RE = /^[A-Za-z0-9_-]{1,30}$/;
export const MAX_SEED = 2_147_483_647;

/** Loose shape accepted from the browser; `gameOptionsIssue` applies the per-game rules. */
export const gameOptionsInput = z.object({
  gslt: z.string().trim().max(64).optional(),
  mode: z.string().max(20).optional(),
  map: z.string().max(40).optional(),
  password: z.string().trim().max(30).optional(),
  worldSize: z.number().int().optional(),
  seed: z.number().int().optional(),
  patchline: z.string().max(20).optional(),
}).strict();
export type GameOptionsInput = z.infer<typeof gameOptionsInput>;

export interface GameOptions {
  gslt?: string;
  mode?: Cs2Mode;
  map?: string;
  password?: string;
  worldSize?: number;
  seed?: number;
  patchline?: keyof typeof hytalePatchlines;
}

/** First problem with the options for this product, or null when they are fine. */
export function gameOptionsIssue(product: string, o: GameOptionsInput = {}): { path: string; message: string } | null {
  if (product === "cs2") {
    if (!o.gslt || !GSLT_RE.test(o.gslt)) return { path: "gslt", message: "Enter your 32 character Steam Game Server Login Token" };
    if (o.mode !== undefined && !(o.mode in cs2Modes)) return { path: "mode", message: "Pick a game mode" };
    if (o.map !== undefined && !(cs2Maps as readonly string[]).includes(o.map)) return { path: "map", message: "Pick a map from the list" };
    if (o.password && !JOIN_PASSWORD_RE.test(o.password)) return { path: "password", message: "Join password: up to 30 letters, numbers, dashes or underscores" };
  }
  if (product === "rust") {
    if (o.worldSize !== undefined && !(rustWorldSizes as readonly number[]).includes(o.worldSize)) return { path: "worldSize", message: "Pick a world size from the list" };
    if (o.seed !== undefined && (o.seed < 1 || o.seed > MAX_SEED)) return { path: "seed", message: `Map seed must be between 1 and ${MAX_SEED}` };
  }
  if (product === "hytale" && o.patchline !== undefined && !(o.patchline in hytalePatchlines)) return { path: "patchline", message: "Pick a game version" };
  return null;
}

/** Keeps only the options that belong to the product, so nothing else is ever stored. */
export function pickGameOptions(product: string, o: GameOptionsInput = {}): GameOptions {
  if (product === "cs2") {
    return {
      ...(o.gslt ? { gslt: o.gslt } : {}),
      mode: (o.mode && o.mode in cs2Modes ? o.mode : "competitive") as Cs2Mode,
      map: o.map ?? "de_dust2",
      ...(o.password ? { password: o.password } : {}),
    };
  }
  if (product === "rust") return { worldSize: o.worldSize ?? 3500, ...(o.seed ? { seed: o.seed } : {}) };
  if (product === "hytale") return { patchline: o.patchline === "pre-release" ? "pre-release" : "release" };
  return {};
}
