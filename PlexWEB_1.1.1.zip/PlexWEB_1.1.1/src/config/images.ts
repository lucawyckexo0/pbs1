import minecraft from "@/assets/img/minecraft.webp";
import hytale from "@/assets/img/hytale.webp";
import cs2 from "@/assets/img/cs2.webp";
import rust from "@/assets/img/rust.webp";
import vps from "@/assets/img/vps.webp";
import bot from "@/assets/img/bot.webp";
import epycAsset from "@/assets/img/epyc_7763.webp";
const epyc = epycAsset;
import racks from "@/assets/img/racks.webp";
import pmark from "@/assets/img/pmark.webp";
import flagIn from "@/assets/img/flag_in.webp";
import flagAe from "@/assets/img/flag_ae.webp";
import flagDe from "@/assets/img/flag_de.webp";
import flagUs from "@/assets/img/flag_us.webp";
import plexusWordmark from "@/assets/img/plexus_wordmark.webp";
import plexusVpsPanel from "@/assets/img/plexus_vps_panel.webp";
import amd from "@/assets/img/amd_epyc.webp";
import cloudflare from "@/assets/img/cloudflare.webp";
import razorpay from "@/assets/img/razorpay.webp";
import pterodactyl from "@/assets/img/pterodactyl.webp";
import azure from "@/assets/img/azure.webp";
import gcloud from "@/assets/img/googlecloud.webp";
import minecraftBlock from "@/assets/img/minecraft-block.jpg";
import hytaleLogo from "@/assets/img/hytale_logo.webp";
import cs2Logo from "@/assets/img/cs2_logo.webp";
import rustLogo from "@/assets/img/rust_logo.webp";

export const gameMenuImages = { minecraft: minecraftBlock, hytale: hytaleLogo, cs2: cs2Logo, rust: rustLogo };

export const img = {
  minecraft: minecraft,
  hytale: hytale,
  cs2: cs2,
  rust: rust,
  vps: racks, vpsArt: vps,
  bot: bot,
  epyc: epyc,
  racks: racks,
  pmark: pmark,
  plexusWordmark: plexusWordmark,
  plexusVpsPanel: plexusVpsPanel,
};

export const flags: Record<string, string> = { IN: flagIn, AE: flagAe, DE: flagDe, US: flagUs };

/** Partner logos with their trimmed aspect ratio (width / height), used to give every mark the same visual weight. */
export const partners = [
  { name: "AMD EPYC", src: amd, ratio: 6.79, boost: "" },
  { name: "Cloudflare", src: cloudflare, ratio: 7.18, boost: "" },
  { name: "Razorpay", src: razorpay, ratio: 4.65, boost: "brightness-200" },
  { name: "Pterodactyl", src: pterodactyl, ratio: 3.83, boost: "" },
  { name: "Microsoft Azure", src: azure, ratio: 1.06, boost: "brightness-150" },
  { name: "Google Cloud", src: gcloud, ratio: 6.33, boost: "brightness-150" },
  { name: "Plexus", src: plexusWordmark, ratio: 5.14, boost: "" },
];

/** Equal optical area for logos of any shape: wide wordmarks get shorter, square marks get taller (capped). */
export function partnerLogoSize(ratio: number, area = 3400, maxHeight = 38) {
  const height = Math.min(maxHeight, Math.sqrt(area / ratio));
  return { width: Math.round(height * ratio), height: Math.round(height) };
}
