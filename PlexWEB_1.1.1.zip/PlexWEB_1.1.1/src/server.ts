import "./lib/error-capture";

import { consumeLastCapturedError } from "./lib/error-capture";
import { renderErrorPage } from "./lib/error-page";
import { apiOrigin, buildCsp } from "./lib/csp";

type ServerEntry = {
  fetch: (request: Request, env: unknown, ctx: unknown) => Promise<Response> | Response;
};

let serverEntryPromise: Promise<ServerEntry> | undefined;

async function getServerEntry(): Promise<ServerEntry> {
  if (!serverEntryPromise) {
    serverEntryPromise = import("@tanstack/react-start/server-entry").then(
      (m) => (m.default ?? m) as ServerEntry,
    );
  }
  return serverEntryPromise;
}

// h3 swallows in-handler throws into a normal 500 Response with body
// {"unhandled":true,"message":"HTTPError"} — try/catch alone never fires for those.
async function normalizeCatastrophicSsrResponse(response: Response): Promise<Response> {
  if (response.status < 500) return response;
  const contentType = response.headers.get("content-type") ?? "";
  if (!contentType.includes("application/json")) return response;

  const body = await response.clone().text();
  if (!isH3SwallowedErrorBody(body)) return response;

  console.error(consumeLastCapturedError() ?? new Error(`h3 swallowed SSR error: ${body}`));
  return new Response(renderErrorPage(), {
    status: 500,
    headers: { "content-type": "text/html; charset=utf-8" },
  });
}

function isH3SwallowedErrorBody(body: string): boolean {
  try {
    const payload = JSON.parse(body) as { unhandled?: unknown; message?: unknown };
    return payload.unhandled === true && payload.message === "HTTPError";
  } catch {
    return false;
  }
}

// Production Content-Security-Policy (src/lib/csp.ts). connect-src names the API host from
// VITE_SUPABASE_URL (for example https://api.example.com) instead of a wildcard.
// Development keeps a relaxed policy for hot reload.
const API_ORIGIN = apiOrigin(process.env["VITE_SUPABASE_URL"]);
const csp = (nonce: string) => buildCsp(nonce, API_ORIGIN);

const NONCE_HEADER = "x-plexscale-csp-nonce";
function newNonce() {
  const b = crypto.getRandomValues(new Uint8Array(16));
  let s = "";
  for (const x of b) s += String.fromCharCode(x);
  return btoa(s);
}

function applySecurityHeaders(response: Response, nonce: string): Response {
  // Redirects and opaque responses keep their own headers.
  if (response.status >= 300 && response.status < 400) return response;
  const headers = new Headers(response.headers);
  for (const h of ["x-powered-by", "server", "via"]) headers.delete(h);
  headers.set("X-Content-Type-Options", "nosniff");
  headers.set("Referrer-Policy", "strict-origin-when-cross-origin");
  headers.set("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=(self \"https://checkout.razorpay.com\" \"https://api.razorpay.com\")");
  headers.set("Cross-Origin-Opener-Policy", "same-origin-allow-popups");
  headers.set("X-DNS-Prefetch-Control", "off");
  if (import.meta.env.PROD) {
    if (!headers.has("Content-Security-Policy")) headers.set("Content-Security-Policy", csp(nonce));
    headers.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
    headers.set("Cross-Origin-Resource-Policy", "same-origin");
    headers.set("X-Frame-Options", "DENY");
  }
  return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
}

// Framework-level failures on the RPC path (bad payloads, wrong method) get a plain reply.
const RPC_PREFIX = "/_px/";
const INTERNAL_TEXT = /seroval|expected (get|post) method|invariant|stack|serverfn|tanstack/i;
async function scrubRpcError(request: Request, response: Response): Promise<Response> {
  if (response.status < 400 || !new URL(request.url).pathname.startsWith(RPC_PREFIX)) return response;
  const body = await response.clone().text();
  if (!INTERNAL_TEXT.test(body)) return response;
  return new Response("Bad request", { status: response.status >= 500 ? 500 : 400, headers: { "content-type": "text/plain; charset=utf-8" } });
}

// Cloudflare compresses responses at its edge. Never compress a body (gzip, brotli,
// CompressionStream) or set content-encoding here or in a server route.
const app = {
  async fetch(request: Request, env: unknown, ctx: unknown) {
    const nonce = newNonce();
    try {
      const handler = await getServerEntry();
      // Always overwrite: a client-sent nonce header must never reach the renderer.
      const headers = new Headers(request.headers);
      headers.set(NONCE_HEADER, nonce);
      const hasBody = request.method !== "GET" && request.method !== "HEAD";
      const forwarded = new Request(request.url, {
        method: request.method, headers, redirect: request.redirect, signal: request.signal,
        ...(hasBody ? { body: request.body, duplex: "half" } : {}),
      } as RequestInit);
      const response = await handler.fetch(forwarded, env, ctx);
      return applySecurityHeaders(await scrubRpcError(request, await normalizeCatastrophicSsrResponse(response)), nonce);
    } catch (error) {
      console.error(error);
      return applySecurityHeaders(new Response(renderErrorPage(), {
        status: 500,
        headers: { "content-type": "text/html; charset=utf-8" },
      }), nonce);
    }
  },
};

export default app;

