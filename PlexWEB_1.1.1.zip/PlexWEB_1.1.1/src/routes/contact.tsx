import { createFileRoute } from "@tanstack/react-router";
import { SupportOptions } from "@/components/sections/common";
import { site } from "@/config/site";

export const Route = createFileRoute("/contact")({
  head: () => ({ meta: [
    { title: "Contact | PlexScale" },
    { name: "description", content: "Reach PlexScale support with an on-site ticket, on Discord or by email." },
    { property: "og:title", content: "Contact PlexScale" },
    { property: "og:description", content: "Open a support ticket, or talk to the PlexScale team on Discord or by email." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: Contact,
});

function Contact() {
  return (
    <section className="section container-px">
      <p className="eyebrow">Contact</p>
      <h1 className="mt-3 text-4xl md:text-5xl">Talk to us</h1>
      <p className="mt-4 max-w-xl text-muted-foreground">{site.responseTime}. Signed-in customers can open a private support ticket right here on the site.</p>
      <SupportOptions className="mt-10" />
    </section>
  );
}
