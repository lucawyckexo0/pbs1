import { createFileRoute } from "@tanstack/react-router";
import { GamePage } from "@/components/sections/GamePage";
import { homeFaq } from "@/config/faq";
import { img } from "@/config/images";
import { formatINR, fromPrice, gamePlans } from "@/config/plans";

const from = formatINR(fromPrice(gamePlans("rust")));

export const Route = createFileRoute("/rust")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { title: "Rust server hosting | PlexScale" },
      { name: "description", content: `Rust servers on AMD EPYC with NVMe storage from ${from} a month, GST included.` },
      { property: "og:title", content: "Rust server hosting | PlexScale" },
      { property: "og:description", content: `Rust servers on AMD EPYC with NVMe storage from ${from} a month, GST included.` },
    ],
  }),
  component: () => (
    <GamePage game="rust" name="Rust" image={img.rust} sub="Survive, build and raid with your clan. Fast EPYC servers, set up for you in minutes." software={["Rust dedicated server", "Oxide plugins", "Procedural maps"]} faq={homeFaq} />
  ),
});
