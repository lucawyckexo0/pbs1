import { createFileRoute } from "@tanstack/react-router";

// Internal only (see src/lib/internal-jobs.server.ts). Hourly backstop: finds Razorpay payments whose webhook never arrived, expires unpaid coupon checkouts,
// and retries server setups that failed (each failure is already an admin alert). Idempotent.
export const Route = createFileRoute("/api/internal/jobs/reconcile-payments")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { authenticateInternalJob } = await import("@/lib/internal-jobs.server");
        const authFailure = await authenticateInternalJob(request);
        if (authFailure) return authFailure;
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const { rzp, confirmRazorpayPayment, markPaid, provisionOrder, razorpayConfigured } = await import("@/lib/billing.server");
        const { logEvent } = await import("@/lib/log");
        const now = Date.now();
        let recovered = 0;
        let expired = 0;
        let retried = 0;

        if (razorpayConfigured()) {
          const { data: open } = await supabaseAdmin.from("orders")
            .select("id, amount, status, razorpay_order_id, coupon_id, created_at")
            .in("status", ["pending", "failed"]).is("razorpay_payment_id", null).not("razorpay_order_id", "is", null).eq("paid_with", "razorpay")
            .lt("created_at", new Date(now - 10 * 60_000).toISOString()).gt("created_at", new Date(now - 3 * 864e5).toISOString())
            .order("created_at", { ascending: true }).limit(50);
          for (const o of open ?? []) {
            try {
              const list = await rzp(`/orders/${encodeURIComponent(o.razorpay_order_id!)}/payments`);
              const items = (list["items"] as { id?: string; amount?: number; currency?: string; status?: string }[] | undefined) ?? [];
              const paid = items.find((p) => p.id && (p.status === "captured" || p.status === "authorized") && Number(p.amount) === o.amount * 100 && p.currency === "INR");
              if (paid?.id) {
                await confirmRazorpayPayment(paid.id, o.razorpay_order_id!, o.amount);
                await markPaid(o.id, paid.id);
                logEvent("warn", "reconcile.recovered_payment", { orderId: o.id });
                recovered++;
              } else if (o.status === "pending" && o.coupon_id && Date.parse(o.created_at) < now - 3600_000) {
                // Unpaid coupon checkouts give their coupon use back after an hour.
                const { data: closed } = await supabaseAdmin.from("orders").update({ status: "failed" }).eq("id", o.id).eq("status", "pending").is("razorpay_payment_id", null).select("id").maybeSingle();
                if (closed) expired++;
              }
            } catch (e) {
              logEvent("error", "reconcile.payment_check_failed", { orderId: o.id, message: e instanceof Error ? e.message : String(e) });
            }
          }
        }

        // Credit payments whose completion was interrupted after the balance was taken.
        let creditsCompleted = 0;
        try {
          const { completeInterruptedCreditPayments } = await import("@/lib/billing.server");
          creditsCompleted = await completeInterruptedCreditPayments();
        } catch (e) {
          logEvent("error", "reconcile.credits_failed", { message: e instanceof Error ? e.message : String(e) });
        }

        // Retry queue: paid orders whose server setup failed get up to 5 automatic attempts.
        const { data: stuck } = await supabaseAdmin.from("orders").select("id")
          .eq("kind", "new").eq("status", "provisioning").lt("provision_attempts", 5)
          .lt("updated_at", new Date(now - 10 * 60_000).toISOString()).limit(20);
        for (const o of stuck ?? []) {
          const r = await provisionOrder(o.id);
          retried++;
          logEvent(r.ok ? "info" : "warn", "reconcile.provision_retry", { orderId: o.id, ok: r.ok });
        }
        return Response.json({ recovered, expired, retried, creditsCompleted });
      },
    },
  },
});
