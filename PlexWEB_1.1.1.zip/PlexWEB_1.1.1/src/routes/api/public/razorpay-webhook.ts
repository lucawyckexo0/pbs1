import { createFileRoute } from "@tanstack/react-router";

// Razorpay calls this after a payment, so orders complete even if the customer closes the tab.
export const Route = createFileRoute("/api/public/razorpay-webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { hitRateLimit, requestIp } = await import("@/lib/rate-limit.server");
        const ip = requestIp(request);
        if (ip && !(await hitRateLimit(`webhook:ip:${ip}`, 300, 60))) return new Response("Too many requests", { status: 429 });
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const { markPaid } = await import("@/lib/billing.server");
        const { handleRazorpayWebhook } = await import("@/lib/razorpay-webhook");
        const { logEvent } = await import("@/lib/log");
        return handleRazorpayWebhook(request, {
          secret: process.env["RAZORPAY_WEBHOOK_SECRET"],
          recordEvent: async (eventId, event) => {
            const { error } = await supabaseAdmin.from("webhook_events").insert({ event_id: eventId, event });
            if (!error) return "new";
            if (error.code === "23505") return "duplicate";
            throw new Error("Webhook event could not be recorded.");
          },
          forgetEvent: async (eventId) => { await supabaseAdmin.from("webhook_events").delete().eq("event_id", eventId); },
          findOrder: async (rzpOrderId) => (await supabaseAdmin.from("orders").select("id, amount, status, razorpay_payment_id").eq("razorpay_order_id", rzpOrderId).maybeSingle()).data,
          markPaid,
          log: logEvent,
        });
      },
    },
  },
});
