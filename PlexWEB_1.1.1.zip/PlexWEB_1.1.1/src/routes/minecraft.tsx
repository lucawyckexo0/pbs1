import { createFileRoute } from "@tanstack/react-router";
import { GamePage } from "@/components/sections/GamePage";
import { homeFaq } from "@/config/faq";
import { img } from "@/config/images";

export const Route = createFileRoute("/minecraft")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { title: "Minecraft server hosting in India | PlexScale" },
      { name: "description", content: "Minecraft servers from ₹149 a month, GST included. PaperMC, Fabric, Forge, SpigotMC, NeoForge and Vanilla on AMD EPYC 7763." },
      { property: "og:title", content: "Minecraft server hosting in India | PlexScale" },
      { property: "og:description", content: "Minecraft servers from ₹149 a month, GST included. PaperMC, Fabric, Forge, SpigotMC, NeoForge and Vanilla on AMD EPYC 7763." },
    ],
  }),
  component: () => (
    <GamePage game="minecraft" name="Minecraft" image={img.minecraft} sub="PaperMC, Fabric, Forge and more on AMD EPYC with NVMe storage. Live in about a minute." software={["PaperMC","Fabric","Forge","SpigotMC","NeoForge","Vanilla"]} faq={homeFaq} />
  ),
});
