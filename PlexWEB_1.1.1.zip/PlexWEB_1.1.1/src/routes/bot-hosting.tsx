import { createFileRoute } from "@tanstack/react-router";
import { btn } from "@/components/ui-px/btn";
import { ClosingBanner, FaqSection, PageHero, SectionHead } from "@/components/sections/common";
import { PlanGrid } from "@/components/sections/pricing";
import { img } from "@/config/images";
import { botPlans } from "@/config/plans";

const title = "Discord bot hosting in India | PlexScale";
const desc = "Host Node.js and Python Discord bots from ₹49 a month. Always online, GST included.";

export const Route = createFileRoute("/bot-hosting")({
  head: () => ({ meta: [{ property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }, { title }, { name: "description", content: desc }, { property: "og:title", content: title }, { property: "og:description", content: desc }] }),
  component: Bot,
});

const runtimes = [
  { t: "Node.js", b: "discord.js, Eris and friends. Install packages from package.json, set your start file and go." },
  { t: "Python", b: "discord.py, nextcord, py-cord. Dependencies install from requirements.txt on start." },
];

function Bot() {
  return (
    <>
      <PageHero eyebrow="Discord bot hosting" title="Your bot, online around the clock" sub="Upload your code, set your token and let it run. Node.js and Python supported out of the box." image={img.bot}>
        <a href="#plans" className={btn({ size: "lg" })}>Deploy a server</a>
      </PageHero>
      <PlanGrid plans={botPlans} kind="bot" title="Bot plans" features={["Node.js and Python", "Live console and file manager", "DDoS protection, up to 480 Gbps"]} />
      <section className="section container-px">
        <SectionHead eyebrow="Runtimes" title="Node.js and Python, ready" />
        <div className="mt-10 grid gap-6 md:grid-cols-2">
          {runtimes.map((r) => (
            <div key={r.t} className="panel p-8">
              <h3 className="text-xl font-semibold">{r.t}</h3>
              <p className="mt-2 text-muted-foreground">{r.b}</p>
            </div>
          ))}
        </div>
      </section>
      <FaqSection items={[
        { q: "Where do I put my bot token?", a: "Add it as an environment variable in the panel so it never sits in your code." },
        { q: "Can I get a refund on bot hosting?", a: "No. Refunds are available only for eligible new game-hosting orders, within 24 hours of payment. Renewals are not refundable." },
        { q: "Will my bot restart if it crashes?", a: "Yes. The panel can restart it automatically." },
        { q: "Do plans renew automatically?", a: "No. We send reminder emails before your plan is due." },
      ]} />
      <ClosingBanner />
    </>
  );
}
