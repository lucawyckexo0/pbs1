import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { ShieldCheck } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { TurnstileBox, type TurnstileHandle } from "@/components/security/TurnstileBox";
import { getTurnstileConfig, verifyHuman } from "@/lib/turnstile.functions";
import { supabase } from "@/integrations/supabase/client";
import { Spinner } from "@/components/ui-px/Spinner";
import { btn } from "@/components/ui-px/btn";
import { cn } from "@/lib/utils";

const KEY = "px-after-auth";
const safe = (p?: string) => {
// eslint-disable-next-line no-control-regex -- strips control characters on purpose
  if (!p || !p.startsWith("/") || p.startsWith("//") || p.startsWith("/\\") || /[\\\u0000-\u001f]/.test(p)) return "/billing";
  try {
    const resolved = new URL(p, typeof window === "undefined" ? "https://plexscale.invalid" : window.location.origin);
    return resolved.origin === (typeof window === "undefined" ? "https://plexscale.invalid" : window.location.origin)
      ? `${resolved.pathname}${resolved.search}${resolved.hash}`
      : "/billing";
  } catch { return "/billing"; }
};

export const Route = createFileRoute("/auth")({
  loader: () => getTurnstileConfig(),
  validateSearch: (s: Record<string, unknown>): { redirect?: string | undefined } => ({ redirect: typeof s["redirect"] === "string" ? s["redirect"] : undefined }),
  head: () => ({ meta: [
    { title: "Sign in | PlexScale" },
    { name: "description", content: "Sign in or create your PlexScale account with Google or Discord." },
    { property: "og:title", content: "Sign in | PlexScale" },
    { property: "og:description", content: "Sign in or create your PlexScale account." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: AuthPage,
});

function GoogleMark() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" width={18} height={18} className="!size-[18px]"><path fill="#4285F4" d="M23.49 12.27c0-.79-.07-1.54-.19-2.27H12v4.51h6.47c-.29 1.48-1.14 2.73-2.4 3.58v3h3.86c2.26-2.09 3.56-5.17 3.56-8.82z"/><path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.86-3c-1.08.72-2.45 1.16-4.07 1.16-3.13 0-5.78-2.11-6.73-4.96H1.29v3.09C3.26 21.3 7.31 24 12 24z"/><path fill="#FBBC05" d="M5.27 14.29c-.25-.72-.38-1.49-.38-2.29s.14-1.57.38-2.29V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.98-3.09z"/><path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.98 3.09c.95-2.85 3.6-4.96 6.73-4.96z"/></svg>
  );
}

function AuthPage() {
  const { redirect } = Route.useSearch();
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const { siteKey } = Route.useLoaderData();
  const verify = useServerFn(verifyHuman);
  const [token, setToken] = useState<string | null>(null);
  const [widgetError, setWidgetError] = useState(false);
  const turnstile = useRef<TurnstileHandle>(null);

  /** Spends the single-use token on the server, then resets the widget for any later attempt. */
  const passCheck = useCallback(async () => {
    const t = token;
    turnstile.current?.reset();
    if (!t) return false;
    try { return (await verify({ data: { token: t } })).ok; } catch { return false; }
  }, [token, verify]);

  useEffect(() => {
    if (redirect) sessionStorage.setItem(KEY, safe(redirect));
    const go = () => {
      const to = safe(sessionStorage.getItem(KEY) ?? undefined);
      sessionStorage.removeItem(KEY);
      navigate({ to, replace: true });
    };
    supabase.auth.getSession().then(({ data }) => data.session && go()).catch(() => setError("Sign-in is temporarily unavailable. Please try again later."));
    const { data } = supabase.auth.onAuthStateChange((e, s) => { if (e === "SIGNED_IN" && s) go(); });
    return () => data.subscription.unsubscribe();
  }, [redirect, navigate]);

  /** Starts Google or Discord sign-in through the PlexScale auth server (no email or one-time-code sign-in). */
  async function signIn(provider: "google" | "discord") {
    if (!token || !siteKey) return;
    setBusy(true); setError(null);
    if (!(await passCheck())) { setError("Security check failed. Please complete it again."); setBusy(false); return; }
    try {
      // Returns to the public /auth page, which forwards to the saved destination.
      const { error: authError } = await supabase.auth.signInWithOAuth({ provider, options: { redirectTo: `${window.location.origin}/auth` } });
      if (authError) throw authError;
    } catch {
      setError("Sign-in could not start. Please try again."); setBusy(false);
    }
  }

  return (
    <section className="section container-px flex min-h-[70vh] flex-col items-center justify-center gap-4">
      <div className="panel w-full max-w-md p-8">
        <h1 className="text-3xl">Sign in to PlexScale</h1>
        <p className="mt-3 text-sm text-muted-foreground">New here? Signing in creates your account. No passwords to remember.</p>
        <p className={cn("mt-6 flex items-center gap-1.5 text-xs", token ? "text-ok" : widgetError ? "text-destructive" : "text-muted-foreground")} aria-live="polite">
          <ShieldCheck className="size-3.5" />
          {!siteKey ? "Sign-in is unavailable right now. Please try again later." : token ? "Verified. You can sign in now." : widgetError ? "The security check could not load. Refresh the page to try again." : "Complete the security check to continue."}
        </p>
        <div className="mt-3">
          {siteKey && <TurnstileBox ref={turnstile} siteKey={siteKey} action="login" onToken={(t) => { setToken(t); if (t) setWidgetError(false); }} onError={() => setWidgetError(true)} />}
        </div>
        <button type="button" onClick={() => void signIn("google")} disabled={busy || !token} className="google-btn mt-4 flex h-12 w-full items-center justify-center gap-[10px] rounded-md px-3 text-sm font-medium transition-opacity disabled:cursor-not-allowed disabled:opacity-50">
          {busy ? <Spinner size="xs" /> : <GoogleMark />} Continue with Google
        </button>
        <button type="button" onClick={() => void signIn("discord")} disabled={busy || !token} className={cn(btn({ size: "lg", variant: "secondary" }), "mt-3 w-full")}>
          <svg viewBox="0 0 24 24" aria-hidden className="!size-5 fill-current"><path d="M20.3 4.4A19.8 19.8 0 0 0 15.4 3l-.6 1.3a18.3 18.3 0 0 0-5.6 0L8.6 3a19.7 19.7 0 0 0-4.9 1.5C.6 9.1-.3 13.6.1 18.1a19.9 19.9 0 0 0 6 3l1.3-2a12.9 12.9 0 0 1-2-1l.5-.4a14.2 14.2 0 0 0 12.2 0l.5.4c-.6.4-1.3.7-2 1l1.3 2a19.8 19.8 0 0 0 6-3c.5-5.2-.8-9.7-3.6-13.7ZM8 15.3c-1.2 0-2.2-1.1-2.2-2.4S6.8 10.5 8 10.5s2.2 1.1 2.2 2.4-1 2.4-2.2 2.4Zm8 0c-1.2 0-2.2-1.1-2.2-2.4s1-2.4 2.2-2.4 2.2 1.1 2.2 2.4-1 2.4-2.2 2.4Z"/></svg>
          Continue with Discord
        </button>
        {error && <p role="alert" className="mt-4 text-sm text-destructive">{error}</p>}
        <p className="mt-6 text-xs text-muted-foreground">By continuing you agree to our Terms of Service and Privacy Policy.</p>
      </div>
    </section>
  );
}
