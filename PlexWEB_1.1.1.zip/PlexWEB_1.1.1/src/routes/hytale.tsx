import { createFileRoute } from "@tanstack/react-router";
import { GamePage } from "@/components/sections/GamePage";
import { homeFaq } from "@/config/faq";
import { img } from "@/config/images";

export const Route = createFileRoute("/hytale")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { title: "Hytale server hosting | PlexScale" },
      { name: "description", content: "Hytale servers on AMD EPYC 7763 with NVMe storage. INR pricing with GST included." },
      { property: "og:title", content: "Hytale server hosting | PlexScale" },
      { property: "og:description", content: "Hytale servers on AMD EPYC 7763 with NVMe storage. INR pricing with GST included." },
    ],
  }),
  component: () => (
    <GamePage game="hytale" name="Hytale" image={img.hytale} sub="Get your Hytale world online on tuned EPYC hardware, close to your players." software={["Hytale dedicated server","Custom mods","Plugins"]} faq={homeFaq} />
  ),
});
