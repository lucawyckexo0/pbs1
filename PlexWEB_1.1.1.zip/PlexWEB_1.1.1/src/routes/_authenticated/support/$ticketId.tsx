import { askConfirm } from "@/components/ui-px/ConfirmHost";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ArrowLeft, Headset, User } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { btn } from "@/components/ui-px/btn";
import { PageLoader, Spinner } from "@/components/ui-px/Spinner";
import { replyBody, ticketCategories, ticketStatusLabel, ticketStatusTone as statusTone, type TicketStatus } from "@/config/support";
import { supabase } from "@/integrations/supabase/client";
import { closeMyTicket, markTicketRead, replyTicket } from "@/lib/support.functions";
import { cn } from "@/lib/utils";
import { shownError } from "@/lib/public-error";

export const Route = createFileRoute("/_authenticated/support/$ticketId")({
  head: () => ({ meta: [
    { title: "Support ticket | PlexScale" },
    { name: "description", content: "Your conversation with the PlexScale support team." },
    { property: "og:title", content: "Support ticket | PlexScale" },
    { property: "og:description", content: "Your conversation with PlexScale support." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
    { name: "robots", content: "noindex" },
  ] }),
  component: Ticket,
});

const when = (s: string) => new Date(s).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" });

function Ticket() {
  const { ticketId } = Route.useParams();
  const qc = useQueryClient();
  const reply = useServerFn(replyTicket);
  const close = useServerFn(closeMyTicket);
  const markRead = useServerFn(markTicketRead);
  const [body, setBody] = useState("");
  const [busy, setBusy] = useState(false);
  const bottom = useRef<HTMLDivElement>(null);
  const valid = /^[0-9a-f-]{36}$/i.test(ticketId);
  const { data, isLoading } = useQuery({
    queryKey: ["ticket", ticketId],
    enabled: valid,
    queryFn: async () => {
      const [t, m] = await Promise.all([
        supabase.from("support_tickets").select("id, number, subject, category, priority, status, created_at").eq("id", ticketId).maybeSingle(),
        supabase.from("ticket_messages").select("id, is_staff, body, created_at").eq("ticket_id", ticketId).order("created_at", { ascending: true }).limit(500),
      ]);
      return { ticket: t.data, messages: m.data ?? [] };
    },
    refetchInterval: 20_000,
  });
  const count = data?.messages.length ?? 0;
  useEffect(() => { if (data?.ticket) void markRead({ data: { ticketId } }).then(() => qc.invalidateQueries({ queryKey: ["my-tickets"] })).catch(() => undefined); }, [count, data?.ticket, ticketId, markRead, qc]);
  useEffect(() => { bottom.current?.scrollIntoView({ block: "end" }); }, [count]);

  if (!valid) return <NotFoundTicket />;
  if (isLoading) return <PageLoader text="Loading your ticket" />;
  if (!data?.ticket) return <NotFoundTicket />;
  const t = data.ticket;
  const closed = t.status === "closed";

  async function send(e: React.FormEvent) {
    e.preventDefault();
    const check = replyBody.safeParse(body);
    if (!check.success) { toast.error(check.error.issues[0]?.message ?? "Write a message first."); return; }
    setBusy(true);
    try {
      await reply({ data: { ticketId, body } });
      setBody("");
      await qc.invalidateQueries({ queryKey: ["ticket", ticketId] });
    } catch (err) {
      toast.error(shownError(err, "Could not send your reply."));
    }
    setBusy(false);
  }

  async function doClose() {
    if (!(await askConfirm("Close this ticket? You can still reply later to reopen it."))) return;
    try { await close({ data: { ticketId } }); await qc.invalidateQueries({ queryKey: ["ticket", ticketId] }); toast.success("Ticket closed"); } catch { toast.error("Could not close the ticket."); }
  }

  return (
    <section className="section container-px max-w-3xl">
      <Link to="/support" className={cn(btn({ variant: "text" }), "-ml-2")}><ArrowLeft />All tickets</Link>
      <div className="mt-4 flex flex-wrap items-start justify-between gap-4">
        <div className="min-w-0">
          <p className="eyebrow">Ticket #{t.number}</p>
          <h1 className="mt-2 break-words text-3xl">{t.subject}</h1>
          <p className="mt-2 text-sm text-muted-foreground">{ticketCategories.find((c) => c.key === t.category)?.label} · Priority {t.priority} · Opened {when(t.created_at)}</p>
        </div>
        <div className="flex items-center gap-2">
          <span className={cn("rounded-full border px-3 py-1 text-xs font-semibold", statusTone[t.status as TicketStatus])}>{ticketStatusLabel[t.status as TicketStatus] ?? t.status}</span>
          {!closed && <button type="button" onClick={doClose} className={btn({ variant: "text" })}>Close ticket</button>}
        </div>
      </div>

      <ol className="mt-8 space-y-4">
        {data.messages.map((m) => (
          <li key={m.id} className={cn("panel p-5", m.is_staff && "border-azure/50 bg-azure-deep/40")}>
            <p className="flex items-center gap-2 text-sm font-semibold">
              {m.is_staff ? <Headset className="size-4 text-azure" /> : <User className="size-4 text-muted-foreground" />}
              {m.is_staff ? "PlexScale Support" : "You"}
              <span className="font-normal text-muted-foreground">· {when(m.created_at)}</span>
            </p>
            <p className="mt-3 whitespace-pre-wrap break-words text-sm leading-relaxed">{m.body}</p>
          </li>
        ))}
      </ol>
      <div ref={bottom} />

      <form onSubmit={send} className="panel mt-6 grid gap-3 p-5">
        <label htmlFor="reply" className="text-sm font-semibold">{closed ? "Reply to reopen this ticket" : "Your reply"}</label>
        <textarea id="reply" value={body} onChange={(e) => setBody(e.target.value)} rows={5} maxLength={5000} placeholder="Write your message" className="w-full rounded-md border border-steel bg-ink px-3 py-3 text-sm focus:border-azure focus:outline-none" />
        <div className="flex items-center justify-between gap-3">
          <span className="text-xs text-muted-foreground">We’ll email you when the team replies.</span>
          <button type="submit" disabled={busy || !body.trim()} className={btn()}>{busy && <Spinner size="xs" />}{busy ? "Sending" : "Send reply"}</button>
        </div>
      </form>
    </section>
  );
}

function NotFoundTicket() {
  return (
    <section className="section container-px max-w-3xl">
      <h1 className="text-3xl">Ticket not found</h1>
      <p className="mt-3 text-muted-foreground">It may have been removed, or it belongs to a different account.</p>
      <Link to="/support" className={cn(btn(), "mt-6")}>Back to tickets</Link>
    </section>
  );
}
