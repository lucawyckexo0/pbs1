import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Check } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { btn } from "@/components/ui-px/btn";
import { BillingToggle } from "@/components/sections/pricing";
import { billingPeriods, cpuLabel, formatINR, isBilling, isGame, isProduct, periodTotal, planLines, productNames, type Billing, type ProductKey } from "@/config/plans";
import { locationsForProduct, visibleVpsOs, vpsOsLabel } from "@/config/settings";
import { PlanLine } from "@/components/sections/pricing";
import { checkoutInput, deploymentError, SERVER_NAME_RE } from "@/config/order-rules";
import { flags } from "@/config/images";
import { cs2Maps, cs2Modes, GSLT_RE, hytalePatchlines, MAX_SEED, rustWorldSizes, type GameOptionsInput } from "@/config/game-options";
import { Button } from "@/components/ui/button";
import { softwareFor, type SoftwareOption } from "@/config/software";
import { usePlans, useSettings } from "@/hooks/use-settings";
import { createCheckout, previewCoupon, verifyPayment } from "@/lib/orders.functions";
import { usePaymentFlow } from "@/components/payment/PaymentFlow";
import { Spinner } from "@/components/ui-px/Spinner";
import { PayChoice } from "@/components/billing/PayChoice";
import { inputCls } from "@/components/ui-px/form";
import { useCredits } from "@/hooks/use-credits";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";
import { shownError } from "@/lib/public-error";

type Search = { product?: string | undefined; plan?: string | undefined; billing?: string | undefined; location?: string | undefined };

export const Route = createFileRoute("/_authenticated/deploy/")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    product: typeof s["product"] === "string" ? s["product"] : undefined,
    plan: typeof s["plan"] === "string" ? s["plan"] : undefined,
    billing: typeof s["billing"] === "string" ? s["billing"] : undefined,
    location: typeof s["location"] === "string" ? s["location"] : undefined,
  }),
  head: () => ({ meta: [
    { title: "Deploy a server | PlexScale" },
    { name: "description", content: "Configure your PlexScale server: location, software, version and name, then pay securely with Razorpay." },
    { property: "og:title", content: "Deploy a server | PlexScale" },
    { property: "og:description", content: "Configure and deploy your server." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
    { name: "robots", content: "noindex" },
  ] }),
  component: Deploy,
});

const choice = "h-auto w-full cursor-pointer whitespace-normal rounded-md border p-4 text-left text-foreground transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50";
const choiceOn = "border-azure bg-azure/10";
const choiceOff = "border-steel bg-ink/40 hover:border-azure/60 hover:bg-accent/40";
const field = cn(inputCls, "h-11");

function Step({ n, title, children }: { n: number; title: string; children: React.ReactNode }) {
  return (
    <section className="panel p-6">
      <h2 className="flex items-center gap-3 text-xl"><span className="flex size-8 items-center justify-center rounded-md border border-azure/40 bg-azure/15 font-display text-sm text-azure-bright">{n}</span>{title}</h2>
      <div className="mt-5">{children}</div>
    </section>
  );
}

function Deploy() {
  const search = Route.useSearch();
  const product: ProductKey = isProduct(search.product) ? search.product : "minecraft";
  if (!isProduct(search.product)) return <EmptyCart />;
  return <DeployForm key={product} product={product} search={search} />;
}

function EmptyCart() {
  return (
    <section className="section container-px">
      <p className="eyebrow">Deploy</p>
      <h1 className="mt-3 text-4xl">Pick a plan first</h1>
      <p className="mt-4 text-muted-foreground">Choose a game or service, then come back here to set it up.</p>
      <div className="mt-8 flex flex-wrap gap-3">
        <Link to="/minecraft" className={btn({ size: "lg" })}>Minecraft plans</Link>
        <Link to="/" className={btn({ size: "lg", variant: "secondary" })}>All products</Link>
      </div>
    </section>
  );
}

function DeployForm({ product, search }: { product: ProductKey; search: Search }) {
  const navigate = useNavigate();
  const create = useServerFn(createCheckout);
  const verify = useServerFn(verifyPayment);
  const checkCoupon = useServerFn(previewCoupon);
  const settings = useSettings();
  const plans = usePlans(product);
  const locations = useMemo(() => locationsForProduct(settings, product), [settings, product]);
  const minecraftVersions = settings.minecraftVersions;
  const openLocations = useMemo(() => locations.filter((l) => !settings.ordering.disabledLocations.includes(l.id)), [locations, settings.ordering.disabledLocations]);
  const software = useMemo<SoftwareOption[]>(() => product === "vps" ? visibleVpsOs(settings).map((o) => ({ key: o.key, label: vpsOsLabel(o), hint: o.hint })) : softwareFor(product), [product, settings]);

  const [planId, setPlanId] = useState(plans.find((p) => p.id === search.plan)?.id ?? plans[0]?.id ?? "");
  const [billing, setBilling] = useState<Billing>(isBilling(search.billing) ? search.billing : "monthly");
  const [location, setLocation] = useState(openLocations.find((l) => l.id === search.location)?.id ?? openLocations[0]?.id ?? "");
  const [soft, setSoft] = useState(software[0]?.key ?? "");
  const [version, setVersion] = useState("latest");
  const [serverName, setServerName] = useState("");
  const [description, setDescription] = useState("");
  const [eula, setEula] = useState(false);
  const [gslt, setGslt] = useState("");
  const [cs2Mode, setCs2Mode] = useState<string>("competitive");
  const [cs2Map, setCs2Map] = useState<string>("de_dust2");
  const [joinPassword, setJoinPassword] = useState("");
  const [worldSize, setWorldSize] = useState<number>(3500);
  const [seed, setSeed] = useState("");
  const [patchline, setPatchline] = useState<string>("release");
  const payment = usePaymentFlow();
  const credits = useCredits();
  const busy = payment.busy;
  const [error, setError] = useState<string | null>(null);
  const [touched, setTouched] = useState(false);
  const [couponCode, setCouponCode] = useState("");
  const [coupon, setCoupon] = useState<{ code: string; discount: number; total: number } | null>(null);
  const [couponMsg, setCouponMsg] = useState<string | null>(null);
  const [couponBusy, setCouponBusy] = useState(false);

  // A coupon is priced for one plan and period: changing either asks the server again.
  useEffect(() => {
    if (!coupon) return;
    let cancelled = false;
    checkCoupon({ data: { code: coupon.code, product, plan: planId, billing } })
      .then((r) => { if (cancelled) return; if (r.ok) setCoupon({ code: r.code, discount: r.discount, total: r.total }); else { setCoupon(null); setCouponMsg(r.message); } })
      .catch(() => { if (!cancelled) setCoupon(null); });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [planId, billing]);

  useEffect(() => {
    if (!openLocations.some((l) => l.id === location)) setLocation(openLocations[0]?.id ?? "");
    if (!minecraftVersions.includes(version)) setVersion("latest");
  }, [openLocations, location, minecraftVersions, version]);

  const plan = plans.find((p) => p.id === planId);
  const paused = !settings.ordering.enabled || settings.ordering.disabledProducts.includes(product);
  if (!plan) return <EmptyCart />;

  const period = billingPeriods.find((b) => b.key === billing);
  if (!period) return <EmptyCart />;
  const total = periodTotal(plan.monthly, billing);
  const full = plan.monthly * period.months;
  const isMc = product === "minecraft";
  const nameOk = SERVER_NAME_RE.test(serverName.trim());

  const gsltOk = GSLT_RE.test(gslt.trim());
  const seedNum = seed.trim() ? Number(seed.trim()) : undefined;
  const game: GameOptionsInput | undefined =
    product === "cs2" ? { gslt: gslt.trim(), mode: cs2Mode, map: cs2Map, ...(joinPassword.trim() ? { password: joinPassword.trim() } : {}) }
    : product === "rust" ? { worldSize, ...(seedNum !== undefined && Number.isInteger(seedNum) ? { seed: seedNum } : {}) }
    : product === "hytale" ? { patchline }
    : undefined;

  async function applyCoupon() {
    const code = couponCode.trim();
    if (!code || !plan) return;
    setCouponBusy(true); setCouponMsg(null);
    try {
      const r = await checkCoupon({ data: { code, product, plan: plan.id, billing } });
      if (r.ok) { setCoupon({ code: r.code, discount: r.discount, total: r.total }); setCouponCode(r.code); }
      else { setCoupon(null); setCouponMsg(r.message); }
    } catch (e) {
      setCoupon(null); setCouponMsg(shownError(e, "That coupon could not be checked. Please try again."));
    }
    setCouponBusy(false);
  }

  async function pay(useCredits: boolean) {
    if (!plan || !period) return;
    setTouched(true); setError(null);
    if (product === "rust" && seed.trim() && !(Number.isInteger(seedNum) && seedNum! >= 1 && seedNum! <= MAX_SEED)) { setError(`Map seed must be a whole number between 1 and ${MAX_SEED}.`); return; }
    const input = { product, plan: plan.id, billing, location, serverName: serverName.trim(), description: description.trim(), software: soft, version: isMc ? version : "latest", eula: isMc ? eula : false, ...(game ? { game } : {}), ...(coupon ? { coupon: coupon.code } : {}) };
    const check = checkoutInput.safeParse(input);
    if (!check.success) { setError(check.error.issues[0]?.message ?? "Please check the form."); return; }
    const availability = deploymentError(input, settings);
    if (availability) { setError(availability); return; }
    const { data } = await supabase.auth.getUser();
    const label = `${plan.name} (${period.label})`;
    await payment.run({
      create: () => create({ data: { ...input, useCredits } }),
      description: label,
      email: data.user?.email,
      verify: (co, r) => verify({ data: { orderId: co.orderId, razorpayOrderId: r.razorpay_order_id, paymentId: r.razorpay_payment_id, signature: r.razorpay_signature } }),
      success: (co) => ({ title: "Payment successful", body: `${label} is paid${useCredits ? " with credits" : ""}. We’re creating your server now.`, action: { label: "Track server setup", onClick: () => { payment.reset(); navigate({ to: "/deploy/status/$orderId", params: { orderId: co.orderId } }); } } }),
    });
  }

  return (
    <section className="checkout-section section container-px">
      <p className="eyebrow">Deploy · {productNames[product]}</p>
      <h1 className="mt-3 flex flex-wrap items-center gap-3 text-4xl">Set up your server{settings.ordering.disabledProducts.includes(product) && <span className="rounded-md border border-destructive/60 px-2 py-0.5 font-sans text-xs font-semibold text-destructive">Out of stock</span>}</h1>
      <p className="mt-3 text-muted-foreground">Pick your options, pay, and your server is created on the panel automatically.</p>

      <div className="mt-10 grid gap-8 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Step n={1} title="Plan">
            <div className="grid gap-3 sm:grid-cols-2">
              {plans.map((p) => (
                <button key={p.id} type="button" onClick={() => setPlanId(p.id)} aria-pressed={p.id === planId}
                  className={cn(choice, p.id === planId ? choiceOn : choiceOff, "block")}>
                  <div className="flex items-center justify-between"><span className="font-display font-semibold">{p.name}</span><span className="font-display text-azure">{formatINR(p.monthly)}<span className="text-xs text-muted-foreground">/mo</span></span></div>
                  <p className="mt-1 text-xs text-muted-foreground">{product === "vps" ? `${p.vcpu} vCPU` : cpuLabel(p)} · {p.ramLabel} RAM · {p.storage} NVMe</p>
                </button>
              ))}
            </div>
            <div className="mt-5"><BillingToggle value={billing} onChange={setBilling} /></div>
          </Step>

          <Step n={2} title="Location">
            {openLocations.length === 0 ? <p className="text-sm text-muted-foreground">All locations are full right now. Please check back soon.</p> : (
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {locations.map((l) => (
                  <button key={l.id} type="button" onClick={() => setLocation(l.id)} disabled={settings.ordering.disabledLocations.includes(l.id)} aria-pressed={l.id === location}
                    className={cn(choice, l.id === location ? choiceOn : choiceOff, "flex items-center gap-3")}>
                    {flags[l.country] && <img src={flags[l.country]} alt="" width={32} height={16} className="h-4 w-8 shrink-0 rounded-sm object-cover ring-1 ring-steel" />}
                    <span><span className="block text-sm font-semibold">{l.city}</span><span className={cn("text-xs", settings.ordering.disabledLocations.includes(l.id) ? "font-semibold text-destructive" : "text-muted-foreground")}>{settings.ordering.disabledLocations.includes(l.id) ? "Out of stock" : `${l.region} · ~${l.mockPing} ms`}</span></span>
                  </button>
                ))}
              </div>
            )}
          </Step>

          <Step n={3} title={product === "vps" ? "Operating system" : "Software"}>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {software.map((s) => (
                <button key={s.key} type="button" onClick={() => setSoft(s.key)} aria-pressed={s.key === soft}
                  className={cn(choice, s.key === soft ? choiceOn : choiceOff, "flex items-start gap-3")}>
                  {s.logo && <img src={s.logo} alt="" width={28} height={28} className="size-7 shrink-0 object-contain" />}
                  <span><span className="block text-sm font-semibold">{s.label}</span><span className="text-xs text-muted-foreground">{s.hint}</span></span>
                </button>
              ))}
            </div>
            {isMc && (
              <label className="mt-5 grid max-w-xs gap-1.5 text-sm">
                <span className="font-semibold">Minecraft version</span>
                <select value={version} onChange={(e) => setVersion(e.target.value)} className={field}>
                  {minecraftVersions.map((v) => <option key={v} value={v}>{v === "latest" ? "Latest release" : v}</option>)}
                </select>
              </label>
            )}
          </Step>

          <Step n={4} title="Server details">
            <div className="grid gap-4">
              <label className="grid gap-1.5 text-sm">
                <span className="font-semibold">Server name</span>
                <input value={serverName} onChange={(e) => setServerName(e.target.value)} maxLength={40} placeholder={product === "vps" ? "My Awesome VPS" : product === "bot" ? "My Awesome Bot" : "My Awesome Server"} className={cn(field, touched && !nameOk && "border-destructive")} aria-invalid={touched && !nameOk} />
                <span className={cn("text-xs", touched && !nameOk ? "text-destructive" : "text-muted-foreground")}>3 to 40 characters: letters, numbers, spaces, dots, dashes or underscores.</span>
              </label>
              <label className="grid gap-1.5 text-sm">
                <span className="font-semibold">Description <span className="font-normal text-muted-foreground">(optional)</span></span>
                <textarea value={description} onChange={(e) => setDescription(e.target.value)} maxLength={160} rows={3} placeholder="What is this server for?" className={cn(field, "h-auto py-2")} />
                <span className="text-xs text-muted-foreground">{description.length}/160</span>
              </label>
              {product === "cs2" && (
                <>
                  <label className="grid gap-1.5 text-sm">
                    <span className="font-semibold">Steam Game Server Login Token</span>
                    <input value={gslt} onChange={(e) => setGslt(e.target.value)} maxLength={32} autoComplete="off" spellCheck={false} placeholder="32 letters and numbers" className={cn(field, "font-mono", touched && !gsltOk && "border-destructive")} aria-invalid={touched && !gsltOk} />
                    <span className={cn("text-xs", touched && !gsltOk ? "text-destructive" : "text-muted-foreground")}>Required by Valve. Create one free at <a href="https://steamcommunity.com/dev/managegameservers" target="_blank" rel="noopener noreferrer" className="text-azure underline-offset-4 hover:underline">Steam game server accounts</a> using App ID 730.</span>
                  </label>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <label className="grid gap-1.5 text-sm">
                      <span className="font-semibold">Game mode</span>
                      <select value={cs2Mode} onChange={(e) => setCs2Mode(e.target.value)} className={field}>{Object.entries(cs2Modes).map(([k, m]) => <option key={k} value={k}>{m.label}</option>)}</select>
                    </label>
                    <label className="grid gap-1.5 text-sm">
                      <span className="font-semibold">Starting map</span>
                      <select value={cs2Map} onChange={(e) => setCs2Map(e.target.value)} className={field}>{cs2Maps.map((m) => <option key={m} value={m}>{m}</option>)}</select>
                    </label>
                  </div>
                  <label className="grid gap-1.5 text-sm">
                    <span className="font-semibold">Join password <span className="font-normal text-muted-foreground">(optional)</span></span>
                    <input value={joinPassword} onChange={(e) => setJoinPassword(e.target.value)} maxLength={30} autoComplete="off" placeholder="Leave empty for a public server" className={field} />
                  </label>
                </>
              )}
              {product === "rust" && (
                <div className="grid gap-4 sm:grid-cols-2">
                  <label className="grid gap-1.5 text-sm">
                    <span className="font-semibold">World size</span>
                    <select value={worldSize} onChange={(e) => setWorldSize(Number(e.target.value))} className={field}>{rustWorldSizes.map((w) => <option key={w} value={w}>{w}</option>)}</select>
                  </label>
                  <label className="grid gap-1.5 text-sm">
                    <span className="font-semibold">Map seed <span className="font-normal text-muted-foreground">(optional)</span></span>
                    <input value={seed} onChange={(e) => setSeed(e.target.value.replace(/[^0-9]/g, ""))} inputMode="numeric" maxLength={10} placeholder="Random" className={field} />
                  </label>
                </div>
              )}
              {product === "hytale" && (
                <label className="grid gap-1.5 text-sm">
                  <span className="font-semibold">Game version</span>
                  <select value={patchline} onChange={(e) => setPatchline(e.target.value)} className={field}>{Object.entries(hytalePatchlines).map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select>
                </label>
              )}
              {isMc && (
                <label className="flex items-start gap-3 text-sm">
                  <input type="checkbox" checked={eula} onChange={(e) => setEula(e.target.checked)} className="mt-0.5 size-4 accent-azure" />
                  <span>I accept the <a href="https://www.minecraft.net/en-us/eula" target="_blank" rel="noopener noreferrer" className="text-azure underline-offset-4 hover:underline">Minecraft EULA</a>.</span>
                </label>
              )}
            </div>
          </Step>
        </div>

        <aside className="checkout-summary panel h-fit p-6 lg:sticky lg:top-24">
          <h2 className="text-xl">Order summary</h2>
          <ul className="mt-4 space-y-2 text-sm">
            {planLines(plan, ["DDoS protection, up to 480 Gbps"]).map((line, i) => <PlanLine key={`${i}-${line}`} line={line} />)}
          </ul>
          <dl className="mt-5 divide-y divide-steel border-t border-steel text-sm">
            {[["Plan", plan.name], ["Location", locations.find((l) => l.id === location)?.city ?? "-"], [product === "vps" ? "OS" : "Software", software.find((s) => s.key === soft)?.label ?? "-"], ...(isMc ? [["Version", version === "latest" ? "Latest" : version]] : []), ["Billing", period.label]].map(([k, v]) => (
              <div key={k} className="flex justify-between py-2.5"><dt className="text-muted-foreground">{k}</dt><dd className="font-medium">{v}</dd></div>
            ))}
          </dl>
          <div className="mt-4 flex justify-between text-sm"><span className="text-muted-foreground">Subtotal</span><span>{formatINR(full)}</span></div>
          {period.discount > 0 && <div className="mt-2 flex justify-between text-sm"><span className="text-muted-foreground">{period.label} discount</span><span className="text-ok">-{formatINR(full - total)}</span></div>}
          {coupon && <div className="mt-2 flex justify-between text-sm"><span className="text-muted-foreground">Coupon {coupon.code}</span><span className="text-ok">-{formatINR(coupon.discount)}</span></div>}
          <div className="mt-4 flex justify-between border-t border-steel pt-4 font-display text-xl"><span>Total</span><span>{formatINR(coupon ? coupon.total : total)}</span></div>
          <div className="mt-4">
            {coupon ? (
              <p className="flex items-center justify-between gap-2 rounded-md border border-ok/40 bg-ok/10 px-3 py-2 text-sm"><span>Coupon <span className="font-mono font-semibold">{coupon.code}</span> applied</span><Button type="button" variant="link" size="sm" onClick={() => { setCoupon(null); setCouponCode(""); setCouponMsg(null); }}>Remove</Button></p>
            ) : (
              <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); void applyCoupon(); }}>
                <input value={couponCode} onChange={(e) => setCouponCode(e.target.value.toUpperCase())} maxLength={32} placeholder="Coupon code" aria-label="Coupon code" autoComplete="off" spellCheck={false} className={cn(field, "h-10 font-mono uppercase")} />
                <Button type="submit" disabled={couponBusy || !couponCode.trim()} variant="secondary">{couponBusy ? <Spinner size="xs" /> : "Apply"}</Button>
              </form>
            )}
            {couponMsg && <p role="alert" className="mt-2 text-xs text-destructive">{couponMsg}</p>}
          </div>
          <p className="mt-1 text-xs text-muted-foreground">GST included · No auto renew</p>
          {isGame(product)
            ? <p className="mt-3 rounded-md border border-ok/40 bg-ok/10 p-3 text-sm text-card-foreground">Eligible game hosting orders may be refunded within 24 hours of payment.</p>
            : <p className="mt-3 rounded-md border border-border bg-muted p-3 text-sm text-card-foreground">VPS and bot hosting orders are not refundable.</p>}
          {paused ? (
            <p role="status" className="mt-6 rounded-md border border-azure/50 p-3 text-sm">{settings.ordering.disabledProducts.includes(product) ? `${productNames[product]} is out of stock right now. Please check back soon.` : settings.ordering.pausedMessage || "New orders are paused right now."}</p>
          ) : (
            <PayChoice className="mt-6" amount={coupon ? coupon.total : total} balance={credits.data?.balance} product={product} disabled={busy || !openLocations.some((l) => l.id === location)} onPay={(useCredits) => void pay(useCredits)} />
          )}
          {error && <p role="alert" className="mt-4 text-sm text-destructive">{error}</p>}
          <p className="mt-4 flex items-center gap-2 text-xs text-muted-foreground"><Check className="size-3.5 text-azure" />Card, UPI and netbanking payments are processed securely by Razorpay.</p>
        </aside>
        {payment.overlay}
      </div>
    </section>
  );
}
