import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AlertTriangle, Check } from "lucide-react";
import { PageLoader, Spinner } from "@/components/ui-px/Spinner";
import { btn } from "@/components/ui-px/btn";
import { softwareLabel } from "@/config/software";
import { useSettings } from "@/hooks/use-settings";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/deploy/status/$orderId")({
  head: () => ({ meta: [
    { title: "Setting up your server | PlexScale" },
    { name: "description", content: "Live setup progress for your PlexScale server." },
    { property: "og:title", content: "Setting up your server | PlexScale" },
    { property: "og:description", content: "Your server is being set up." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
    { name: "robots", content: "noindex" },
  ] }),
  component: Status,
});

const steps = [
  { key: "paid", label: "Payment received" },
  { key: "provisioning", label: "Creating your server on the panel" },
  { key: "active", label: "Server is live" },
];

function Status() {
  const { orderId } = Route.useParams();
  const s = useSettings();
  const locations = s.locations;
  const { data: order, isLoading } = useQuery({
    queryKey: ["order", orderId],
    queryFn: async () => (await supabase.from("orders").select("id, kind, product, plan_name, billing, status, location, server_name, software, version, ptero_identifier, paid_at, provision_error").eq("id", orderId).maybeSingle()).data,
    refetchInterval: (q) => (["active", "failed", "cancelled", "refunded", "renewed"].includes(q.state.data?.status ?? "") ? false : 5000),
  });

  if (isLoading) return <PageLoader text="Loading your order" />;
  if (!order) return <section className="section container-px"><h1 className="text-3xl">Order not found</h1><Link to="/billing" className={`${btn()} mt-6`}>Go to billing</Link></section>;

  const reached = order.status === "active" ? 3 : order.status === "provisioning" ? 2 : order.status === "pending" ? 0 : 1;
  const city = locations.find((l) => l.id === order.location)?.city ?? order.location;
  const panelUrl = order.product === "vps" ? s.vpsPanelUrl : s.gamePanelUrl;
  const serverUrl = order.ptero_identifier ? `${s.gamePanelUrl.replace(/\/+$/, "")}/server/${encodeURIComponent(order.ptero_identifier)}` : panelUrl;

  return (
    <section className="section container-px max-w-2xl">
      <p className="eyebrow">Order {order.id.slice(0, 8)}</p>
      <h1 className="mt-3 text-4xl">{order.status === "active" ? "Your server is live" : order.status === "pending" ? "Waiting for payment" : "Setting up your server"}</h1>
      <p className="mt-4 text-muted-foreground">{order.server_name || order.plan_name} · {order.plan_name} in {city}{order.software ? ` · ${softwareLabel(order.product, order.software)}` : ""}. This page updates on its own.</p>
      <ol className="mt-10 space-y-4">
        {steps.map((st, i) => {
          const done = i < reached;
          const current = i === reached;
          return (
            <li key={st.key} className={cn("panel flex items-center gap-4 p-4", done && "border-azure")}>
              <span className={cn("flex size-8 items-center justify-center rounded-full border border-steel", done && "border-azure bg-primary text-primary-foreground")}>
                {done ? <Check className="size-4" /> : current ? <Spinner size="xs" /> : i + 1}
              </span>
              <span className={cn(!done && !current && "text-muted-foreground")}>{st.label}</span>
            </li>
          );
        })}
      </ol>
      {order.status === "provisioning" && (
        <p className="panel mt-6 flex gap-3 border-azure/50 p-4 text-sm"><AlertTriangle className="size-4 shrink-0 text-azure" /><span>Our team has been notified and will finish setting up your server shortly. Your payment is safe.{order.provision_error && <span className="mt-2 block font-mono text-xs text-muted-foreground">{order.provision_error}</span>}</span></p>
      )}
      <div className="mt-10 flex flex-wrap gap-3">
        {order.status === "active" && <a href={serverUrl} target="_blank" rel="noopener noreferrer" className={btn({ size: "lg" })}>Open {order.product === "vps" ? "VPS" : "game"} panel</a>}
        <Link to="/billing" className={btn({ size: "lg", variant: "secondary" })}>Go to billing</Link>
        <Link to="/support/new" search={{ category: "technical", orderId: order.id }} className={btn({ size: "lg", variant: "ghost" })}>Need help? Open a ticket</Link>
      </div>
      {order.status === "active" && order.product !== "vps" && <p className="mt-6 text-sm text-muted-foreground">Log in to the game panel with the same email you used here. If it is your first time, use “Forgot password” on the panel to set one.</p>}
    </section>
  );
}
