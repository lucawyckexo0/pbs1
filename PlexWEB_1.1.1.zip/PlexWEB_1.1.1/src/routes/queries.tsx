import { createFileRoute } from "@tanstack/react-router";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FaqList, SupportCards } from "@/components/sections/common";
import { faqTabs } from "@/config/faq";

const title = "Queries and answers | PlexScale";
const desc = "Answers about setup, hardware, billing, renewals, refunds and support at PlexScale.";

export const Route = createFileRoute("/queries")({
  head: () => ({ meta: [{ property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }, { title }, { name: "description", content: desc }, { property: "og:title", content: title }, { property: "og:description", content: desc }] }),
  component: Faq,
});

function Faq() {
  return (
    <>
      <section className="section container-px">
        <p className="eyebrow">Queries</p>
        <h1 className="mt-3 text-4xl md:text-5xl">How can we help?</h1>
        <Tabs defaultValue="start" className="mt-10">
          <TabsList className="h-auto flex-wrap border border-steel bg-graphite p-1">
            {faqTabs.map((t) => (
              <TabsTrigger key={t.key} value={t.key} className="px-4 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">{t.label}</TabsTrigger>
            ))}
          </TabsList>
          {faqTabs.map((t) => (
            <TabsContent key={t.key} value={t.key} className="mt-6"><FaqList items={t.items} /></TabsContent>
          ))}
        </Tabs>
      </section>
      <SupportCards />
    </>
  );
}
