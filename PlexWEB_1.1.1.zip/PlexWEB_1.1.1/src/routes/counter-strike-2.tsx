import { createFileRoute } from "@tanstack/react-router";
import { GamePage } from "@/components/sections/GamePage";
import { homeFaq } from "@/config/faq";
import { img } from "@/config/images";

export const Route = createFileRoute("/counter-strike-2")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { title: "Counter Strike 2 server hosting | PlexScale" },
      { name: "description", content: "CS2 servers on AMD EPYC 7763 in Mumbai, Hyderabad, Dubai, Frankfurt and Virginia (US). GST included." },
      { property: "og:title", content: "Counter Strike 2 server hosting | PlexScale" },
      { property: "og:description", content: "CS2 servers on AMD EPYC 7763 in Mumbai, Hyderabad, Dubai, Frankfurt and Virginia (US). GST included." },
    ],
  }),
  component: () => (
    <GamePage game="cs2" name="Counter Strike 2" image={img.cs2} sub="Low latency CS2 servers in India and Asia for scrims, retakes and community nights." software={["Competitive","Retakes","Deathmatch","Workshop maps","SourceMod"]} faq={homeFaq} />
  ),
});
