import type { ReactNode } from "react";
import type { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

/** Page title block used by every account page and Administrator, matching the homepage section headings. */
export function PageHeader({ eyebrow, title, description, actions, className }: { eyebrow: string; title: ReactNode; description?: ReactNode; actions?: ReactNode; className?: string }) {
  return (
    <header className={cn("flex flex-wrap items-end justify-between gap-x-6 gap-y-4 border-b border-steel pb-6", className)}>
      <div className="min-w-0">
        <p className="eyebrow">{eyebrow}</p>
        <h1 className="mt-3 text-3xl md:text-4xl">{title}</h1>
        {description && <p className="mt-3 max-w-2xl text-muted-foreground">{description}</p>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </header>
  );
}

/** Section heading inside a page. */
export function SectionTitle({ title, description, actions, className }: { title: ReactNode; description?: ReactNode; actions?: ReactNode; className?: string }) {
  return (
    <div className={cn("flex flex-wrap items-end justify-between gap-3", className)}>
      <div className="min-w-0">
        <h2 className="text-xl md:text-2xl">{title}</h2>
        {description && <p className="mt-1 text-sm text-muted-foreground">{description}</p>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}

/** One number with its label. */
export function StatCard({ label, value, icon: Icon, hint, tone }: { label: string; value: ReactNode; icon?: LucideIcon; hint?: ReactNode; tone?: "ok" | "bad" | "info" }) {
  return (
    <div className="panel relative overflow-hidden p-5">
      <div className="flex items-start justify-between gap-3">
        <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">{label}</p>
        {Icon && <Icon aria-hidden className={cn("size-4 shrink-0", tone === "ok" ? "text-ok" : tone === "bad" ? "text-destructive" : "text-azure")} />}
      </div>
      <p className="mt-2 font-display text-2xl tabular-nums">{value}</p>
      {hint && <p className="mt-1 text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}

export type BadgeTone = "ok" | "info" | "warn" | "bad" | "muted";

export function Badge({ tone = "muted", children, className, dot }: { tone?: BadgeTone; children: ReactNode; className?: string; dot?: boolean }) {
  return (
    <span className={cn("badge", `badge-${tone}`, className)}>
      {dot && <span aria-hidden className="size-1.5 rounded-full bg-current" />}
      {children}
    </span>
  );
}

/** Friendly empty state with one clear next step. */
export function EmptyState({ icon: Icon, title, body, action }: { icon: LucideIcon; title: string; body?: ReactNode; action?: ReactNode }) {
  return (
    <div className="panel flex flex-col items-center p-10 text-center md:p-12">
      <span className="popup-icon popup-icon-info size-14"><Icon className="size-6" /></span>
      <h3 className="mt-5 text-xl">{title}</h3>
      {body && <p className="mt-2 max-w-md text-sm text-muted-foreground">{body}</p>}
      {action && <div className="mt-6">{action}</div>}
    </div>
  );
}
