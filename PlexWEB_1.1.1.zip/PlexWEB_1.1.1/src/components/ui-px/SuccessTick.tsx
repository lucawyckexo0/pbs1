import { cn } from "@/lib/utils";

/** Animated green tick in a blue halo, used by every success popup. */
export function SuccessTick({ className, size = "lg" }: { className?: string; size?: "sm" | "lg" }) {
  return (
    <span className={cn("success-tick", size === "sm" && "success-tick-sm", className)} aria-hidden>
      <svg viewBox="0 0 52 52">
        <circle className="success-tick-ring" cx="26" cy="26" r="23" fill="none" />
        <path className="success-tick-check" fill="none" d="M15 27l7 7 15-16" />
      </svg>
    </span>
  );
}
