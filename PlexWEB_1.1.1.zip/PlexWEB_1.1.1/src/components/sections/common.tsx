import { Link } from "@tanstack/react-router";
import { ArrowRight, LifeBuoy, Mail, MessageCircle } from "lucide-react";
import type { ReactNode } from "react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { btn } from "@/components/ui-px/btn";
import type { QA } from "@/config/faq";
import { site } from "@/config/site";
import { useSettings } from "@/hooks/use-settings";
import { cn } from "@/lib/utils";

export function SectionHead({ eyebrow, title, sub, center }: { eyebrow?: string; title: string; sub?: string; center?: boolean }) {
  return (
    <div className={cn(center && "mx-auto text-center", "max-w-2xl")}>
      {eyebrow && <p className="eyebrow">{eyebrow}</p>}
      <h2 className="mt-2">{title}</h2>
      {sub && <p className={cn("measure mt-4 text-muted-foreground", center && "mx-auto")}>{sub}</p>}
    </div>
  );
}

export function Divider() {
  return <div className="container-px"><div className="slant-divider" /></div>;
}

export function FaqList({ items }: { items: QA[] }) {
  return (
    <Accordion type="single" collapsible className="panel divide-y divide-steel px-6">
      {items.map((it, i) => (
        <AccordionItem key={it.q} value={`i${i}`} className="border-0">
          <AccordionTrigger className="py-5 text-left font-display text-base font-semibold hover:no-underline">{it.q}</AccordionTrigger>
          <AccordionContent className="measure pb-5 text-muted-foreground">{it.a}</AccordionContent>
        </AccordionItem>
      ))}
    </Accordion>
  );
}

export function FaqSection({ items, title = "Questions, answered" }: { items: QA[]; title?: string }) {
  return (
    <section className="section container-px grid gap-10 lg:grid-cols-12">
      <div className="lg:col-span-4">
        <SectionHead eyebrow="Queries" title={title} sub="Something still unclear? Open a ticket or drop into Discord and we will sort it out." />
        <Link to="/queries" className={cn(btn({ variant: "secondary" }), "mt-6")}>See all questions</Link>
      </div>
      <div className="lg:col-span-8"><FaqList items={items} /></div>
    </section>
  );
}

export function PageHero({ eyebrow, title, sub, image, children }: { eyebrow: string; title: string; sub: string; image?: string; children?: ReactNode }) {
  return (
    <section className="relative -mt-16 overflow-hidden pt-16">
      {image && (
        <>
          <img src={image} alt="" width={1280} height={720} className="absolute inset-0 h-full w-full object-cover opacity-60" />
          <div className="fade-ink-side absolute inset-0" />
          <div className="fade-ink absolute inset-0" />
        </>
      )}
      <div className="container-px relative py-24 md:py-32">
        <div className="max-w-2xl animate-rise">
          <p className="eyebrow">{eyebrow}</p>
          <h1 className="mt-3">{title}</h1>
          <p className="measure mt-5 text-lg text-muted-foreground">{sub}</p>
          {children && <div className="mt-8 flex flex-wrap gap-3">{children}</div>}
        </div>
      </div>
    </section>
  );
}

/** The three ways to reach PlexScale. Used on every support section so they always match. */
export function SupportOptions({ className }: { className?: string }) {
  const s = useSettings();
  const cards = [
    { key: "tickets", icon: LifeBuoy, title: "Support tickets", body: "Private, tracked help for servers, billing and account issues. Email updates on every reply.", cta: "Open a ticket", internal: true },
    { key: "discord", icon: MessageCircle, title: "Discord", body: "Quick help with setup, plugins, mods and anything game related from our team and community.", cta: s.discordLabel, href: s.discordUrl },
    { key: "email", icon: Mail, title: "Email", body: "Prefer email? Write to us for billing questions, invoices and private account matters.", cta: s.supportEmail, href: `mailto:${s.supportEmail}` },
  ];
  const card = "panel group relative flex h-full flex-col p-8 transition-colors duration-150 hover:border-azure/60";
  const inner = (c: (typeof cards)[number]) => (
    <>
      <div className="flex items-start justify-between gap-3">
        <span className="grid size-12 place-items-center rounded-md border border-steel bg-ink/50"><c.icon className="size-6 text-azure" /></span>
      </div>
      <h3 className="mt-6 text-xl font-semibold">{c.title}</h3>
      <p className="mt-2 flex-1 text-muted-foreground">{c.body}</p>
      <span className="mt-6 inline-flex items-center gap-1.5 font-display text-sm font-semibold text-azure group-hover:text-azure-bright">{c.cta}<ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" /></span>
    </>
  );
  return (
    <div className={cn("grid items-stretch gap-6 md:grid-cols-3", className)}>
      {cards.map((c) => c.internal
        ? <Link key={c.key} to="/support/new" className={card}>{inner(c)}</Link>
        : <a key={c.key} href={c.href} {...(c.key === "discord" ? { target: "_blank", rel: "noopener noreferrer" } : {})} className={card}>{inner(c)}</a>)}
    </div>
  );
}

export function SupportCards() {
  return (
    <section className="section container-px">
      <SectionHead eyebrow="Support" title="Real people, quick replies" sub={`${site.responseTime}. Open a ticket right here on the site, or reach us on Discord and email.`} />
      <SupportOptions className="mt-10" />
    </section>
  );
}

export function ClosingBanner({ title }: { title?: ReactNode } = {}) {
  const s = useSettings();
  return (
    <section className="section container-px">
      <div className="scale-banner relative isolate overflow-hidden rounded-xl border p-10 md:p-16">
        <div aria-hidden className="pointer-events-none absolute inset-0 -z-10">
          <div className="scale-banner-stars scale-banner-stars-a absolute inset-0" />
          <div className="scale-banner-stars scale-banner-stars-b absolute inset-0" />
          <div className="scale-banner-nebula absolute inset-0" />
          <svg className="absolute left-1/2 top-1/2 h-[900px] w-[900px] -translate-x-1/2 -translate-y-1/2" viewBox="0 0 900 900" fill="none">
            {[140, 220, 300, 380].map((r, i) => (
              <g key={r} className="scale-banner-ring" style={{ animationDuration: `${36 + i * 14}s`, animationDirection: i % 2 ? "reverse" : "normal" }}>
                <circle cx="450" cy="450" r={r} strokeDasharray={i % 2 ? "2 10" : "60 24"} />
                <circle cx={450 + r} cy="450" r={i % 2 ? 2.5 : 3.5} className="scale-banner-planet" />
              </g>
            ))}
          </svg>
          <div className="scale-banner-core absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
            <div className="scale-banner-halo" />
            <svg className="scale-banner-star" viewBox="0 0 100 100" fill="none">
              <defs>
                <radialGradient id="banner-star-fill">
                  <stop offset="0%" style={{ stopColor: "var(--foreground)" }} />
                  <stop offset="45%" style={{ stopColor: "var(--azure-bright)" }} />
                  <stop offset="100%" style={{ stopColor: "var(--azure)", stopOpacity: 0.6 }} />
                </radialGradient>
              </defs>
              <path d="M50 0 C53 38 62 47 100 50 C62 53 53 62 50 100 C47 62 38 53 0 50 C38 47 47 38 50 0Z" />
            </svg>
          </div>
          <div className="scale-banner-veil absolute inset-0" />
        </div>
        <div className="relative mx-auto max-w-3xl text-center">
          <h2 className="text-3xl leading-tight md:text-5xl">{title ?? <>Scalable solutions for complex problems. <span className="text-azure-bright">That’s PlexScale.</span></>}</h2>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Link to="/deploy" className={btn({ size: "lg" })}>Get started</Link>
            <a href={s.discordUrl} target="_blank" rel="noopener noreferrer" className={btn({ size: "lg", variant: "glass" })}>Talk to us</a>
          </div>
        </div>
      </div>
    </section>
  );
}

export function FeatureLines({ items }: { items: { icon: ReactNode; title: string; body: string }[] }) {
  return (
    <section className="section container-px">
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {items.map((f) => (
          <div key={f.title} className="panel p-6">
            <div className="text-azure [&_svg]:size-6">{f.icon}</div>
            <h3 className="mt-5 text-lg font-semibold">{f.title}</h3>
            <p className="mt-2 text-sm text-muted-foreground">{f.body}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
