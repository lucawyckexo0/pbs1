import { Archive, FolderOpen, Gamepad2, HardDriveDownload, Server, ShieldHalf, Terminal } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import panelImg from "@/assets/img/panel.webp";
import { img } from "@/config/images";
import { SectionHead } from "@/components/sections/common";
import { cn } from "@/lib/utils";

const slides = [
  {
    key: "game",
    tab: "Game Panel",
    icon: Gamepad2,
    title: "Game Panel",
    body: "Built on Pterodactyl, the panel trusted by game hosts worldwide. Manage worlds, mods and players from your browser.",
    image: panelImg,
    width: 1672,
    height: 941,
    alt: "PlexScale game panel with live console, file manager and backups",
    caps: [
      { icon: Terminal, t: "Live console", b: "Watch logs and run commands in real time." },
      { icon: FolderOpen, t: "File manager", b: "Edit configs and upload worlds in the browser." },
      { icon: Archive, t: "Backups", b: "Take a backup and restore it in one click." },
    ],
  },
  {
    key: "vps",
    tab: "VPS Panel",
    icon: Server,
    title: "VPS Panel",
    body: "Fully custom built by the PlexScale team, with access to features like Live Console, OS Rebuilds, Firewalls, and more.",
    image: img.plexusVpsPanel,
    width: 1876,
    height: 1055,
    alt: "Plexus VPS panel dashboard with power controls, CPU, memory, disk and network usage",
    caps: [
      { icon: Terminal, t: "Live Console", b: "Full browser console access, even before SSH is up." },
      { icon: HardDriveDownload, t: "OS Rebuilds", b: "Reinstall Ubuntu or Debian in a couple of clicks." },
      { icon: ShieldHalf, t: "Firewalls", b: "Open and close ports with simple rules." },
    ],
  },
] as const;

export function PanelSlider() {
  const [i, setI] = useState(0);
  const [paused, setPaused] = useState(false);
  const touch = useRef<number | null>(null);
  const go = useCallback((n: number) => setI((n + slides.length) % slides.length), []);

  useEffect(() => {
    if (paused) return;
    const t = setInterval(() => setI((x) => (x + 1) % slides.length), 7000);
    return () => clearInterval(t);
  }, [paused]);

  const s = slides[i]!;
  return (
    <section className="section container-px" aria-roledescription="carousel" aria-label="Control panels">
      <SectionHead eyebrow="Control panels" title="Everything in one panel" sub="A dedicated panel for every service: game servers on our Game Panel, virtual servers on our custom VPS Panel." center />
      <div className="mx-auto mt-8 flex w-fit rounded-lg border border-steel bg-graphite p-1" role="tablist" aria-label="Choose a panel">
        {slides.map((sl, n) => (
          <button key={sl.key} type="button" role="tab" aria-selected={i === n} onClick={() => go(n)} className={cn("flex items-center gap-2 rounded-md px-4 py-2 font-display text-sm font-semibold transition-colors duration-200", i === n ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground")}>
            <sl.icon className="size-4" />{sl.tab}
          </button>
        ))}
      </div>

      <div className="relative mx-auto mt-8 max-w-5xl" onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)} onFocus={() => setPaused(true)} onBlur={() => setPaused(false)}
        onTouchStart={(e) => { touch.current = e.touches[0]?.clientX ?? null; }}
        onTouchEnd={(e) => { const start = touch.current; const end = e.changedTouches[0]?.clientX; if (start != null && end != null && Math.abs(end - start) > 40) go(i + (end < start ? 1 : -1)); touch.current = null; }}>
        <div className="panel-frame panel overflow-hidden p-2">
          <div className="overflow-hidden rounded-lg">
            <div className="flex transition-transform duration-700 ease-[cubic-bezier(.65,0,.35,1)]" style={{ transform: `translateX(-${i * 100}%)` }}>
              {slides.map((sl, n) => (
                <div key={sl.key} className="w-full shrink-0" role="group" aria-roledescription="slide" aria-label={`${n + 1} of ${slides.length}: ${sl.title}`} aria-hidden={i !== n}>
                  <img src={sl.image} alt={sl.alt} width={sl.width} height={sl.height} loading="lazy" className="block aspect-[16/9] h-auto w-full object-cover" />
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="mt-4 flex justify-center gap-2" aria-hidden>
          {slides.map((sl, n) => <span key={sl.key} className={cn("h-1.5 rounded-full transition-all duration-500", i === n ? "w-8 bg-azure" : "w-3 bg-steel")} />)}
        </div>
      </div>

      <div key={s.key} className="animate-rise mx-auto mt-6 max-w-5xl">
        <div className="text-center">
          <h3 className="flex items-center justify-center gap-2 text-2xl font-semibold"><s.icon className="size-6 text-azure" />{s.title}</h3>
          <p className="mx-auto mt-2 max-w-2xl text-muted-foreground">{s.body}</p>
        </div>
        <div className="mt-8 grid gap-6 md:grid-cols-3">
          {s.caps.map((c) => (
            <div key={c.t} className="flex gap-4"><c.icon className="mt-0.5 size-5 shrink-0 text-azure" /><div><h4 className="font-semibold">{c.t}</h4><p className="text-sm text-muted-foreground">{c.b}</p></div></div>
          ))}
        </div>
      </div>
    </section>
  );
}
