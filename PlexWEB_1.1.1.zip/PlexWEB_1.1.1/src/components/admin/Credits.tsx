import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Minus, Plus, Wallet } from "lucide-react";
import { Button } from "@/components/ui/button";
import { askConfirm } from "@/components/ui-px/ConfirmHost";
import { PageLoader, Spinner } from "@/components/ui-px/Spinner";
import { Badge, StatCard } from "@/components/ui-px/page";
import { creditKindLabel, creditsSettingsSchema, type CreditsSettings } from "@/config/credits";
import { formatINR, productKeys, productNames } from "@/config/plans";
import type { SiteSettings } from "@/config/settings";
import { adminAdjustCredits, adminCreditsOverview } from "@/lib/credits.functions";
import { saveSiteSettings } from "@/lib/admin.functions";
import { cn } from "@/lib/utils";
import { Card, Field, inputCls, num, td, th, Toggle } from "./fields";
import { SaveBar, useSettingsDraft } from "./settings-controls";
import { shownError } from "@/lib/public-error";

const when = (s: string) => new Date(s).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" });

export function CreditsAdmin({ site, onSaved }: { site: SiteSettings; onSaved: () => void }) {
  const qc = useQueryClient();
  const load = useServerFn(adminCreditsOverview);
  const adjust = useServerFn(adminAdjustCredits);
  const { data, isLoading, error } = useQuery({ queryKey: ["admin-credits"], queryFn: () => load() });
  const [email, setEmail] = useState("");
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [direction, setDirection] = useState<"add" | "remove">("add");
  const [busy, setBusy] = useState(false);
  const [q, setQ] = useState("");

  if (isLoading) return <PageLoader text="Loading credits" className="min-h-[30vh]" />;
  if (error || !data) return <p className="text-sm text-destructive">Could not load credits.</p>;
  const who = (id: string | null) => (id ? data.profiles.find((p) => p.id === id)?.email ?? id.slice(0, 8) : "System");
  const wallets = data.wallets.filter((w) => !q || who(w.user_id).toLowerCase().includes(q.toLowerCase()));

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const n = Number(amount);
    if (!Number.isInteger(n) || n <= 0) { toast.error("Enter a whole number of credits."); return; }
    const signed = direction === "add" ? n : -n;
    if (!(await askConfirm(`${direction === "add" ? "Add" : "Remove"} ${formatINR(n)} ${direction === "add" ? "to" : "from"} ${email.trim()}?`))) return;
    setBusy(true);
    try {
      const r = await adjust({ data: { email: email.trim(), amount: signed, note: note.trim() } });
      toast.success(`Done. New balance ${formatINR(r.balance)}.`);
      setAmount(""); setNote("");
      void qc.invalidateQueries({ queryKey: ["admin-credits"] });
    } catch (err) {
      toast.error(shownError(err, "The change could not be saved."));
    }
    setBusy(false);
  }

  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="Outstanding credits" value={formatINR(data.outstanding)} icon={Wallet} hint="Total customer balances" />
        <StatCard label="Customers with credits" value={data.wallets.length} />
        <StatCard label="Ledger entries shown" value={data.transactions.length} hint="Newest 200" />
      </div>

      <CreditSettings site={site} onSaved={onSaved} />

      <Card title="Adjust a balance" sub="Adds or removes credits for one customer. Every change is logged with your account and the reason.">
        <form onSubmit={submit} className="grid gap-4 md:grid-cols-[minmax(0,2fr)_auto_minmax(0,1fr)]">
          <Field label="Customer email"><input type="email" required maxLength={120} value={email} onChange={(e) => setEmail(e.target.value)} placeholder="customer@example.com" className={inputCls} /></Field>
          <Field label="Change">
            <div role="radiogroup" aria-label="Add or remove" className="inline-flex h-10 rounded-md border border-steel bg-ink p-1">
              {(["add", "remove"] as const).map((d) => (
                <button key={d} type="button" role="radio" aria-checked={direction === d} onClick={() => setDirection(d)}
                  className={cn("inline-flex items-center gap-1.5 rounded px-3 text-sm font-medium transition-colors", direction === d ? (d === "add" ? "bg-ok/15 text-ok" : "bg-destructive/15 text-destructive") : "text-muted-foreground hover:text-foreground")}>
                  {d === "add" ? <Plus className="size-3.5" /> : <Minus className="size-3.5" />}{d === "add" ? "Add" : "Remove"}
                </button>
              ))}
            </div>
          </Field>
          <Field label="Credits (₹)"><input inputMode="numeric" required value={amount} onChange={(e) => setAmount(e.target.value.replace(/[^0-9]/g, "").slice(0, 7))} placeholder="500" className={inputCls} /></Field>
          <Field label="Reason (shown to the customer)" className="md:col-span-3"><input required minLength={3} maxLength={200} value={note} onChange={(e) => setNote(e.target.value)} placeholder="Goodwill credit for the Mumbai outage" className={inputCls} /></Field>
          <div className="md:col-span-3"><Button type="submit" variant={direction === "add" ? "primary" : "danger"} disabled={busy}>{busy ? <Spinner size="xs" /> : direction === "add" ? <Plus /> : <Minus />}{direction === "add" ? "Add credits" : "Remove credits"}</Button></div>
        </form>
      </Card>

      <Card title="Balances" actions={<input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search email" className={cn(inputCls, "w-56")} />}>
        <div className="max-h-[420px] overflow-auto">
          <table className="w-full text-sm">
            <thead className="sticky top-0 bg-graphite"><tr><th className={th}>Customer</th><th className={cn(th, "text-right")}>Balance</th><th className={th}>Last change</th></tr></thead>
            <tbody>
              {wallets.length === 0 && <tr><td className={td} colSpan={3}>No balances.</td></tr>}
              {wallets.map((w) => <tr key={w.user_id}><td className={td}>{who(w.user_id)}</td><td className={cn(td, "text-right font-semibold tabular-nums")}>{formatINR(w.balance)}</td><td className={cn(td, "text-muted-foreground")}>{when(w.updated_at)}</td></tr>)}
            </tbody>
          </table>
        </div>
      </Card>

      <Card title="Ledger" sub="Every top-up, payment, refund and adjustment. Entries cannot be edited.">
        <div className="max-h-[520px] overflow-auto">
          <table className="w-full text-sm">
            <thead className="sticky top-0 bg-graphite"><tr><th className={th}>When</th><th className={th}>Customer</th><th className={th}>Type</th><th className={cn(th, "text-right")}>Amount</th><th className={cn(th, "text-right")}>Balance</th><th className={th}>Note</th></tr></thead>
            <tbody>
              {data.transactions.length === 0 && <tr><td className={td} colSpan={6}>No credit activity yet.</td></tr>}
              {data.transactions.map((t) => (
                <tr key={t.id}>
                  <td className={cn(td, "whitespace-nowrap text-muted-foreground")}>{when(t.created_at)}</td>
                  <td className={td}>{who(t.user_id)}</td>
                  <td className={td}><Badge tone={t.amount > 0 ? "ok" : t.kind === "admin_deduct" ? "bad" : "info"}>{creditKindLabel[t.kind] ?? t.kind}</Badge></td>
                  <td className={cn(td, "whitespace-nowrap text-right font-semibold tabular-nums", t.amount > 0 ? "text-ok" : "")}>{t.amount > 0 ? "+" : "-"}{formatINR(Math.abs(t.amount))}</td>
                  <td className={cn(td, "whitespace-nowrap text-right tabular-nums text-muted-foreground")}>{formatINR(t.balance_after)}</td>
                  <td className={cn(td, "max-w-xs text-muted-foreground")}>{t.note}{t.created_by ? <span className="block text-xs">by {who(t.created_by)}</span> : null}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

function CreditSettings({ site, onSaved }: { site: SiteSettings; onSaved: () => void }) {
  const save = useServerFn(saveSiteSettings);
  const { draft, setDraft, dirty, discard, accept } = useSettingsDraft<CreditsSettings>(site.credits);
  const [saving, setSaving] = useState(false);
  const [presetText, setPresetText] = useState(site.credits.presets.join(", "));
  const set = <K extends keyof CreditsSettings>(k: K, v: CreditsSettings[K]) => setDraft((p) => ({ ...p, [k]: v }));

  async function submit() {
    const checked = creditsSettingsSchema.safeParse(draft);
    if (!checked.success) { toast.error(checked.error.issues[0]?.message ?? "Check the credit settings."); return; }
    setSaving(true);
    try { await save({ data: { ...site, credits: checked.data } }); accept(checked.data); toast.success("Credit settings saved."); onSaved(); }
    catch { toast.error("Could not save the credit settings."); }
    setSaving(false);
  }

  return (
    <Card title="Credit settings" sub="Top-up limits customers see on the Billing page. Prices are in rupees.">
      <div className="grid gap-5">
        <div className="flex flex-wrap gap-6">
          <Toggle checked={draft.enabled} onChange={(v) => set("enabled", v)} label="Customers can buy credits" />
          <Toggle checked={draft.payWithCredits} onChange={(v) => set("payWithCredits", v)} label="Customers can pay with credits" />
        </div>
        <div className="grid gap-2">
          <p className="text-sm font-semibold">Credits can pay for</p>
          <p className="text-xs text-muted-foreground">Untick a product to make customers pay for it (new orders, renewals and upgrades) with Razorpay only.</p>
          <div className="mt-1 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {productKeys.map((p) => {
              const allowed = !draft.disabledProducts.includes(p);
              return (
                <label key={p} className={cn("flex min-h-11 cursor-pointer items-center justify-between gap-3 rounded-md border px-4 py-2.5 text-sm transition-colors", !draft.payWithCredits ? "cursor-not-allowed opacity-60" : allowed ? "border-ok/40 bg-ok/5" : "border-steel hover:border-azure/60")}>
                  <span className="min-w-0"><span className="block font-semibold">{productNames[p]}</span><span className={cn("text-xs", allowed ? "text-ok" : "text-muted-foreground")}>{allowed ? "Credits allowed" : "Razorpay only"}</span></span>
                  <input type="checkbox" className="size-4 shrink-0 accent-azure" disabled={!draft.payWithCredits} checked={allowed}
                    onChange={(e) => set("disabledProducts", e.target.checked ? draft.disabledProducts.filter((x) => x !== p) : [...new Set([...draft.disabledProducts, p])])} />
                </label>
              );
            })}
          </div>
        </div>
        <div className="grid gap-4 sm:grid-cols-3">
          <Field label="Minimum top-up (₹)"><input type="number" min={1} className={inputCls} value={draft.minTopup} onChange={(e) => set("minTopup", num(e.target.value) ?? 0)} /></Field>
          <Field label="Maximum top-up (₹)"><input type="number" min={1} className={inputCls} value={draft.maxTopup} onChange={(e) => set("maxTopup", num(e.target.value) ?? 0)} /></Field>
          <Field label="Balance limit (₹)" hint="The most credits one account can hold."><input type="number" min={100} className={inputCls} value={draft.maxBalance} onChange={(e) => set("maxBalance", num(e.target.value) ?? 0)} /></Field>
        </div>
        <Field label="Quick amounts (₹)" hint="Up to 6 buttons, separated by commas.">
          <input className={cn(inputCls, "font-mono")} value={presetText} onChange={(e) => setPresetText(e.target.value)}
            onBlur={() => set("presets", [...new Set(presetText.split(/[\s,]+/).map((x) => Number(x)).filter((n) => Number.isInteger(n) && n > 0))].slice(0, 6))} placeholder="250, 500, 1000, 2500" />
        </Field>
      </div>
      <SaveBar dirty={dirty} saving={saving} onSave={() => void submit()} onDiscard={() => { discard(); setPresetText(site.credits.presets.join(", ")); }} label="Save credit settings" />
    </Card>
  );
}
