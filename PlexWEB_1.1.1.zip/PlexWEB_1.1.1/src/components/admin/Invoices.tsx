import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Download, FileSpreadsheet, FileText, Receipt, Wallet } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PageLoader, Spinner } from "@/components/ui-px/Spinner";
import { Badge, EmptyState, StatCard } from "@/components/ui-px/page";
import { billingLabel, formatINR, productNames, type ProductKey } from "@/config/plans";
import { adminInvoicePdf, adminListInvoices } from "@/lib/invoices.functions";
import { cn } from "@/lib/utils";
import { inputCls, Segmented, td, th } from "./fields";
import { shownError } from "@/lib/public-error";

type Row = Awaited<ReturnType<typeof adminListInvoices>>[number];
type Category = "all" | "games" | "vps" | "bot" | "credits";
type Kind = "any" | "new" | "renewal" | "upgrade";

const PAGE = 50;
const categoryOf = (r: Row): Exclude<Category, "all"> => (r.kind === "credits" ? "credits" : r.product === "vps" ? "vps" : r.product === "bot" ? "bot" : "games");
const day = (s: string) => new Date(s).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric", timeZone: "Asia/Kolkata" });
const kindLabel: Record<string, string> = { new: "New service", renewal: "Renewal", upgrade: "Upgrade", credits: "Credits top-up" };
const itemName = (r: Row) => (r.kind === "credits" ? "PlexScale Credits" : `${productNames[r.product as ProductKey] ?? r.product} · ${r.planName}`);

function saveBytes(base64: string, filename: string, type: string) {
  const bytes = Uint8Array.from(atob(base64), (c) => c.charCodeAt(0));
  saveBlob(new Blob([bytes], { type }), filename);
}
function saveBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename; a.rel = "noopener";
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30_000);
}
const csvCell = (v: string | number) => {
  const s = String(v);
  // Neutralise spreadsheet formulas and quote every cell.
  const safe = /^[=+\-@\t\r]/.test(s) ? `'${s}` : s;
  return `"${safe.replace(/"/g, '""')}"`;
};

export function InvoicesPanel() {
  const list = useServerFn(adminListInvoices);
  const pdf = useServerFn(adminInvoicePdf);
  const { data, isLoading, error, refetch } = useQuery({ queryKey: ["admin-invoices"], queryFn: () => list() });
  const [category, setCategory] = useState<Category>("all");
  const [kind, setKind] = useState<Kind>("any");
  const [q, setQ] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [shown, setShown] = useState(PAGE);
  const [busy, setBusy] = useState<string | null>(null);

  const rows = useMemo(() => {
    const needle = q.trim().toLowerCase();
    const start = from ? Date.parse(`${from}T00:00:00+05:30`) : null;
    const end = to ? Date.parse(`${to}T23:59:59.999+05:30`) : null;
    return (data ?? []).filter((r) => {
      if (category !== "all" && categoryOf(r) !== category) return false;
      if (kind !== "any" && r.kind !== kind) return false;
      const t = Date.parse(r.paidAt);
      if (start !== null && t < start) return false;
      if (end !== null && t > end) return false;
      if (!needle) return true;
      return `${r.number ?? ""} ${r.customerEmail} ${r.customerName} ${r.serverName} ${r.planName} ${r.orderId} ${r.paymentRef ?? ""}`.toLowerCase().includes(needle);
    });
  }, [data, category, kind, q, from, to]);

  if (isLoading) return <PageLoader text="Loading invoices" className="min-h-[30vh]" />;
  if (error || !data) return <div className="panel p-6 text-sm"><p className="text-destructive">Could not load invoices.</p><Button className="mt-4" variant="secondary" onClick={() => void refetch()}>Try again</Button></div>;

  const counts = { all: data.length, games: 0, vps: 0, bot: 0, credits: 0 } as Record<Category, number>;
  for (const r of data) counts[categoryOf(r)]++;
  const billed = rows.filter((r) => r.status !== "refunded");
  const cash = billed.filter((r) => r.paidWith === "razorpay").reduce((s, r) => s + r.amount, 0);
  const viaCredits = billed.filter((r) => r.paidWith === "credits").reduce((s, r) => s + r.amount, 0);
  const topups = billed.filter((r) => r.kind === "credits").reduce((s, r) => s + r.amount, 0);

  async function download(r: Row) {
    setBusy(r.orderId);
    try {
      const res = await pdf({ data: { orderId: r.orderId } });
      saveBytes(res.base64, res.filename, "application/pdf");
      if (!r.number) void refetch();
    } catch (e) {
      toast.error(shownError(e, "The invoice couldn’t be downloaded. Please try again."));
    }
    setBusy(null);
  }

  function exportCsv() {
    const head = ["Invoice", "Date", "Customer", "Email", "Item", "Type", "Service", "Billing", "Amount (INR)", "Discount (INR)", "Paid with", "Payment ID", "Status", "Order ID"];
    const lines = rows.map((r) => [r.number ?? "", day(r.paidAt), r.customerName, r.customerEmail, itemName(r), kindLabel[r.kind] ?? r.kind, r.serverName, r.kind === "credits" ? "One time" : billingLabel(r.billing), r.amount, r.discount, r.paidWith === "credits" ? "PlexScale Credits" : "Razorpay", r.paymentRef ?? "", r.status, r.orderId].map(csvCell).join(","));
    saveBlob(new Blob([`\uFEFF${[head.map(csvCell).join(","), ...lines].join("\r\n")}`], { type: "text/csv;charset=utf-8" }), `plexscale-invoices-${new Date().toISOString().slice(0, 10)}.csv`);
  }

  const reset = () => { setCategory("all"); setKind("any"); setQ(""); setFrom(""); setTo(""); setShown(PAGE); };
  const filtered = category !== "all" || kind !== "any" || q || from || to;
  const page = rows.slice(0, shown);

  const DownloadBtn = ({ r, className }: { r: Row; className?: string }) => (
    <Button type="button" size="sm" variant="secondary" className={className} disabled={busy === r.orderId} onClick={() => void download(r)} aria-label={`Download invoice ${r.number ?? r.orderId.slice(0, 8)}`}>
      {busy === r.orderId ? <Spinner size="xs" /> : <Download />}PDF
    </Button>
  );
  const Paid = ({ r }: { r: Row }) => (r.paidWith === "credits" ? <Badge tone="info"><Wallet className="size-3" />Credits</Badge> : <Badge tone="muted">Razorpay</Badge>);
  const Status = ({ r }: { r: Row }) => (r.status === "refunded" ? <Badge tone="bad">Refunded</Badge> : <Badge tone="ok" dot>Paid</Badge>);

  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Invoices" value={rows.length.toLocaleString("en-IN")} icon={Receipt} hint={filtered ? `of ${data.length.toLocaleString("en-IN")} in total` : "All paid orders"} />
        <StatCard label="Paid by Razorpay" value={formatINR(cash)} icon={FileText} hint="Excludes refunded orders" />
        <StatCard label="Paid with credits" value={formatINR(viaCredits)} icon={Wallet} hint="Already counted at top-up" />
        <StatCard label="Credit top-ups" value={formatINR(topups)} icon={Wallet} tone="ok" />
      </div>

      <div className="panel space-y-4 p-4 md:p-5">
        <div className="-mx-1 overflow-x-auto px-1 pb-1">
          <Segmented label="Product" value={category} onChange={(v) => { setCategory(v); setShown(PAGE); }} options={[
            { value: "all", label: `All (${counts.all})` },
            { value: "games", label: `Game servers (${counts.games})` },
            { value: "vps", label: `VPS (${counts.vps})` },
            { value: "bot", label: `Bot hosting (${counts.bot})` },
            { value: "credits", label: `Credits (${counts.credits})` },
          ]} />
        </div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-[minmax(0,2fr)_minmax(0,1fr)_minmax(0,1fr)_minmax(0,1fr)]">
          <input value={q} onChange={(e) => { setQ(e.target.value); setShown(PAGE); }} placeholder="Search invoice, email, server or payment ID" aria-label="Search invoices" className={inputCls} />
          <select value={kind} onChange={(e) => { setKind(e.target.value as Kind); setShown(PAGE); }} aria-label="Type" className={inputCls}>
            <option value="any">Any type</option>
            <option value="new">New services</option>
            <option value="renewal">Renewals</option>
            <option value="upgrade">Upgrades</option>
          </select>
          <label className="relative flex items-center">
            <span className="pointer-events-none absolute left-3 text-xs text-muted-foreground">From</span>
            <input type="date" aria-label="From date" value={from} max={to || undefined} onChange={(e) => { setFrom(e.target.value); setShown(PAGE); }} className={cn(inputCls, "pl-12")} />
          </label>
          <label className="relative flex items-center">
            <span className="pointer-events-none absolute left-3 text-xs text-muted-foreground">To</span>
            <input type="date" aria-label="To date" value={to} min={from || undefined} onChange={(e) => { setTo(e.target.value); setShown(PAGE); }} className={cn(inputCls, "pl-9")} />
          </label>
        </div>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <p className="text-sm text-muted-foreground">{rows.length === 0 ? "No invoices match." : `Showing ${page.length.toLocaleString("en-IN")} of ${rows.length.toLocaleString("en-IN")}`}</p>
          <div className="flex flex-wrap gap-2">
            {filtered && <Button type="button" size="sm" variant="ghost" onClick={reset}>Clear filters</Button>}
            <Button type="button" size="sm" variant="secondary" disabled={rows.length === 0} onClick={exportCsv}><FileSpreadsheet />Export CSV</Button>
          </div>
        </div>
      </div>

      {data.length === 0 ? (
        <EmptyState icon={Receipt} title="No invoices yet" body="Every paid order, renewal, upgrade and credit top-up gets an invoice. They will appear here." />
      ) : (
        <>
          {/* Phones: one card per invoice */}
          <ul className="grid gap-3 md:hidden">
            {page.map((r) => (
              <li key={r.orderId} className="panel p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="font-display font-semibold">{r.number ?? "Not issued yet"}</p>
                    <p className="text-xs text-muted-foreground">{day(r.paidAt)} · {kindLabel[r.kind] ?? r.kind}</p>
                  </div>
                  <p className="shrink-0 font-display text-lg tabular-nums">{formatINR(r.amount)}</p>
                </div>
                <p className="mt-3 truncate text-sm">{itemName(r)}{r.serverName ? ` · ${r.serverName}` : ""}</p>
                <p className="truncate text-xs text-muted-foreground">{r.customerEmail || "Unknown customer"}</p>
                <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex flex-wrap gap-1.5"><Paid r={r} /><Status r={r} /></div>
                  <DownloadBtn r={r} />
                </div>
              </li>
            ))}
          </ul>

          {/* Tablets and desktops: table */}
          <div className="panel hidden overflow-x-auto md:block">
            <table className="w-full min-w-[820px] text-sm">
              <thead><tr><th className={th}>Invoice</th><th className={th}>Date</th><th className={th}>Customer</th><th className={th}>Item</th><th className={th}>Paid with</th><th className={cn(th, "text-right")}>Amount</th><th className={th}>Status</th><th className={cn(th, "text-right")}><span className="sr-only">Download</span></th></tr></thead>
              <tbody>
                {page.length === 0 && <tr><td className={td} colSpan={8}>No invoices match these filters.</td></tr>}
                {page.map((r) => (
                  <tr key={r.orderId}>
                    <td className={cn(td, "whitespace-nowrap font-semibold")}>{r.number ?? <span className="font-normal text-muted-foreground">Not issued yet</span>}</td>
                    <td className={cn(td, "whitespace-nowrap text-muted-foreground")}>{day(r.paidAt)}</td>
                    <td className={cn(td, "max-w-[220px]")}><p className="truncate">{r.customerEmail || "Unknown"}</p>{r.customerName && <p className="truncate text-xs text-muted-foreground">{r.customerName}</p>}</td>
                    <td className={cn(td, "max-w-[260px]")}><p className="truncate font-medium">{itemName(r)}</p><p className="truncate text-xs text-muted-foreground">{kindLabel[r.kind] ?? r.kind}{r.serverName ? ` · ${r.serverName}` : ""}</p></td>
                    <td className={td}><Paid r={r} /></td>
                    <td className={cn(td, "whitespace-nowrap text-right font-semibold tabular-nums")}>{formatINR(r.amount)}</td>
                    <td className={td}><Status r={r} /></td>
                    <td className={cn(td, "text-right")}><DownloadBtn r={r} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {rows.length > shown && <div className="flex justify-center"><Button type="button" variant="secondary" onClick={() => setShown((n) => n + PAGE)}>Show {Math.min(PAGE, rows.length - shown)} more</Button></div>}
        </>
      )}
    </div>
  );
}
