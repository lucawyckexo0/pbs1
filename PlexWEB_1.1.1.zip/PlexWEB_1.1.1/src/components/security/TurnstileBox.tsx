import { useEffect, useImperativeHandle, useRef, forwardRef } from "react";

const TS_SRC = "https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit";
type TurnstileApi = { render: (el: HTMLElement, opts: Record<string, unknown>) => string; reset: (id: string) => void; remove: (id: string) => void };
type TurnstileWindow = Window & { turnstile?: TurnstileApi };

function loadTurnstile(): Promise<TurnstileApi> {
  const w = window as TurnstileWindow;
  if (w.turnstile) return Promise.resolve(w.turnstile);
  return new Promise((resolve, reject) => {
    let s = document.querySelector<HTMLScriptElement>(`script[src="${TS_SRC}"]`);
    if (!s) {
      s = document.createElement("script");
      s.src = TS_SRC; s.async = true; s.defer = true;
      document.head.appendChild(s);
    }
    const done = () => (w.turnstile ? resolve(w.turnstile) : reject(new Error("Turnstile unavailable")));
    s.addEventListener("load", done, { once: true });
    s.addEventListener("error", () => reject(new Error("Turnstile failed to load")), { once: true });
    window.setTimeout(() => { if (w.turnstile) resolve(w.turnstile); }, 0);
  });
}

export type TurnstileHandle = { reset: () => void };

/** Cloudflare Turnstile check. The token goes to the server, which verifies it once. */
export const TurnstileBox = forwardRef<TurnstileHandle, { siteKey: string; action: string; onToken: (token: string | null) => void; onError?: () => void }>(
  function TurnstileBox({ siteKey, action, onToken, onError }, ref) {
    const box = useRef<HTMLDivElement>(null);
    const id = useRef<string | null>(null);
    const cb = useRef({ onToken, onError });
    cb.current = { onToken, onError };
    useImperativeHandle(ref, () => ({ reset: () => { const w = window as TurnstileWindow; if (id.current && w.turnstile) w.turnstile.reset(id.current); cb.current.onToken(null); } }), []);
    useEffect(() => {
      let cancelled = false;
      loadTurnstile().then((ts) => {
        if (cancelled || !box.current) return;
        id.current = ts.render(box.current, {
          sitekey: siteKey, action, theme: "dark", size: "flexible", language: "auto",
          // Cloudflare refreshes expired tokens and retries failed checks itself, so the page stays in sync.
          "refresh-expired": "auto", "refresh-timeout": "auto", retry: "auto",
          callback: (t: string) => cb.current.onToken(t),
          "expired-callback": () => cb.current.onToken(null),
          "timeout-callback": () => cb.current.onToken(null),
          "error-callback": () => { cb.current.onToken(null); cb.current.onError?.(); },
        });
      }).catch(() => { if (!cancelled) cb.current.onError?.(); });
      return () => {
        cancelled = true;
        const w = window as TurnstileWindow;
        if (id.current && w.turnstile) w.turnstile.remove(id.current);
        id.current = null;
      };
    }, [siteKey, action]);
    return <div ref={box} aria-label="Security check" className="min-h-[65px] w-full overflow-hidden rounded-md" />;
  },
);
