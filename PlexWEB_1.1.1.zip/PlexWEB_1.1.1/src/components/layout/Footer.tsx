import { Link } from "@tanstack/react-router";
import { Activity, ExternalLink } from "lucide-react";
import { img } from "@/config/images";
import { site } from "@/config/site";
import { TrustpilotMark } from "@/components/layout/Trustpilot";

type FooterLink = { label: string; to?: string; hash?: string; href?: string; trustpilot?: boolean };

const cols: { title: string; links: FooterLink[] }[] = [
  { title: "Products", links: [{ label: "Minecraft", to: "/minecraft" }, { label: "Hytale", to: "/hytale" }, { label: "Counter Strike 2", to: "/counter-strike-2" }, { label: "Rust", to: "/rust" }, { label: "VPS", to: "/vps" }, { label: "Bot Hosting", to: "/bot-hosting" }] },
  { title: "Resources", links: [{ label: "Locations", to: "/", hash: "locations" }, { label: "Status", href: site.statusUrl }, { label: "Queries", to: "/queries" }, { label: "Support tickets", to: "/support" }, { label: "Trustpilot", href: site.trustpilotUrl, trustpilot: true }] },
  { title: "Company", links: [{ label: "About", to: "/about" }, { label: "Legal", href: site.legalUrl }, { label: "Billing", to: "/billing" }, { label: "Contact", to: "/contact" }] },
];

const legal = [["Terms", "terms"], ["Privacy", "privacy"], ["Refunds", "refunds"], ["Acceptable Use", "acceptable-use"], ["SLA", "sla"]] as const;
const linkCls = "inline-flex items-center gap-1.5 text-muted-foreground transition-colors hover:text-foreground";

export function Footer() {
  return (
    <footer className="border-t border-steel bg-ink">
      <div className="container-px grid gap-12 py-16 md:grid-cols-12">
        <div className="md:col-span-6">
          <span className="flex items-center gap-2.5"><img src={img.pmark} alt="" width={36.8} height={36.8} loading="lazy" className="size-[36.8px] object-contain" /><span className="font-display text-[20.7px] font-semibold text-foreground">PlexScale</span></span>
          <p className="mt-6 max-w-xs text-sm text-muted-foreground">{site.blurb}</p>
          <a href={site.statusUrl} target="_blank" rel="noopener noreferrer" className="mt-6 inline-flex items-center gap-2 rounded-full border border-steel px-3 py-1 text-xs text-muted-foreground hover:text-foreground">
            <Activity className="size-3.5 text-ok" /> System status <ExternalLink className="size-3" />
          </a>
        </div>
        {cols.map((c) => (
          <div key={c.title} className="md:col-span-2">
            <h3 className="font-display text-sm font-semibold">{c.title}</h3>
            <ul className="mt-4 space-y-2 text-sm">
              {c.links.map((l) => (
                <li key={l.label}>
                  {l.href ? (
                    <a href={l.href} target="_blank" rel="noopener noreferrer" className={linkCls}>{l.trustpilot && <TrustpilotMark className="size-3.5" />}{l.label}</a>
                  ) : l.hash ? (
                    <Link to="/" hash={l.hash} className={linkCls}>{l.label}</Link>
                  ) : (
                    <Link to={l.to as "/"} className={linkCls}>{l.label}</Link>
                  )}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="border-t border-steel">
        <div className="container-px flex flex-col gap-3 py-6 text-xs text-muted-foreground md:flex-row md:items-center md:justify-between">
          <p>{site.copyright}</p>
          <ul className="flex flex-wrap gap-x-4 gap-y-2">
            {legal.map(([l, d]) => (
              <li key={d}><Link to="/legal/$doc" params={{ doc: d }} className="hover:text-foreground">{l}</Link></li>
            ))}
          </ul>
        </div>
      </div>
    </footer>
  );
}
