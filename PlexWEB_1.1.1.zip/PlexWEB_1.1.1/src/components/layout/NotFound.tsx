import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";

export function NotFound() {
  return (
    <section className="flex min-h-[70vh] items-center justify-center px-4 py-16">
      <div className="max-w-md text-center">
        <p className="eyebrow">PlexScale · Site syncing</p>
        <h1 className="mt-4 text-6xl">404</h1>
        <p className="mt-4 text-muted-foreground">We couldn’t find that page. Your account and services remain unchanged.</p>
        <Button asChild className="mt-6"><Link to="/">Return home</Link></Button>
      </div>
    </section>
  );
}
