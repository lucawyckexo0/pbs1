import { describe, expect, it } from "vitest";
import { readdirSync, readFileSync } from "node:fs";
import path from "node:path";

// Fails if any public table in the migrations is created without row level security and grants.
const dir = path.resolve(__dirname, "../../db/migrations");
const sql = readdirSync(dir).filter((f) => f.endsWith(".sql")).sort().map((f) => readFileSync(path.join(dir, f), "utf8")).join("\n");
const tables = [...sql.matchAll(/CREATE TABLE (?:IF NOT EXISTS )?public\.(\w+)/gi)].map((m) => m[1]!);

describe("Database security rules", () => {
  it("finds the application tables", () => expect(tables.length).toBeGreaterThan(10));
  for (const t of tables) {
    it(`${t} has row level security enabled`, () => {
      expect(sql).toMatch(new RegExp(`ALTER TABLE public\\.${t} ENABLE ROW LEVEL SECURITY`, "i"));
    });
    it(`${t} has explicit grants`, () => {
      expect(sql).toMatch(new RegExp(`GRANT [A-Z, ()_]+ ON public\\.${t} TO`, "i"));
    });
  }
  it("never grants anon access to private tables", () => {
    for (const t of ["orders", "coupons", "panel_alerts", "panel_settings", "email_settings", "audit_log", "rate_limits", "webhook_events", "profiles", "refunds", "invoices", "credit_wallets", "credit_transactions"]) {
      expect(sql).not.toMatch(new RegExp(`GRANT [^;]* ON public\\.${t} TO [^;]*anon`, "i"));
    }
  });
  it("customers can never write credit balances or the credit ledger", () => {
    for (const t of ["credit_wallets", "credit_transactions"]) {
      expect(sql).not.toMatch(new RegExp(`GRANT [^;]*(INSERT|UPDATE|DELETE|ALL)[^;]* ON public\\.${t} TO [^;]*authenticated`, "i"));
    }
    expect(sql).not.toMatch(/GRANT [^;]*(UPDATE|DELETE)[^;]* ON public\.credit_transactions/i);
  });
  it("credit functions are callable by the server only", () => {
    for (const fn of ["credit_topup", "spend_credits", "refund_order_to_credits", "admin_adjust_credits"]) {
      expect(sql).toMatch(new RegExp(`REVOKE ALL ON FUNCTION public\\.${fn}\\([^)]*\\) FROM PUBLIC, anon, authenticated`, "i"));
    }
  });
  it("keeps the audit log append-only", () => {
    expect(sql).not.toMatch(/GRANT ALL ON public\.audit_log/i);
    expect(sql).not.toMatch(/GRANT [^;]*(UPDATE|DELETE)[^;]* ON public\.audit_log/i);
  });
});
