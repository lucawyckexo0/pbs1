import { describe, expect, it } from "vitest";
import { PRELOADER_MAX_MS, isNearFold } from "@/components/layout/LandingPreloader";

describe("landing preloader", () => {
  it("never holds the page longer than 5 seconds", () => {
    expect(PRELOADER_MAX_MS).toBeGreaterThanOrEqual(3000);
    expect(PRELOADER_MAX_MS).toBeLessThanOrEqual(5000);
  });
  it("only waits for images in the first screens", () => {
    expect(isNearFold(100, 900)).toBe(true);
    expect(isNearFold(5000, 900)).toBe(false);
  });
});
