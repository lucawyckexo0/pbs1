import { describe, expect, it } from "vitest";
import { normalizeIp } from "@/lib/ip";

describe("admin activity IP", () => {
  it("keeps a plain IPv4", () => expect(normalizeIp(" 203.0.113.7 ")).toBe("203.0.113.7"));
  it("unwraps IPv4-mapped IPv6 to IPv4", () => expect(normalizeIp("::ffff:198.51.100.4")).toBe("198.51.100.4"));
  it("keeps IPv6 when no IPv4 exists", () => expect(normalizeIp("2001:DB8::1")).toBe("2001:db8::1"));
  it("rejects junk header text", () => {
    expect(normalizeIp("<script>")).toBeNull();
    expect(normalizeIp("999.1.1.1")).toBeNull();
    expect(normalizeIp("")).toBeNull();
  });
});
