import { describe, expect, it } from "vitest";
import { botPlans, gamePlans } from "@/config/plans";

describe("Hosting plan series", () => {
  it.each([
    ["minecraft", "Mark", 8],
    ["hytale", "Tale", 8],
    ["cs2", "Strike", 8],
    ["rust", "Raid", 5],
  ] as const)("uses the requested names and IDs for %s", (game, series, count) => {
    const plans = gamePlans(game);
    expect(plans).toHaveLength(count);
    expect(plans.map(({ name, id }) => ({ name, id }))).toEqual(
      Array.from({ length: count }, (_, i) => ({ name: `${series} ${i + 1}`, id: `${series.toLowerCase()}-${i + 1}` })),
    );
  });

  it("uses BOT 1–4 with matching IDs", () => {
    expect(botPlans.map(({ name, id }) => ({ name, id }))).toEqual([
      { name: "BOT 1", id: "bot-1" }, { name: "BOT 2", id: "bot-2" },
      { name: "BOT 3", id: "bot-3" }, { name: "BOT 4", id: "bot-4" },
    ]);
  });
});
import { botPlans as _bots, gamePlans as _games, vcoreLabel as _vc } from "@/config/plans";
describe("CPU allowance per plan", () => {
  it("game plans scale from 50% to 500% CPU", () => {
    expect(_games("minecraft").map((p) => p.cpuPercent)).toEqual([50, 100, 150, 200, 250, 300, 400, 500]);
  });
  it("bot plans get 25%, 50%, 75% and 100% CPU", () => {
    expect(_bots.map((p) => p.cpuPercent)).toEqual([25, 50, 75, 100]);
  });
  it("shows CPU % as vCores", () => {
    expect(_vc(_games("hytale")[0]!)).toBe("0.50 vCores");
  });
});
