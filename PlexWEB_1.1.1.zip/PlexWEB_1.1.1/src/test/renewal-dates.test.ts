import { describe, expect, it } from "vitest";
import { addMonthsClamped } from "@/config/plans";

const iso = (from: string, months: number) => addMonthsClamped(new Date(from), months).toISOString();

describe("addMonthsClamped", () => {
  it("stops at the end of a short month instead of rolling into the next one", () => {
    expect(iso("2026-01-31T10:00:00Z", 1)).toBe("2026-02-28T10:00:00.000Z");
    expect(iso("2026-11-30T10:00:00Z", 3)).toBe("2027-02-28T10:00:00.000Z");
    expect(iso("2028-02-29T00:00:00Z", 12)).toBe("2029-02-28T00:00:00.000Z");
  });
  it("keeps the day and time when the target month is long enough", () => {
    expect(iso("2026-12-15T08:30:00Z", 1)).toBe("2027-01-15T08:30:00.000Z");
    expect(iso("2027-08-31T00:00:00Z", 6)).toBe("2028-02-29T00:00:00.000Z");
  });
  it("does not change the date it was given", () => {
    const d = new Date("2026-01-31T00:00:00Z");
    addMonthsClamped(d, 1);
    expect(d.toISOString()).toBe("2026-01-31T00:00:00.000Z");
  });
});
