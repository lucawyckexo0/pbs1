import { describe, expect, it } from "vitest";
import { periodTotal, type Plan } from "@/config/plans";
import { upgradeQuote } from "@/config/upgrade-rules";
import { isOrderRefundEligible, REFUND_WINDOW_MS } from "@/config/refund-rules";

const plan = (id: string, monthly: number, ramGb: number, diskGb = 40, cpuPercent = 100) => ({ id, name: id, monthly, ramGb, diskGb, cpuPercent }) as unknown as Plan;

describe("Period prices round to whole rupees", () => {
  it("quarterly 5% off rounds to nearest rupee", () => expect(periodTotal(199, "quarterly")).toBe(567)); // 567.15
  it("semi-annual 10% off", () => expect(periodTotal(333, "semiannual")).toBe(1798)); // 1798.2
  it("yearly 15% off rounds half up", () => expect(periodTotal(150, "yearly")).toBe(1530));
  it("monthly is unchanged", () => expect(periodTotal(1, "monthly")).toBe(1));
});

describe("Upgrade proration edges", () => {
  const now = Date.parse("2026-11-11T00:00:00Z");
  const from = plan("s", 199, 4);
  const to = plan("m", 299, 6);
  it("rounds the prorated amount up", () => {
    const q = upgradeQuote(from, to, "monthly", new Date(now + 10 * 864e5).toISOString(), now);
    expect(q.ok && q.amount).toBe(34); // 100 x 10 / 30 = 33.33 → 34
  });
  it("charges at least ₹1", () => {
    const tiny = plan("t", 200, 4);
    const q = upgradeQuote(from, tiny, "monthly", new Date(now + 2 * 864e5).toISOString(), now);
    expect(q.ok && q.amount).toBe(1);
  });
  it("refuses within a day of expiry", () => {
    expect(upgradeQuote(from, to, "monthly", new Date(now + 23 * 3600_000).toISOString(), now).ok).toBe(false);
  });
  it("refuses plans that shrink disk", () => {
    expect(upgradeQuote(from, plan("d", 399, 8, 20), "monthly", new Date(now + 10 * 864e5).toISOString(), now).ok).toBe(false);
  });
});

describe("Refund window edges", () => {
  const paid = "2026-11-11T00:00:00.000Z";
  const t = Date.parse(paid);
  it("is open at exactly 24 hours", () => expect(isOrderRefundEligible("new", "rust", paid, t + REFUND_WINDOW_MS)).toBe(true));
  it("is closed one millisecond later", () => expect(isOrderRefundEligible("new", "rust", paid, t + REFUND_WINDOW_MS + 1)).toBe(false));
  it("never covers renewals or bot hosting", () => {
    expect(isOrderRefundEligible("renewal", "rust", paid, t + 1000)).toBe(false);
    expect(isOrderRefundEligible("new", "bot", paid, t + 1000)).toBe(false);
  });
});
