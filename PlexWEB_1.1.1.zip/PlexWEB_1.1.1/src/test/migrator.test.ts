// @vitest-environment node
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import { comparePlan, loadMigrations, migrate, MigrationError, status, type Migration } from "../../scripts/lib/migrator.mjs";
import { emptyDatabase, MIGRATIONS_DIR, pgliteAdapter } from "./helpers/db-harness";

// The 1.1.0 migrations must stay byte-for-byte identical forever (their checksums are in every ledger).
const FROZEN_1_1_0: Record<string, string> = {
  "0000_plexscale_schema.sql": "c8f22dd899b8634cebf4fd01c2af7a57205a2192d00e258cfa3bec87ecf103ba",
  "0001_admin_email_grants_and_stack_updates.sql": "1ce27cd7d4a2caccd9a4b1761a584e2de6e7fd80efa1d5a1b169d6a01ee18821",
  "0002_set_maintenance_function.sql": "f217fc842fe722f0c85fb7e6ff2af06aad408d06ccf95b8d04f5b05e8cfaca32",
  "0003_retire_support_ids_add_settings_backups.sql": "24a960197cc8d0260e9dbc8a4cc418f04aabbebed6b9e4f3522ca3d58b2dfe1b",
  "0004_retire_updates_and_settings_backups.sql": "9f2f4b058d5a96540c9ea104667d32e99b8d49a3ec0dcf111f6899ed7f98218a",
  "0005_plexus_vps.sql": "aadd05a9ea0c4396060c453372e379fa09b4d6b55e54250c33e2f9fb4980194d",
  "0006_credits.sql": "92aa5f99a8bbda6b358810ad8456d3c8e0033ffb63e94b9d1bad56a0167c0e01",
  "0007_billing_guards_and_system_ops.sql": "de64ea1264c6a8959d22065c0fca63375b64ac2da92c1b6d5561322b1f00a96e",
};

const all = loadMigrations(MIGRATIONS_DIR);
const upTo = (id: string) => all.slice(0, all.findIndex((m) => m.id === id) + 1);
const ledger = async (db: Awaited<ReturnType<typeof emptyDatabase>>) =>
  (await db.query<{ id: string; checksum: string; baseline: boolean }>("SELECT id, checksum, baseline FROM plexscale_meta.schema_migrations ORDER BY id")).rows;
const exists = async (db: Awaited<ReturnType<typeof emptyDatabase>>, rel: string) =>
  (await db.query<{ r: string | null }>("SELECT to_regclass($1)::text r", [rel])).rows[0]!.r !== null;
const errorOf = async (p: Promise<unknown>) => { try { await p; return null; } catch (e) { return e as MigrationError; } };

describe("migration files", () => {
  it("are numbered 0000 to 0008 without gaps", () => {
    expect(all.map((m) => m.id)).toEqual(["0000", "0001", "0002", "0003", "0004", "0005", "0006", "0007", "0008"]);
  });

  it("keep every 1.1.0 migration byte-for-byte unchanged", () => {
    for (const [name, sum] of Object.entries(FROZEN_1_1_0)) expect(all.find((m) => m.name === name)?.checksum).toBe(sum);
  });

  it("ship a checksum manifest that matches the files", () => {
    const lines = readFileSync(join(MIGRATIONS_DIR, "..", "migrations.sha256"), "utf8").trim().split("\n");
    expect(lines).toEqual(all.map((m) => `${m.checksum}  ${m.name}`));
  });

  it("0008 only drops the retired backup objects", () => {
    const sql = all.find((m) => m.id === "0008")!.sql.replace(/--.*$/gm, "");
    const statements = sql.split(";").map((s) => s.trim()).filter(Boolean);
    expect(statements.length).toBeGreaterThan(0);
    for (const s of statements) expect(s).toMatch(/^DROP (TABLE|FUNCTION) IF EXISTS public\.(system_backups|system_update_runs|settings_backups|stack_update_runs|create_system_backup|restore_system_backup|backup_tables|create_settings_backup|restore_settings_backup)\b/);
  });
});

describe("migration runner", () => {
  it("applies everything on a fresh database and records each checksum", async () => {
    const db = await emptyDatabase();
    const r = await migrate(pgliteAdapter(db), all, { appVersion: "1.1.1" });
    expect(r.applied).toHaveLength(9);
    expect((await ledger(db)).map((x) => x.checksum)).toEqual(all.map((m) => m.checksum));
    const again = await migrate(pgliteAdapter(db), all, { appVersion: "1.1.1" });
    expect(again.applied).toEqual([]);
  }, 60_000);

  it("upgrading a 1.1.0 database applies only 0008 and keeps existing data", async () => {
    const db = await emptyDatabase();
    await migrate(pgliteAdapter(db), upTo("0007"), { appVersion: "1.1.0" });
    const user = "11111111-1111-1111-1111-111111111111";
    await db.query("INSERT INTO auth.users (id, email) VALUES ($1, 'a@example.com')", [user]);
    await db.query("INSERT INTO public.orders (user_id, kind, product, plan_id, plan_name, billing, location, amount) VALUES ($1, 'new', 'minecraft', 'mc-2', 'Test', 'monthly', 'mumbai', 100)", [user]);
    await db.query("SELECT public.create_system_backup(NULL, 'manual', NULL)");
    expect(await exists(db, "public.system_backups")).toBe(true);

    const r = await migrate(pgliteAdapter(db), all, { appVersion: "1.1.1" });
    expect(r.applied).toEqual(["0008_drop_in_database_backups.sql"]);
    expect(await exists(db, "public.system_backups")).toBe(false);
    expect((await db.query<{ n: number }>("SELECT count(*)::int n FROM public.orders")).rows[0]!.n).toBe(1);
  }, 60_000);

  it("refuses to run when an applied migration was edited", async () => {
    const db = await emptyDatabase();
    await migrate(pgliteAdapter(db), upTo("0007"), { appVersion: "1.1.0" });
    const edited: Migration[] = all.map((m) => (m.id === "0003" ? { ...m, checksum: "0".repeat(64) } : m));
    const e = await errorOf(migrate(pgliteAdapter(db), edited, { appVersion: "1.1.1" }));
    expect(e?.problems.join(" ")).toMatch(/0003.*changed after it was applied/);
    expect(await exists(db, "public.system_backups")).toBe(true); // 0008 was not applied
  }, 60_000);

  it("refuses a package that is older than the database", async () => {
    const db = await emptyDatabase();
    await migrate(pgliteAdapter(db), all, { appVersion: "1.1.1" });
    const e = await errorOf(migrate(pgliteAdapter(db), upTo("0007"), { appVersion: "1.1.0" }));
    expect(e?.problems.join(" ")).toMatch(/0008.*does not include/);
  }, 60_000);

  it("rolls back every pending migration when one of them fails", async () => {
    const db = await emptyDatabase();
    await migrate(pgliteAdapter(db), upTo("0006"), { appVersion: "1.1.0" });
    const broken: Migration[] = [...upTo("0008"), { id: "0009", name: "0009_broken.sql", sql: "CREATE TABLE public.never_kept (id int); SELECT 1/0;", checksum: "f".repeat(64) }];
    const e = await errorOf(migrate(pgliteAdapter(db), broken, { appVersion: "9.9.9" }));
    expect(e?.message).toMatch(/0009_broken\.sql failed/);
    expect((await ledger(db)).map((r) => r.id)).toEqual(upTo("0006").map((m) => m.id));
    expect(await exists(db, "public.never_kept")).toBe(false);
    expect(await exists(db, "public.system_backups")).toBe(false); // 0007 from the same run was rolled back too
  }, 60_000);

  it("adopts a database migrated by the old tooling only with an explicit baseline", async () => {
    const db = await emptyDatabase();
    for (const m of upTo("0007")) await db.exec(m.sql);
    const refused = await errorOf(migrate(pgliteAdapter(db), all, { appVersion: "1.1.1" }));
    expect(refused?.message).toMatch(/--baseline/);
    const r = await migrate(pgliteAdapter(db), all, { appVersion: "1.1.1", baseline: "0007" });
    expect(r.baselined).toHaveLength(8);
    expect(r.applied).toEqual(["0008_drop_in_database_backups.sql"]);
    expect((await ledger(db)).filter((x) => x.baseline)).toHaveLength(8);
  }, 60_000);

  it("reports status without changing anything", async () => {
    const db = await emptyDatabase();
    await migrate(pgliteAdapter(db), upTo("0007"), { appVersion: "1.1.0" });
    const s = await status(pgliteAdapter(db), all);
    expect(s.pending.map((m) => m.id)).toEqual(["0008"]);
    expect(s.problems).toEqual([]);
    expect(comparePlan([], all).pending).toHaveLength(9);
  }, 60_000);
});
