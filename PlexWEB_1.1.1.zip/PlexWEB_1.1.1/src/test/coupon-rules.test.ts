import { describe, expect, it } from "vitest";
import { couponDiscount, couponErrorMessage, couponInput, couponProblem, type CouponRow } from "@/config/coupon-rules";

const base: CouponRow = { kind: "percent", value: 20, max_discount: null, active: true, starts_at: null, expires_at: null, products: [], min_amount: 0, max_uses: null, per_user_limit: 1 };
const ctx = { product: "minecraft", amount: 999, uses: 0, userUses: 0, now: Date.parse("2026-11-11T00:00:00Z") };

describe("Coupon discounts", () => {
  it("percent coupons round down", () => expect(couponDiscount(base, 999)).toBe(199));
  it("percent coupons respect the cap", () => expect(couponDiscount({ ...base, max_discount: 100 }, 999)).toBe(100));
  it("fixed coupons take a flat amount", () => expect(couponDiscount({ kind: "fixed", value: 150, max_discount: null }, 999)).toBe(150));
  it("customers always pay at least ₹1", () => {
    expect(couponDiscount({ kind: "percent", value: 100, max_discount: null }, 500)).toBe(499);
    expect(couponDiscount({ kind: "fixed", value: 5000, max_discount: null }, 500)).toBe(499);
    expect(couponDiscount(base, 1)).toBe(0);
  });
});

describe("Coupon limits", () => {
  it("applies when every rule passes", () => expect(couponProblem(base, ctx)).toBeNull());
  it("is refused when switched off, early or expired", () => {
    expect(couponProblem({ ...base, active: false }, ctx)).toBe("coupon_invalid");
    expect(couponProblem({ ...base, starts_at: "2026-11-12T00:00:00Z" }, ctx)).toBe("coupon_not_started");
    expect(couponProblem({ ...base, expires_at: "2026-11-11T00:00:00Z" }, ctx)).toBe("coupon_expired");
  });
  it("is refused for other products and small orders", () => {
    expect(couponProblem({ ...base, products: ["rust"] }, ctx)).toBe("coupon_product");
    expect(couponProblem({ ...base, min_amount: 1000 }, ctx)).toBe("coupon_min_amount");
  });
  it("is refused once total or per-customer uses run out", () => {
    expect(couponProblem({ ...base, max_uses: 5 }, { ...ctx, uses: 5 })).toBe("coupon_used_up");
    expect(couponProblem(base, { ...ctx, userUses: 1 })).toBe("coupon_already_used");
    expect(couponProblem({ ...base, per_user_limit: 2 }, { ...ctx, userUses: 1 })).toBeNull();
  });
  it("maps database errors to customer messages", () => {
    expect(couponErrorMessage('ERROR: coupon_used_up')).toBe("That coupon has been fully used.");
    expect(couponErrorMessage("something else")).toBe("That coupon could not be applied. Please try again.");
  });
});

describe("Admin coupon input", () => {
  it("upper-cases codes and rejects bad ones", () => {
    expect(couponInput.parse({ code: " launch20 ", kind: "percent", value: 20 }).code).toBe("LAUNCH20");
    expect(couponInput.safeParse({ code: "a b", kind: "percent", value: 20 }).success).toBe(false);
  });
  it("caps percentages at 100 and needs expiry after start", () => {
    expect(couponInput.safeParse({ code: "BIG", kind: "percent", value: 101 }).success).toBe(false);
    expect(couponInput.safeParse({ code: "WIN", kind: "fixed", value: 50, startsAt: "2026-11-12T00:00:00Z", expiresAt: "2026-11-11T00:00:00Z" }).success).toBe(false);
  });
});
