import { QueryClient } from "@tanstack/react-query";
import { createRouter, rootRouteId } from "@tanstack/react-router";
import { describe, expect, it } from "vitest";

import { routeTree } from "@/routeTree.gen";

// Match routes without running loaders or rendering: loaders may need a server or
// network the test run lacks, and jsdom never loads the stylesheets React waits on.
describe("App routing", () => {
  it("matches a page for / instead of falling back to not found", () => {
    const router = createRouter({ routeTree, context: { queryClient: new QueryClient() } });
    expect(router.matchRoutes("/").at(-1)?.routeId).not.toBe(rootRouteId);
  });

  it.each([["/queries", "/queries"], ["/billing", "/_authenticated/billing"], ["/account", "/_authenticated/account"], ["/deploy", "/_authenticated/deploy/"], ["/deploy/status/abc", "/_authenticated/deploy/status/$orderId"], ["/auth", "/auth"], ["/contact", "/contact"], ["/administrator", "/administrator"], ["/support", "/_authenticated/support/"], ["/support/new", "/_authenticated/support/new"], ["/support/0b7c1a52-7a44-4a8e-9f00-2f1b5f0e4d11", "/_authenticated/support/$ticketId"]])("resolves %s", (path, id) => {
    const router = createRouter({ routeTree, context: { queryClient: new QueryClient() } });
    expect(router.matchRoutes(path).at(-1)?.routeId).toBe(id);
  });

  it.each(["/faq", "/login", "/dashboard", "/panel", "/signup", "/status"])("has no page at %s", (path) => {
    const router = createRouter({ routeTree, context: { queryClient: new QueryClient() } });
    expect(router.matchRoutes(path).at(-1)?.routeId).toBe(rootRouteId);
  });
});
