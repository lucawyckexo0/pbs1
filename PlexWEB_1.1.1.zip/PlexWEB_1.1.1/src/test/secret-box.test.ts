import { describe, expect, it, beforeAll } from "vitest";
import { openSecret, sealSecret } from "@/lib/secret-box.server";

describe("Stored credential encryption", () => {
  beforeAll(() => { process.env["SETTINGS_ENCRYPTION_KEY"] = "k".repeat(48); });
  it("writes the v2 format and reads it back", async () => {
    const sealed = await sealSecret("smtp-pass");
    expect(sealed.startsWith("v2:")).toBe(true);
    expect(await openSecret(sealed)).toBe("smtp-pass");
  });
  it("still reads values sealed in the old v1 format", async () => {
    const enc = new TextEncoder();
    const digest = await crypto.subtle.digest("SHA-256", enc.encode(`plexscale-settings-v1:${"k".repeat(48)}`));
    const key = await crypto.subtle.importKey("raw", digest, { name: "AES-GCM" }, false, ["encrypt"]);
    const iv = new Uint8Array(12);
    const ct = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, enc.encode("old")));
    const all = new Uint8Array([...iv, ...ct]);
    expect(await openSecret(`v1:${btoa(String.fromCharCode(...all))}`)).toBe("old");
  });
  it("rejects unknown formats", async () => {
    expect(await openSecret("plain")).toBeNull();
  });
});
