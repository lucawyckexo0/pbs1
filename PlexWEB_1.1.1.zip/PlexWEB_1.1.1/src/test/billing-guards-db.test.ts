// @vitest-environment node
import { PGlite } from "@electric-sql/pglite";
import { beforeAll, describe, expect, it } from "vitest";
import { migratedDatabase } from "./helpers/db-harness";

// Runs the migrations on an in-memory Postgres and checks renewal, late payment and top-up rules, and migration 0008.
const A = "11111111-1111-1111-1111-111111111111";
const B = "22222222-2222-2222-2222-222222222222";
let db: PGlite;

const one = async <T = Record<string, unknown>>(sql: string, params: unknown[] = []) => (await db.query<T>(sql, params)).rows[0] as T;
const fails = async (sql: string, params: unknown[] = []) => { try { await db.query(sql, params); return null; } catch (e) { return (e as Error).message; } };
const order = async (fields: Record<string, unknown>) => {
  const row = { user_id: A, kind: "new", product: "minecraft", plan_id: "mc-2", plan_name: "Test", billing: "monthly", location: "mumbai", amount: 100, ...fields };
  const keys = Object.keys(row);
  return (await one<{ id: string }>(`INSERT INTO public.orders (${keys.join(", ")}) VALUES (${keys.map((_, i) => `$${i + 1}`).join(", ")}) RETURNING id`, Object.values(row))).id;
};
const get = (id: string) => one<{ status: string; renews_at: string | null; razorpay_payment_id: string | null; plan_id: string }>("SELECT * FROM public.orders WHERE id = $1", [id]);
const hasRefund = async (id: string) => Boolean(await one("SELECT 1 AS x FROM public.refunds WHERE order_id = $1", [id]));

beforeAll(async () => {
  db = await migratedDatabase();
  await db.query("INSERT INTO auth.users (id, email) VALUES ($1, 'a@example.com'), ($2, 'b@example.com')", [A, B]);
}, 60_000);

describe("renewals", () => {
  it("extends the service by the paid period exactly once", async () => {
    const parent = await order({ status: "active", renews_at: new Date(Date.now() + 5 * 864e5).toISOString() });
    const renewal = await order({ kind: "renewal", parent_order_id: parent });
    const before = Date.parse((await get(parent)).renews_at!);
    expect((await one<{ r: string }>("SELECT public.apply_renewal($1, 'pay_RENEW00001') r", [renewal])).r).toBe("extended_active");
    expect((await one<{ r: string }>("SELECT public.apply_renewal($1, 'pay_RENEW00002') r", [renewal])).r).toBe("noop");
    const days = (Date.parse((await get(parent)).renews_at!) - before) / 864e5;
    expect(days).toBeGreaterThanOrEqual(28);
    expect(days).toBeLessThanOrEqual(31);
  });

  it("does not extend an upgraded service with an old cheaper renewal", async () => {
    const parent = await order({ status: "active", plan_id: "mc-2", renews_at: new Date(Date.now() + 864e5).toISOString() });
    const oldRenewal = await order({ kind: "renewal", parent_order_id: parent, plan_id: "mc-2" });
    await db.query("UPDATE public.orders SET plan_id = 'mc-8' WHERE id = $1", [parent]);
    const before = (await get(parent)).renews_at;
    expect((await one<{ r: string }>("SELECT public.apply_renewal($1, 'pay_RENEW00003') r", [oldRenewal])).r).toBe("review");
    expect(String((await get(parent)).renews_at)).toBe(String(before));
    expect(await hasRefund(oldRenewal)).toBe(true);
  });

  it("queues a refund instead of extending a closed service", async () => {
    const parent = await order({ status: "cancelled" });
    const renewal = await order({ kind: "renewal", parent_order_id: parent });
    expect((await one<{ r: string }>("SELECT public.apply_renewal($1, 'pay_RENEW00004') r", [renewal])).r).toBe("review");
    expect(await hasRefund(renewal)).toBe(true);
  });
});

describe("late payments with coupons", () => {
  it("revives an expired checkout only while the coupon still has uses left", async () => {
    const c = (await one<{ id: string }>("INSERT INTO public.coupons (code, kind, value, max_uses, per_user_limit) VALUES ('LATE10', 'percent', 10, 1, 1) RETURNING id")).id;
    const first = await order({ status: "failed", coupon_id: c, user_id: B });
    const second = await order({ status: "pending", coupon_id: c });
    const renews = new Date(Date.now() + 30 * 864e5).toISOString();
    expect((await one<{ r: string }>("SELECT public.revive_paid_order($1, 'pay_LATE000001', $2) r", [first, renews])).r).toBe("review");
    expect((await get(first)).status).toBe("failed");
    expect(await hasRefund(first)).toBe(true);
    await db.query("UPDATE public.orders SET status = 'failed' WHERE id = $1", [second]);
    const third = await order({ status: "failed", coupon_id: c, user_id: A, amount: 90 });
    expect((await one<{ r: string }>("SELECT public.revive_paid_order($1, 'pay_LATE000002', $2) r", [third, renews])).r).toBe("revived");
    expect((await get(third)).status).toBe("provisioning");
  });
});

describe("credit top-ups", () => {
  it("counts every unpaid top-up against the balance limit", async () => {
    await db.query("SELECT public.create_topup_order($1, 600, 1000, 5)", [B]);
    expect(await fails("SELECT public.create_topup_order($1, 500, 1000, 5)", [B])).toMatch(/topup_over_limit/);
    await db.query("UPDATE public.orders SET created_at = now() - interval '3 hours' WHERE user_id = $1 AND kind = 'credits'", [B]);
    expect(await fails("SELECT public.create_topup_order($1, 500, 1000, 5)", [B])).toMatch(/topup_over_limit/);
  });

  it("limits how many top-ups can be open at once", async () => {
    const u = "33333333-3333-3333-3333-333333333333";
    await db.query("INSERT INTO auth.users (id, email) VALUES ($1, 'c@example.com')", [u]);
    await db.query("SELECT public.create_topup_order($1, 10, 100000, 2)", [u]);
    await db.query("SELECT public.create_topup_order($1, 10, 100000, 2)", [u]);
    expect(await fails("SELECT public.create_topup_order($1, 10, 100000, 2)", [u])).toMatch(/topup_too_many_open/);
  });

  it("never lets a late top-up push a wallet past the hard ceiling", async () => {
    await db.query("INSERT INTO public.credit_wallets (user_id, balance) VALUES ($1, 999950) ON CONFLICT (user_id) DO UPDATE SET balance = 999950", [A]);
    const id = await order({ kind: "credits", product: "credits", plan_id: "credits", billing: "once", amount: 100, status: "failed" });
    expect((await one<{ r: number }>("SELECT public.credit_topup($1, 'pay_CEIL000001') r", [id])).r).toBe(-1);
    expect((await one<{ balance: number }>("SELECT balance FROM public.credit_wallets WHERE user_id = $1", [A])).balance).toBe(999950);
    expect(await hasRefund(id)).toBe(true);
  });
});

describe("migration 0008", () => {
  it("removes the old in-database backup and update tables", async () => {
    for (const t of ["system_backups", "system_update_runs", "settings_backups", "stack_update_runs"]) {
      expect((await one<{ r: string | null }>("SELECT to_regclass($1)::text r", [`public.${t}`])).r).toBeNull();
    }
  });

  it("removes the backup functions but keeps the maintenance switch", async () => {
    const fns = (await db.query<{ proname: string }>("SELECT proname FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace WHERE n.nspname = 'public'")).rows.map((r) => r.proname);
    for (const f of ["create_system_backup", "restore_system_backup", "backup_tables", "create_settings_backup", "restore_settings_backup"]) expect(fns).not.toContain(f);
    expect(fns).toContain("set_maintenance");
  });

  it("keeps business data and settings in place", async () => {
    expect(await one("SELECT 1 AS x FROM public.site_settings WHERE id = 1")).toBeTruthy();
    expect((await one<{ n: number }>("SELECT count(*)::int n FROM public.orders")).n).toBeGreaterThan(0);
  });
});
