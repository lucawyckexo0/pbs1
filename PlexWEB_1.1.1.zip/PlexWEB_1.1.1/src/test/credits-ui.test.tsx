import { describe, expect, it, vi } from "vitest";
import { fireEvent, render, screen } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import type { ReactNode } from "react";

vi.mock("@tanstack/react-start", async (orig) => ({ ...(await orig<object>()), useServerFn: (fn: unknown) => fn }));
vi.mock("@/integrations/supabase/client", () => ({ supabase: { auth: { getUser: async () => ({ data: { user: { email: "a@example.com" } } }) } } }));
vi.mock("@/lib/credits.functions", () => ({ getMyCredits: vi.fn(), createCreditTopup: vi.fn() }));
vi.mock("@/lib/orders.functions", () => ({ verifyPayment: vi.fn() }));
vi.mock("@/lib/settings.functions", async () => {
  const { queryOptions } = await import("@tanstack/react-query");
  const { defaultSiteSettings } = await import("@/config/settings");
  return { settingsQuery: queryOptions({ queryKey: ["site-settings"], queryFn: async () => defaultSiteSettings }) };
});

const { defaultSiteSettings } = await import("@/config/settings");
const { CreditsPanel } = await import("@/components/billing/CreditsPanel");
const { PayChoice } = await import("@/components/billing/PayChoice");

function wrap(ui: ReactNode, balance = 300) {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  qc.setQueryData(["site-settings"], defaultSiteSettings);
  qc.setQueryData(["credits"], { balance, transactions: [{ id: "t1", amount: 500, balance_after: 500, kind: "topup", order_id: null, note: "Razorpay top-up", created_at: "2026-01-02T10:00:00Z" }, { id: "t2", amount: -200, balance_after: 300, kind: "spend", order_id: null, note: "new: Stone", created_at: "2026-01-03T10:00:00Z" }] });
  return render(<QueryClientProvider client={qc}>{ui}</QueryClientProvider>);
}

describe("Credits on the Billing page", () => {
  it("shows the balance and the credit activity", () => {
    wrap(<CreditsPanel />);
    expect(screen.getAllByText("₹300").length).toBeGreaterThan(0);
    expect(screen.getByText("Top-up")).toBeInTheDocument();
    expect(screen.getByText("Payment")).toBeInTheDocument();
  });

  it("opens the top-up window with quick amounts and rejects an amount under the minimum", () => {
    wrap(<CreditsPanel />);
    fireEvent.click(screen.getByRole("button", { name: /add credits/i }));
    expect(screen.getByRole("radio", { name: "₹500" })).toBeInTheDocument();
    fireEvent.change(screen.getByPlaceholderText(/100 to 25000/), { target: { value: "50" } });
    expect(screen.getByText(/minimum top-up is ₹100/)).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /^add credits$/i })).toBeDisabled();
    fireEvent.change(screen.getByPlaceholderText(/100 to 25000/), { target: { value: "750" } });
    expect(screen.getByRole("button", { name: /pay ₹750/i })).toBeEnabled();
  });
});

describe("Paying with credits", () => {
  it("offers credits only when the balance covers the whole amount", () => {
    const onPay = vi.fn();
    const { unmount } = wrap(<PayChoice amount={400} balance={300} product="minecraft" onPay={onPay} />);
    expect(screen.getByRole("button", { name: /not enough credits/i })).toBeDisabled();
    expect(screen.getByRole("button", { name: /pay ₹400 with razorpay/i })).toBeEnabled();
    unmount();
    wrap(<PayChoice amount={250} balance={300} product="minecraft" onPay={onPay} />);
    fireEvent.click(screen.getByRole("button", { name: /pay ₹250 with credits/i }));
    expect(onPay).toHaveBeenCalledWith(true);
  });
});
