// In-memory Postgres (PGlite) with the small slice of the Supabase auth/storage schema the migrations
// reference, migrated with the real migration runner from scripts/lib/migrator.mjs.
import { join } from "node:path";
import { PGlite } from "@electric-sql/pglite";
import { loadMigrations, migrate, type Adapter } from "../../../scripts/lib/migrator.mjs";

export const MIGRATIONS_DIR = join(process.cwd(), "db/migrations");

export const SUPABASE_STUBS = `
  CREATE ROLE anon; CREATE ROLE authenticated; CREATE ROLE service_role; CREATE ROLE supabase_auth_admin;
  CREATE SCHEMA auth; CREATE SCHEMA extensions; CREATE SCHEMA storage; CREATE SCHEMA cron;
  CREATE TABLE auth.users (id uuid PRIMARY KEY, email text, raw_user_meta_data jsonb DEFAULT '{}'::jsonb, raw_app_meta_data jsonb DEFAULT '{}'::jsonb, email_confirmed_at timestamptz, last_sign_in_at timestamptz, created_at timestamptz DEFAULT now());
  CREATE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql STABLE AS $$ select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid $$;
  CREATE FUNCTION auth.jwt() RETURNS jsonb LANGUAGE sql STABLE AS $$ select '{}'::jsonb $$;
  CREATE FUNCTION auth.role() RETURNS text LANGUAGE sql STABLE AS $$ select 'authenticated' $$;
  CREATE TABLE storage.buckets (id text primary key, name text, public boolean, file_size_limit bigint, allowed_mime_types text[]);
  CREATE TABLE storage.objects (id uuid default gen_random_uuid() primary key, bucket_id text, name text, owner uuid);
  CREATE FUNCTION storage.foldername(text) RETURNS text[] LANGUAGE sql AS $$ select string_to_array($1,'/') $$;`;

/** Wraps PGlite in the adapter shape the migration runner expects. */
export function pgliteAdapter(db: PGlite): Adapter {
  return {
    transaction: (fn) => db.transaction(async (tx) => fn({
      query: async (sql, params = []) => (await tx.query<Record<string, unknown>>(sql, params)).rows,
      exec: (sql) => tx.exec(sql),
    })),
  };
}

/** A fresh database with the Supabase stubs only (no app migrations). */
export async function emptyDatabase() {
  const db = new PGlite();
  await db.exec(SUPABASE_STUBS);
  return db;
}

/** A fresh database with every app migration applied through the ledger. */
export async function migratedDatabase() {
  const db = await emptyDatabase();
  await migrate(pgliteAdapter(db), loadMigrations(MIGRATIONS_DIR), { appVersion: "test" });
  return db;
}
