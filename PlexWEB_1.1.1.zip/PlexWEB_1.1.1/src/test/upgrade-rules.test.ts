import { describe, expect, it } from "vitest";
import { canUpgradeProduct, isUpgradePath, upgradeQuote } from "@/config/upgrade-rules";
import { gamePlans } from "@/config/plans";

const [mark1, mark2, mark3] = gamePlans("minecraft");
const now = Date.parse("2026-11-10T00:00:00Z");
const inDays = (d: number) => new Date(now + d * 864e5).toISOString();

describe("plan upgrades", () => {
  it("only game servers can upgrade online", () => {
    expect(canUpgradeProduct("minecraft")).toBe(true);
    expect(canUpgradeProduct("cs2")).toBe(true);
    expect(canUpgradeProduct("vps")).toBe(false);
    expect(canUpgradeProduct("bot")).toBe(false);
  });

  it("rejects the same or a smaller plan", () => {
    expect(isUpgradePath(mark2!, mark2!)).toBe(false);
    expect(isUpgradePath(mark2!, mark1!)).toBe(false);
    expect(upgradeQuote(mark2!, mark1!, "monthly", inDays(20), now).ok).toBe(false);
  });

  it("charges the price difference for the days left, rounded up", () => {
    // Mark 1 ₹149 -> Mark 2 ₹279 monthly: ₹130 difference, 15 of 30 days left = ₹65
    const q = upgradeQuote(mark1!, mark2!, "monthly", inDays(15), now);
    expect(q).toMatchObject({ ok: true, amount: 65, remainingDays: 15, difference: 130 });
  });

  it("uses period prices with the billing discount", () => {
    // Quarterly: 149*3*0.95=425, 279*3*0.95=795 -> 370 diff; 45 of 90 days left = 185
    const q = upgradeQuote(mark1!, mark2!, "quarterly", inDays(45), now);
    expect(q).toMatchObject({ ok: true, amount: 185 });
  });

  it("covers time already renewed in advance", () => {
    // 60 days left on a monthly plan = two periods of difference
    const q = upgradeQuote(mark1!, mark3!, "monthly", inDays(60), now);
    expect(q.ok && q.amount).toBe((399 - 149) * 2);
  });

  it("asks to renew first when less than a day is left", () => {
    expect(upgradeQuote(mark1!, mark2!, "monthly", new Date(now + 3600_000).toISOString(), now).ok).toBe(false);
  });

  it("never charges less than one rupee", () => {
    const q = upgradeQuote(mark1!, mark2!, "yearly", inDays(1.5), now);
    expect(q.ok && q.amount).toBeGreaterThanOrEqual(1);
  });
});
