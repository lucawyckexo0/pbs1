import { describe, expect, it } from "vitest";
import { REFUND_WINDOW_MS, isOrderRefundEligible, isRefundEligible } from "@/config/refund-rules";

describe("refund eligibility", () => {
  const now = Date.parse("2026-11-05T12:00:00.000Z");

  it("allows refundable game hosting through the 24-hour deadline", () => {
    expect(isRefundEligible("minecraft", new Date(now - REFUND_WINDOW_MS).toISOString(), now)).toBe(true);
  });

  it("rejects refundable game hosting after 24 hours", () => {
    expect(isRefundEligible("cs2", new Date(now - REFUND_WINDOW_MS - 1).toISOString(), now)).toBe(false);
  });

  it.each(["vps", "bot"])("rejects non-refundable %s hosting", (product) => {
    expect(isRefundEligible(product, new Date(now - 60_000).toISOString(), now)).toBe(false);
  });

  it("rejects renewals even when their product is refundable", () => {
    expect(isOrderRefundEligible("renewal", "minecraft", new Date(now - 60_000).toISOString(), now)).toBe(false);
  });
});