import { describe, expect, it, vi } from "vitest";
import { handleRazorpayWebhook, type WebhookDeps } from "@/lib/razorpay-webhook";
import { hmacHexPure } from "@/lib/crypto-utils";

const SECRET = "whsec_test";
const payload = (amount = 49900) => JSON.stringify({ event: "payment.captured", payload: { payment: { entity: { id: "pay_ABCDEF123", order_id: "order_XYZ123456", amount, currency: "INR", status: "captured" } } } });

async function req(body: string, opts: { sig?: string; eventId?: string } = {}) {
  return new Request("https://x.test/api/public/razorpay-webhook", {
    method: "POST", body,
    headers: { "x-razorpay-signature": opts.sig ?? (await hmacHexPure(SECRET, body)), ...(opts.eventId ? { "x-razorpay-event-id": opts.eventId } : {}) },
  });
}

function deps(over: Partial<WebhookDeps> = {}) {
  const seen = new Set<string>();
  const markPaid = vi.fn(async () => {});
  const d: WebhookDeps = {
    secret: SECRET,
    recordEvent: async (id) => { if (seen.has(id)) return "duplicate"; seen.add(id); return "new"; },
    forgetEvent: async (id) => { seen.delete(id); },
    findOrder: async () => ({ id: "o1", amount: 499, status: "pending", razorpay_payment_id: null }),
    markPaid,
    ...over,
  };
  return { d, markPaid, seen };
}

describe("Razorpay webhook", () => {
  it("rejects a bad signature", async () => {
    const { d, markPaid } = deps();
    const r = await handleRazorpayWebhook(await req(payload(), { sig: "0".repeat(64) }), d);
    expect(r.status).toBe(401);
    expect(markPaid).not.toHaveBeenCalled();
  });
  it("ignores a payment whose amount does not match the order", async () => {
    const { d, markPaid } = deps();
    const r = await handleRazorpayWebhook(await req(payload(100)), d);
    expect(r.status).toBe(200);
    expect(markPaid).not.toHaveBeenCalled();
  });
  it("processes a replayed event only once", async () => {
    const { d, markPaid } = deps();
    const body = payload();
    await handleRazorpayWebhook(await req(body, { eventId: "evt_1" }), d);
    await handleRazorpayWebhook(await req(body, { eventId: "evt_1" }), d);
    expect(markPaid).toHaveBeenCalledTimes(1);
  });
  it("handles two simultaneous deliveries of the same event once", async () => {
    const { d, markPaid } = deps();
    const body = payload();
    await Promise.all([handleRazorpayWebhook(await req(body, { eventId: "evt_2" }), d), handleRazorpayWebhook(await req(body, { eventId: "evt_2" }), d)]);
    expect(markPaid).toHaveBeenCalledTimes(1);
  });
  it("lets Razorpay retry when processing fails", async () => {
    const { d, seen } = deps({ markPaid: async () => { throw new Error("db down"); } });
    const r = await handleRazorpayWebhook(await req(payload(), { eventId: "evt_3" }), d);
    expect(r.status).toBe(500);
    expect(seen.has("evt_3")).toBe(false);
  });
  it("skips orders that are already paid", async () => {
    const { d, markPaid } = deps({ findOrder: async () => ({ id: "o1", amount: 499, status: "active", razorpay_payment_id: "pay_ABCDEF123" }) });
    await handleRazorpayWebhook(await req(payload(), { eventId: "evt_4" }), d);
    expect(markPaid).not.toHaveBeenCalled();
  });
  it("is closed when no webhook secret is configured", async () => {
    const { d } = deps({ secret: undefined });
    expect((await handleRazorpayWebhook(await req(payload()), d)).status).toBe(503);
  });
});
