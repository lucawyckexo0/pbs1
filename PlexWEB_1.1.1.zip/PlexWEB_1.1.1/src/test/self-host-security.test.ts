import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/lib/client-ip.server", () => ({ clientIp: () => "203.0.113.9" }));

import { cloudflareIp } from "@/lib/ip";
import { apiOrigin, buildCsp } from "@/lib/csp";
import { smtpFromEnv } from "@/lib/smtp-env";
import { turnstileSiteKey, verifyTurnstileToken } from "@/lib/turnstile.server";
import { authenticateInternalJob, INTERNAL_MARKER_HEADER } from "@/lib/internal-jobs.server";

const headers = (h: Record<string, string>) => new Headers(h);

describe("visitor IP comes only from Cloudflare", () => {
  it("uses CF-Connecting-IP", () => expect(cloudflareIp(headers({ "cf-connecting-ip": "198.51.100.4" }))).toBe("198.51.100.4"));
  it("ignores X-Forwarded-For and X-Real-IP", () => {
    expect(cloudflareIp(headers({ "x-forwarded-for": "1.2.3.4", "x-real-ip": "5.6.7.8" }))).toBeNull();
    expect(cloudflareIp(headers({ "cf-connecting-ip": "198.51.100.4", "x-forwarded-for": "1.2.3.4" }))).toBe("198.51.100.4");
  });
  it("rejects junk in the Cloudflare header", () => expect(cloudflareIp(headers({ "cf-connecting-ip": "1.2.3.4, 5.6.7.8" }))).toBeNull());
});

describe("human check fails closed", () => {
  const env = { ...process.env };
  const fetchMock = vi.fn();
  beforeEach(() => { vi.stubGlobal("fetch", fetchMock); fetchMock.mockReset(); });
  afterEach(() => { process.env = { ...env }; vi.unstubAllGlobals(); });

  it("refuses sign-in when the keys are missing, without calling Cloudflare", async () => {
    delete process.env["TURNSTILE_SITE_KEY"];
    delete process.env["TURNSTILE_SECRET_KEY"];
    expect(turnstileSiteKey()).toBeNull();
    expect(await verifyTurnstileToken("token", "login")).toBe(false);
    expect(fetchMock).not.toHaveBeenCalled();
  });
  it("refuses when only one key is set", async () => {
    process.env["TURNSTILE_SITE_KEY"] = "0x4AAAAAAAAAAAAAAAAAAAAA";
    delete process.env["TURNSTILE_SECRET_KEY"];
    expect(turnstileSiteKey()).toBeNull();
    expect(await verifyTurnstileToken("token", "login")).toBe(false);
  });
  it("never accepts Cloudflare's test keys", async () => {
    process.env["TURNSTILE_SITE_KEY"] = "1x00000000000000000000AA";
    process.env["TURNSTILE_SECRET_KEY"] = "1x0000000000000000000000000000000AA";
    expect(turnstileSiteKey()).toBeNull();
    expect(await verifyTurnstileToken("XXXX.DUMMY.TOKEN.XXXX", "login")).toBe(false);
    expect(fetchMock).not.toHaveBeenCalled();
  });
  it("passes only a successful check for the same action", async () => {
    process.env["TURNSTILE_SITE_KEY"] = "0x4AAAAAAAAAAAAAAAAAAAAA";
    process.env["TURNSTILE_SECRET_KEY"] = "0x4BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB";
    fetchMock.mockResolvedValue(new Response(JSON.stringify({ success: true, action: "ticket" })));
    expect(await verifyTurnstileToken("t", "login")).toBe(false);
    fetchMock.mockResolvedValue(new Response(JSON.stringify({ success: true, action: "login" })));
    expect(await verifyTurnstileToken("t", "login")).toBe(true);
  });
});

describe("scheduled jobs are reachable only from this server", () => {
  const env = { ...process.env };
  const MARKER = "m".repeat(64);
  const SECRET = "s".repeat(40);
  beforeEach(() => {
    (globalThis as Record<symbol, unknown>)[Symbol.for("plexscale.internalMarker")] = MARKER;
    process.env["CRON_SECRET"] = SECRET;
    delete process.env["CRON_SECRET_PREVIOUS"];
  });
  afterEach(() => {
    process.env = { ...env };
    delete (globalThis as Record<symbol, unknown>)[Symbol.for("plexscale.internalMarker")];
  });
  const req = (h: Record<string, string>) => new Request("http://localhost/api/internal/jobs/expire-services", { method: "POST", headers: h });
  const status = async (h: Record<string, string>) => (await authenticateInternalJob(req(h)))?.status ?? 200;

  it("runs with the socket marker and the secret", async () => {
    expect(await status({ [INTERNAL_MARKER_HEADER]: MARKER, authorization: `Bearer ${SECRET}` })).toBe(200);
  });
  it("refuses a valid secret without the socket marker (came through the tunnel)", async () => {
    expect(await status({ authorization: `Bearer ${SECRET}` })).toBe(404);
    expect(await status({ [INTERNAL_MARKER_HEADER]: "x".repeat(64), authorization: `Bearer ${SECRET}` })).toBe(404);
  });
  it("refuses any request carrying Cloudflare or forwarding headers", async () => {
    for (const h of ["cf-connecting-ip", "cf-ray", "x-forwarded-for", "cdn-loop"]) {
      expect(await status({ [INTERNAL_MARKER_HEADER]: MARKER, authorization: `Bearer ${SECRET}`, [h]: "1.2.3.4" })).toBe(404);
    }
  });
  it("refuses a wrong secret and is unavailable when no strong secret is set", async () => {
    expect(await status({ [INTERNAL_MARKER_HEADER]: MARKER, authorization: "Bearer nope" })).toBe(401);
    process.env["CRON_SECRET"] = "short";
    expect(await status({ [INTERNAL_MARKER_HEADER]: MARKER, authorization: "Bearer short" })).toBe(503);
  });
  it("accepts the previous secret while rotating", async () => {
    process.env["CRON_SECRET_PREVIOUS"] = "p".repeat(40);
    expect(await status({ [INTERNAL_MARKER_HEADER]: MARKER, authorization: `Bearer ${"p".repeat(40)}` })).toBe(200);
  });
});

describe("allowed connections name the API host", () => {
  it("accepts only an https host", () => {
    expect(apiOrigin("https://api.plexscale.in/")).toBe("https://api.plexscale.in");
    expect(apiOrigin("http://api.plexscale.in")).toBeNull();
    expect(apiOrigin("https://user:pw@api.plexscale.in")).toBeNull();
    expect(apiOrigin("https://*.supabase.co")).toBeNull();
    expect(apiOrigin(undefined)).toBeNull();
  });
  it("lists the API host and no wildcard database host", () => {
    const csp = buildCsp("n0nce", "https://api.plexscale.in");
    const connect = csp.split("; ").find((d) => d.startsWith("connect-src")) ?? "";
    expect(connect).toBe("connect-src 'self' https://api.plexscale.in https://*.razorpay.com https://challenges.cloudflare.com");
    expect(csp).not.toContain("supabase.co");
    expect(csp).toContain("'nonce-n0nce'");
  });
});

describe("SMTP fallback settings", () => {
  const base = { SMTP_HOST: "smtp.zoho.in", SMTP_PORT: "587", SMTP_USER: "u@x.in", SMTP_PASSWORD: "pw", SMTP_FROM_EMAIL: "no-reply@plexscale.in" };
  it("reads a complete config", () => expect(smtpFromEnv(base)).toMatchObject({ host: "smtp.zoho.in", port: 587, security: "starttls" }));
  it("uses TLS on 465", () => expect(smtpFromEnv({ ...base, SMTP_PORT: "465" })?.security).toBe("tls"));
  it("refuses port 25, missing password and header injection", () => {
    expect(smtpFromEnv({ ...base, SMTP_PORT: "25" })).toBeNull();
    expect(smtpFromEnv({ ...base, SMTP_PASSWORD: "" })).toBeNull();
    expect(smtpFromEnv({ ...base, SMTP_PASSWORD: "a\r\nRCPT TO:<x@y>" })).toBeNull();
  });
});
