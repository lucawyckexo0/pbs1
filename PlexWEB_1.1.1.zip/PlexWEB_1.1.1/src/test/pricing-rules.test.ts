import { describe, expect, it } from "vitest";
import { effectivePlans, findEffectivePlan, periodMonths, periodTotal, planLines } from "@/config/plans";
import { checkoutInput, deploymentError, type CheckoutInput } from "@/config/order-rules";
import { normalizeSiteSettings, defaultSiteSettings, locationsForProduct } from "@/config/settings";

const base: CheckoutInput = { product: "minecraft", plan: "mark-1", billing: "monthly", location: "mumbai", serverName: "My SMP", description: "", software: "paper", version: "latest", eula: true };

describe("Admin plan changes", () => {
  it("applies a new price and specs to a plan", () => {
    const p = findEffectivePlan("minecraft", "mark-1", { "mark-1": { monthly: 199, cpuPercent: 75, ramGb: 3, diskGb: 25 } });
    if (!p) throw new Error("Expected an available Minecraft plan");
    expect([p.monthly, p.cpuPercent, p.ramLabel, p.storage]).toEqual([199, 75, "3 GB", "25 GB"]);
  });
  it("hidden plans cannot be bought", () => {
    expect(findEffectivePlan("minecraft", "mark-1", { "mark-1": { hidden: true } })).toBeUndefined();
    expect(effectivePlans("minecraft", { "mark-1": { hidden: true } })).toHaveLength(7);
  });
  it("quarterly is 5% off and yearly 15% off", () => {
    expect(periodTotal(149, "quarterly")).toBe(425);
    expect(periodTotal(149, "yearly")).toBe(1520);
  });
  it("offers a semi-annual (6 month) period", () => {
    expect(periodMonths("semiannual")).toBe(6);
    expect(checkoutInput.safeParse({ ...base, billing: "semiannual" }).success).toBe(true);
  });
  it("admin card lines replace the generated plan lines", () => {
    const p = findEffectivePlan("minecraft", "mark-1", { "mark-1": { lines: ["CPU: 2 fast cores", "DDoS: Always-on filtering", "Free subdomain"] } });
    expect(planLines(p!, ["ignored"])).toEqual(["CPU: 2 fast cores", "DDoS: Always-on filtering", "Free subdomain"]);
  });
});

describe("Per-product locations", () => {
  const vpsOnlyFrankfurt = { ...defaultSiteSettings, ordering: { ...defaultSiteSettings.ordering, productLocations: { vps: ["frankfurt"] } } };
  it("only offers the chosen locations for that product", () => {
    expect(locationsForProduct(vpsOnlyFrankfurt, "vps").map((l) => l.id)).toEqual(["frankfurt"]);
    expect(deploymentError({ product: "vps", location: "mumbai", version: "latest" }, vpsOnlyFrankfurt)).toContain("not offered");
    expect(deploymentError({ product: "vps", location: "frankfurt", version: "latest" }, vpsOnlyFrankfurt)).toBeNull();
  });
  it("other products keep every location", () => {
    expect(locationsForProduct(vpsOnlyFrankfurt, "bot")).toHaveLength(defaultSiteSettings.locations.length);
  });
});

describe("Checkout form rules", () => {
  it("accepts a valid Minecraft order", () => {
    expect(checkoutInput.safeParse(base).success).toBe(true);
  });
  it("requires the Minecraft EULA", () => {
    expect(checkoutInput.safeParse({ ...base, eula: false }).success).toBe(false);
  });
  it("rejects server names shorter than 3 characters or with symbols", () => {
    expect(checkoutInput.safeParse({ ...base, serverName: "ab" }).success).toBe(false);
    expect(checkoutInput.safeParse({ ...base, serverName: "<script>" }).success).toBe(false);
  });
  it("rejects software that does not belong to the product", () => {
    expect(checkoutInput.safeParse({ ...base, software: "python" }).success).toBe(false);
  });
  it("rejects unknown locations", () => {
    expect(deploymentError({ ...base, location: "mars" }, defaultSiteSettings)).toContain("Unknown location");
  });
});

describe("Site settings", () => {
  it("falls back to defaults for broken sections", () => {
    const s = normalizeSiteSettings({ discordUrl: "javascript:alert(1)", supportEmail: "team@plexscale.com" });
    expect(s.discordUrl).toBe(defaultSiteSettings.discordUrl);
    expect(s.supportEmail).toBe("team@plexscale.com");
  });
});

describe("Admin-created plans", () => {
  it("custom plans appear for their product only", () => {
    const o = { "c-vps-1": { custom: true, product: "vps" as const, name: "VPS 4", monthly: 299, ramGb: 4, diskGb: 40, vcpu: 1 } };
    expect(findEffectivePlan("vps", "c-vps-1", o)?.name).toBe("VPS 4");
    expect(findEffectivePlan("minecraft", "c-vps-1", o)).toBeUndefined();
  });
  it("VPS vCPU sets the panel CPU limit", () => {
    expect(findEffectivePlan("vps", "vps-8", { "vps-8": { vcpu: 3 } })?.cpuPercent).toBe(300);
  });
});

describe("Plan deploy values", () => {
  it("RAM in MiB overrides the GB spec on the panel", async () => {
    const { deployLimits } = await import("@/config/plans");
    const p = findEffectivePlan("minecraft", "mark-1", { "mark-1": { deploy: { memoryMib: 2500 } } });
    if (!p) throw new Error("Expected an available Minecraft plan");
    expect(deployLimits(p)).toEqual({ memoryMib: 2500, diskMib: 20480, cpu: 50 });
  });
});
