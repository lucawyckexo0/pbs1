import { describe, expect, it } from "vitest";
import { locations } from "@/config/site";

describe("Hosting locations", () => {
  it("offers Dubai, UAE instead of Singapore", () => {
    expect(locations.find((location) => location.id === "dubai")).toMatchObject({ city: "Dubai", region: "UAE", country: "AE" });
    expect(locations.some((location) => location.id === "singapore" || location.country === "SG")).toBe(false);
    expect(locations).toHaveLength(5);
  });

  it("offers Virginia, United States in place of Chennai", () => {
    expect(locations.find((location) => location.id === "virginia")).toMatchObject({ city: "Virginia", region: "United States", country: "US" });
    expect(locations.some((location) => location.id === "chennai")).toBe(false);
  });
});
