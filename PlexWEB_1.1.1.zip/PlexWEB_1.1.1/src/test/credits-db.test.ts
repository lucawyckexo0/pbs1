// @vitest-environment node
import { PGlite } from "@electric-sql/pglite";
import { beforeAll, describe, expect, it } from "vitest";
import { migratedDatabase } from "./helpers/db-harness";

/** Applies every migration to an in-memory Postgres and checks the credit money rules directly. */
const A = "11111111-1111-1111-1111-111111111111";
const B = "22222222-2222-2222-2222-222222222222";
let db: PGlite;

const one = async <T = Record<string, unknown>>(sql: string, params: unknown[] = []) => (await db.query<T>(sql, params)).rows[0] as T;
const fails = async (sql: string, params: unknown[] = []) => { try { await db.query(sql, params); return null; } catch (e) { return (e as Error).message; } };
const order = async (kind: string, amount: number, user = A) =>
  (await one<{ id: string }>(`INSERT INTO public.orders (user_id, kind, product, plan_id, plan_name, billing, location, amount)
     VALUES ($1, $2, $3, $3, 'Test', $4, 'mumbai', $5) RETURNING id`, [user, kind, kind === "credits" ? "credits" : "minecraft", kind === "credits" ? "once" : "monthly", amount])).id;
const balance = async (user = A) => (await one<{ balance: number } | undefined>("SELECT balance FROM public.credit_wallets WHERE user_id = $1", [user]))?.balance ?? 0;

beforeAll(async () => {
  db = await migratedDatabase();
  await db.query("INSERT INTO auth.users (id, email) VALUES ($1, 'a@example.com'), ($2, 'b@example.com')", [A, B]);
}, 60_000);

describe("credits in the database", () => {
  it("adds a paid top-up exactly once, even when the payment is replayed", async () => {
    const id = await order("credits", 500);
    expect((await one<{ r: number }>("SELECT public.credit_topup($1, 'pay_TEST000001') r", [id])).r).toBe(500);
    expect((await one<{ r: number | null }>("SELECT public.credit_topup($1, 'pay_TEST000002') r", [id])).r).toBeNull();
    expect(await balance()).toBe(500);
  });

  it("pays an order from the balance once and refuses a second charge", async () => {
    const id = await order("new", 300);
    await db.query("SELECT public.spend_credits($1)", [id]);
    expect(await balance()).toBe(200);
    expect(await fails("SELECT public.spend_credits($1)", [id])).toMatch(/credits_order_invalid/);
    expect(await balance()).toBe(200);
  });

  it("refuses to pay when the balance is too low and leaves it unchanged", async () => {
    const id = await order("renewal", 201);
    expect(await fails("SELECT public.spend_credits($1)", [id])).toMatch(/credits_insufficient/);
    expect(await balance()).toBe(200);
  });

  it("refunds a credit-paid order to the balance only once", async () => {
    const id = await order("new", 100);
    await db.query("SELECT public.spend_credits($1)", [id]);
    await db.query("UPDATE public.orders SET razorpay_payment_id = 'credits_' || id, paid_at = now(), status = 'active' WHERE id = $1", [id]);
    await db.query("SELECT public.refund_order_to_credits($1, NULL, 'test')", [id]);
    expect(await balance()).toBe(200);
    expect(await fails("SELECT public.refund_order_to_credits($1, NULL, 'test')", [id])).toMatch(/credits_refund_done/);
  });

  it("never lets an administrator deduction take a balance below zero", async () => {
    expect(await fails("SELECT public.admin_adjust_credits($1, -201, 'too much', NULL)", [A])).toMatch(/credits_insufficient/);
    expect((await one<{ r: number }>("SELECT public.admin_adjust_credits($1, -50, 'correction', NULL) r", [A])).r).toBe(150);
  });

  it("requires a reason for administrator adjustments", async () => {
    expect(await fails("SELECT public.admin_adjust_credits($1, 10, '', NULL)", [A])).toMatch(/credits_note_required/);
  });

  it("customers can read only their own balance and can never write it", async () => {
    await db.query("SELECT public.admin_adjust_credits($1, 40, 'goodwill', NULL)", [B]);
    await db.exec(`SET ROLE authenticated; SELECT set_config('request.jwt.claim.sub', '${B}', false);`);
    try {
      expect((await one<{ n: number }>("SELECT count(*)::int n FROM public.credit_wallets")).n).toBe(1);
      expect(await fails("UPDATE public.credit_wallets SET balance = 999999")).toMatch(/permission denied/);
      expect(await fails(`INSERT INTO public.credit_transactions (user_id, amount, balance_after, kind) VALUES ('${B}', 100, 100, 'topup')`)).toMatch(/permission denied/);
      for (const fn of ["SELECT public.admin_adjust_credits($1, 100, 'self grant', NULL)", "SELECT public.credit_topup($1, 'pay_TEST000003')", "SELECT public.spend_credits($1)"])
        expect(await fails(fn, [B])).toMatch(/permission denied/);
      expect(await fails("UPDATE public.orders SET paid_with = 'credits'")).toMatch(/permission denied/);
    } finally {
      await db.exec("RESET ROLE;");
    }
  });
});
