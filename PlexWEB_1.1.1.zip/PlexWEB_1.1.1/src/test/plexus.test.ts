import { describe, expect, it } from "vitest";
import { runDeletePass, type DeleteCandidate } from "@/lib/server-lifecycle";
import { plexusMachineName, strongPassword } from "@/lib/plexus.server";
import { deploymentError } from "@/config/order-rules";
import { defaultSiteSettings, normalizePanelSettings } from "@/config/settings";

describe("Plexus VPS rules", () => {
  it("deletes the Plexus machine of an unrenewed VPS in the cleanup pass", async () => {
    const log: string[] = [];
    const due: DeleteCandidate[] = [{ id: "v", user_id: "u", product: "vps", ptero_server_id: null, plexus_machine_id: "m1" }];
    await runDeletePass({
      listDue: async () => due, claim: async () => true, revert: async () => { log.push("revert"); },
      deleteServer: async () => { log.push("ptero"); }, deleteMachine: async (id) => { log.push(`machine:${id}`); },
      alert: async () => { log.push("alert"); }, finish: async () => { log.push("finish"); },
    });
    expect(log).toEqual(["machine:m1", "finish"]);
  });

  it("reverts the claim when Plexus refuses the delete, so the next run retries", async () => {
    const log: string[] = [];
    await runDeletePass({
      listDue: async () => [{ id: "v", user_id: "u", product: "vps", ptero_server_id: null, plexus_machine_id: "m1" }], claim: async () => true,
      revert: async () => { log.push("revert"); }, deleteServer: async () => {}, deleteMachine: async () => { throw new Error("409"); },
      alert: async () => { log.push("alert"); }, finish: async () => { log.push("finish"); },
    });
    expect(log).toEqual(["revert", "alert"]);
  });

  it("rejects a hidden VPS operating system", () => {
    const settings = { ...defaultSiteSettings, vpsOs: defaultSiteSettings.vpsOs.map((o) => (o.key === "debian-12" ? { ...o, hidden: true } : o)) };
    const base = { product: "vps" as const, location: settings.locations[0]!.id, version: "latest" };
    expect(deploymentError({ ...base, software: "debian-12" }, settings)).toContain("operating system");
    expect(deploymentError({ ...base, software: "debian-13" }, settings)).toBeNull();
  });

  it("generates 20 character passwords with upper, lower, digit and symbol", () => {
    const p = strongPassword(20);
    expect(p).toHaveLength(20);
    expect(/[A-Z]/.test(p) && /[a-z]/.test(p) && /[0-9]/.test(p) && /[^A-Za-z0-9]/.test(p)).toBe(true);
  });

  it("builds a Plexus-safe machine name tied to the order", () => {
    expect(plexusMachineName("My Web Box!", "1234abcd-0000")).toBe("my-web-box-1234abcd");
  });

  it("keeps Plexus mappings when panel settings are read back", () => {
    expect(normalizePanelSettings({ plexus: { clusters: { mumbai: 2 }, images: { "debian-13": 7 } } }).plexus).toEqual({ clusters: { mumbai: 2 }, images: { "debian-13": 7 } });
  });
});
