import { describe, expect, it } from "vitest";
import { gameOptionsIssue, pickGameOptions } from "@/config/game-options";
import { buildEggEnvironment, extraPortsFor, pickAllocations } from "@/config/egg-env";
import { showsProducts } from "@/config/nav";

const random = { password: () => "pw", seed: () => 42 };
const GSLT = "A".repeat(32);

describe("CS2 orders", () => {
  it("require a 32 character Steam token", () => {
    expect(gameOptionsIssue("cs2", {})?.path).toBe("gslt");
    expect(gameOptionsIssue("cs2", { gslt: "short" })?.path).toBe("gslt");
    expect(gameOptionsIssue("cs2", { gslt: GSLT })).toBeNull();
  });
  it("fill the egg with the chosen mode, map and token", () => {
    const defaults = { SERVER_NAME: "", STEAM_GSLT: "", GAME_TYPE: "", GAME_MODE: "", MAX_PLAYERS: "", SRCDS_MAP: "", RCON_PASSWORD: "", SERVER_PASSWORD: "", TV_PORT: "27020" };
    const env = buildEggEnvironment(defaults, { product: "cs2", serverName: "My Server", description: "", ramMb: 4096, options: pickGameOptions("cs2", { gslt: GSLT, mode: "wingman", map: "de_nuke" }), ports: [25001], adminEnv: { STEAM_GSLT: "admin" }, random });
    expect(env).toMatchObject({ SERVER_NAME: "My Server", STEAM_GSLT: GSLT, GAME_TYPE: "0", GAME_MODE: "2", MAX_PLAYERS: "6", SRCDS_MAP: "de_nuke", TV_PORT: "25001" });
  });
});

describe("Rust orders", () => {
  it("get two extra ports for RCON and the Rust+ app", () => {
    expect(extraPortsFor("rust", { RCON_PORT: "", APP_PORT: "" })).toBe(2);
  });
  it("reject a seed out of range and use the public branch", () => {
    expect(gameOptionsIssue("rust", { seed: 0 })?.path).toBe("seed");
    const env = buildEggEnvironment({ WORLD_SIZE: "", WORLD_SEED: "", SRCDS_BETAID: "staging", RCON_PORT: "", APP_PORT: "" }, { product: "rust", serverName: "x y z", description: "", ramMb: 8192, options: pickGameOptions("rust", { worldSize: 4000 }), ports: [25001, 25002], random });
    expect(env).toMatchObject({ WORLD_SIZE: "4000", WORLD_SEED: "42", SRCDS_BETAID: "", RCON_PORT: "25001", APP_PORT: "25002" });
  });
  it("prefer consecutive ports on one IP", () => {
    const free = [{ id: 1, ip: "1.1.1.1", port: 25000 }, { id: 2, ip: "1.1.1.1", port: 25005 }, { id: 3, ip: "1.1.1.1", port: 25006 }, { id: 4, ip: "1.1.1.1", port: 25007 }];
    expect(pickAllocations(free, 2)?.primary.port).toBe(25005);
  });
});

describe("Navbar product links", () => {
  it("show on public pages and hide on account pages", () => {
    for (const p of ["/", "/about", "/rust", "/counter-strike-2", "/vps", "/legal/terms"]) expect(showsProducts(p)).toBe(true);
    for (const p of ["/billing", "/administrator", "/deploy", "/support", "/account"]) expect(showsProducts(p)).toBe(false);
  });
});

// ---------- Smart ports, panel errors and server cleanup ----------
import { afterEach, beforeEach, vi } from "vitest";
import { extraPortVariables, parsePortRanges, portAllowed } from "@/config/egg-env";
import { createServer, deleteServer, PanelError, scrubPanelText, customerCode, RESERVE_ATTEMPTS } from "@/lib/pterodactyl.server";
import { friendlyLine } from "@/lib/panel-errors.server";
import { runDeletePass, type DeleteCandidate } from "@/lib/server-lifecycle";

describe("Rust ports by variable name", () => {
  const rustDefaults = { HOSTNAME: "", RCON_PORT: "28016", APP_PORT: "28082", QUERY_PORT: "28017" };
  it("reserve RCON, Rust+ and query ports in that order", () => {
    expect(extraPortVariables("rust", rustDefaults)).toEqual(["RCON_PORT", "APP_PORT", "QUERY_PORT"]);
    const env = buildEggEnvironment(rustDefaults, { product: "rust", serverName: "x", description: "", ramMb: 4096, options: {}, ports: [30001, 30002, 30003], random });
    expect(env).toMatchObject({ RCON_PORT: "30001", APP_PORT: "30002", QUERY_PORT: "30003" });
  });
  it("skip RCON_PORT when the egg has none, without shifting the others", () => {
    const noRcon = { HOSTNAME: "", APP_PORT: "28082", QUERY_PORT: "28017" };
    expect(extraPortVariables("rust", noRcon)).toEqual(["APP_PORT", "QUERY_PORT"]);
    const env = buildEggEnvironment(noRcon, { product: "rust", serverName: "x", description: "", ramMb: 4096, options: {}, ports: [30001, 30002], random });
    expect(env).toMatchObject({ APP_PORT: "30001", QUERY_PORT: "30002" });
    expect(env).not.toHaveProperty("RCON_PORT");
  });
  it("give Rust a query port only when the egg defines QUERY_PORT", () => {
    expect(extraPortsFor("rust", { RCON_PORT: "", APP_PORT: "", QUERY_PORT: "" })).toBe(3);
    expect(extraPortsFor("rust", { RCON_PORT: "", APP_PORT: "" })).toBe(2);
  });
  it("keep reserved ports even when an admin fixed value names the same variable", () => {
    const env = buildEggEnvironment({ RCON_PORT: "", APP_PORT: "" }, { product: "rust", serverName: "x", description: "", ramMb: 4096, options: {}, ports: [30001, 30002], adminEnv: { RCON_PORT: "28016" }, random });
    expect(env["RCON_PORT"]).toBe("30001");
  });
});

describe("Other games' extra ports", () => {
  it("Hytale skips the query port when the plugin variable is 0", () => {
    expect(extraPortVariables("hytale", { QUERY_PORT: "5520", INSTALL_SOURCEQUERY_PLUGIN: "0" })).toEqual([]);
    expect(extraPortVariables("hytale", { QUERY_PORT: "5520", INSTALL_SOURCEQUERY_PLUGIN: "1" })).toEqual(["QUERY_PORT"]);
  });
  it("Minecraft and bots need no extra ports", () => {
    expect(extraPortsFor("minecraft", { SERVER_PORT: "25565", QUERY_PORT: "25565", RCON_PORT: "25575" })).toBe(0);
    expect(extraPortsFor("bot", { TV_PORT: "1", QUERY_PORT: "2" })).toBe(0);
  });
  it("CS2 reserves only TV_PORT", () => {
    expect(extraPortVariables("cs2", { TV_PORT: "27020", RCON_PORT: "1" })).toEqual(["TV_PORT"]);
  });
  it("port pools filter allocations", () => {
    const ranges = parsePortRanges(["25565-25570", "27015", "bad", "9-1"]);
    expect(ranges).toEqual([{ from: 25565, to: 25570 }, { from: 27015, to: 27015 }]);
    expect(portAllowed(25566, ranges)).toBe(true);
    expect(portAllowed(30000, ranges)).toBe(false);
    expect(portAllowed(30000, [])).toBe(true);
  });
});

/** A tiny fake Pterodactyl panel answering only what createServer asks for. */
function fakePanel(opts: { eggVars: Record<string, string>; free: { id: number; port: number }[]; existingAfter?: number; onCreate?: (body: Record<string, unknown>) => Response }) {
  const calls: { method: string; path: string; body?: Record<string, unknown> }[] = [];
  let externalLookups = 0;
  const json = (data: unknown, status = 200) => new Response(JSON.stringify(data), { status, headers: { "content-type": "application/json" } });
  const fetchMock = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = new URL(String(input));
    const method = init?.method ?? "GET";
    const body = init?.body ? (JSON.parse(String(init.body)) as Record<string, unknown>) : undefined;
    calls.push({ method, path: url.pathname, ...(body ? { body } : {}) });
    const p = url.pathname;
    if (p.startsWith("/api/application/servers/external/")) {
      externalLookups++;
      return opts.existingAfter !== undefined && externalLookups > opts.existingAfter ? json({ attributes: { id: 77, identifier: "exist01" } }) : json({ errors: [{ code: "NotFoundHttpException", status: "404", detail: "Not found" }] }, 404);
    }
    if (p === "/api/application/users") return json({ data: [{ attributes: { id: 1, email: "a@b.co" } }] });
    if (p === "/api/application/nests/1/eggs/2") return json({ attributes: { docker_image: "img", startup: "run", relationships: { variables: { data: Object.entries(opts.eggVars).map(([k, v]) => ({ attributes: { env_variable: k, default_value: v } })) } } } });
    if (p === "/api/application/nodes") return json({ data: [{ attributes: { id: 5, location_id: 3, maintenance_mode: false } }] });
    if (p === "/api/application/nodes/5") return json({ attributes: { memory: 65536, memory_overallocate: 0, disk: 1_000_000, disk_overallocate: 0, allocated_resources: { memory: 0, disk: 0 } } });
    if (p === "/api/application/nodes/5/allocations") return json({ data: opts.free.map((a) => ({ attributes: { id: a.id, ip: "10.0.0.1", port: a.port, assigned: false } })), meta: { pagination: { current_page: 1, total_pages: 1 } } });
    if (p === "/api/application/servers" && method === "POST") return opts.onCreate ? opts.onCreate(body!) : json({ attributes: { id: 9, identifier: "new0001" } }, 201);
    if (p.startsWith("/api/application/servers/") && method === "DELETE") return new Response(null, { status: p.endsWith("/404") ? 404 : p.endsWith("/500") ? 500 : 204 });
    return json({ errors: [{ code: "NotFound", detail: `unexpected ${method} ${p}` }] }, 404);
  });
  return { fetchMock, calls };
}

const panelSettings = (product: string, software = "default") => ({ eggs: { [`${product}:${software}`]: { nestId: 1, eggId: 2, versionVariable: "", dockerImage: "", env: {} } }, locations: { mumbai: 3 } });
const order = (product: string, software = "default") => ({ orderId: "11111111-1111-4111-8111-111111111111", userId: "u1", email: "a@b.co", name: "A", product, software, version: "latest", location: "mumbai", serverName: "Test", description: "", cpuPercent: 100, ramMb: 4096, diskMb: 20480 });

describe("Server creation on the panel", () => {
  beforeEach(() => { process.env["PTERODACTYL_URL"] = "https://panel.test"; process.env["PTERODACTYL_API_KEY"] = "ptla_testkey123"; });
  afterEach(() => { vi.unstubAllGlobals(); });

  it("reserves Rust ports and passes them by name", async () => {
    const panel = fakePanel({ eggVars: { RCON_PORT: "28016", APP_PORT: "28082" }, free: [{ id: 1, port: 30000 }, { id: 2, port: 30001 }, { id: 3, port: 30002 }] });
    vi.stubGlobal("fetch", panel.fetchMock);
    await expect(createServer(order("rust"), panelSettings("rust"))).resolves.toEqual({ id: 9, identifier: "new0001" });
    const post = panel.calls.find((c) => c.method === "POST")!.body!;
    expect(post["allocation"]).toEqual({ default: 1, additional: [2, 3] });
    expect(post["environment"]).toMatchObject({ RCON_PORT: "30001", APP_PORT: "30002" });
    expect(post).not.toHaveProperty("deploy");
  });

  it("throws a reserve_ports error instead of falling back to automatic placement", async () => {
    const panel = fakePanel({ eggVars: { TV_PORT: "27020" }, free: [] });
    vi.stubGlobal("fetch", panel.fetchMock);
    const err = await createServer(order("cs2"), panelSettings("cs2")).catch((e: unknown) => e);
    expect(err).toBeInstanceOf(PanelError);
    expect((err as PanelError).action).toBe("reserve_ports");
    expect(panel.calls.some((c) => c.method === "POST")).toBe(false);
    expect(panel.calls.filter((c) => c.path === "/api/application/nodes").length).toBe(RESERVE_ATTEMPTS);
    // Initial idempotency check plus one re-check before each retry.
    expect(panel.calls.filter((c) => c.path.startsWith("/api/application/servers/external/")).length).toBe(RESERVE_ATTEMPTS);
  });

  it("returns the existing server when the external id is already taken", async () => {
    const panel = fakePanel({
      eggVars: { SERVER_JARFILE: "server.jar" }, free: [], existingAfter: 1,
      onCreate: () => new Response(JSON.stringify({ errors: [{ code: "ValidationException", status: "422", detail: "The external id has already been taken." }] }), { status: 422 }),
    });
    vi.stubGlobal("fetch", panel.fetchMock);
    await expect(createServer(order("minecraft", "paper"), panelSettings("minecraft", "paper"))).resolves.toEqual({ id: 77, identifier: "exist01" });
  });

  it("lets the panel place Minecraft servers with no extra allocations", async () => {
    const panel = fakePanel({ eggVars: { SERVER_JARFILE: "server.jar" }, free: [] });
    vi.stubGlobal("fetch", panel.fetchMock);
    await createServer(order("minecraft", "paper"), { ...panelSettings("minecraft", "paper"), portRanges: { minecraft: ["25565-25665"] } });
    const post = panel.calls.find((c) => c.method === "POST")!.body!;
    expect(post["deploy"]).toEqual({ locations: [3], dedicated_ip: false, port_range: ["25565-25665"] });
    expect(post).not.toHaveProperty("allocation");
  });

  it("treats a server that is already gone as deleted", async () => {
    const panel = fakePanel({ eggVars: {}, free: [] });
    vi.stubGlobal("fetch", panel.fetchMock);
    await expect(deleteServer(404)).resolves.toBeUndefined();
    await expect(deleteServer(500)).rejects.toBeInstanceOf(PanelError);
  });
});

describe("Panel errors shown to customers", () => {
  it("customer line carries no Support ID", () => {
    expect(friendlyLine(503)).toBe("Error occurred. 503. Contact support.");
    expect(friendlyLine(500)).not.toMatch(/support id/i);
  });
  it("customer line uses the panel status, with 401/403 shown as 500", () => {
    expect(friendlyLine(504)).toBe("Error occurred. 504. Contact support.");
    expect(customerCode(422)).toBe(422);
    expect(customerCode(401)).toBe(500);
    expect(customerCode(403)).toBe(500);
    expect(customerCode(null)).toBe(500);
    expect(new PanelError({ httpStatus: 403, detail: "denied" }).message).toBe("Error occurred. 500.");
  });
  it("secrets are scrubbed from stored text", () => {
    const gslt = "ABCDEF0123456789ABCDEF0123456789";
    const raw = `{"RCON_PASSWORD":"hunter22x","SERVER_PASSWORD":"letmein1","STEAM_GSLT":"${gslt}"} Authorization: Bearer ptla_SECRETKEY RCON_PASS=abc12345 token ${gslt}`;
    const out = scrubPanelText(raw, ["myGeneratedPw"]);
    for (const secret of ["hunter22x", "letmein1", gslt, "ptla_SECRETKEY", "abc12345"]) expect(out).not.toContain(secret);
    expect(scrubPanelText("rcon is myGeneratedPw ok", ["myGeneratedPw"])).not.toContain("myGeneratedPw");
    const e = new PanelError({ httpStatus: 422, detail: "bad", raw });
    expect(e.raw).not.toContain("hunter22x");
    expect(e.message).not.toContain("hunter22x");
  });
});

describe("Day-7 delete pass", () => {
  const due: DeleteCandidate[] = [
    { id: "a", user_id: "u", product: "rust", ptero_server_id: 10 },
    { id: "b", user_id: "u", product: "cs2", ptero_server_id: 11 },
    { id: "c", user_id: "u", product: "minecraft", ptero_server_id: 12 },
  ];
  function deps(over: Partial<Parameters<typeof runDeletePass>[0]> = {}) {
    const log: string[] = [];
    return {
      log,
      d: {
        listDue: async () => due,
        // "b" was renewed or claimed elsewhere: no longer suspended.
        claim: async (c: DeleteCandidate) => { log.push(`claim:${c.id}`); return c.id !== "b"; },
        revert: async (c: DeleteCandidate) => { log.push(`revert:${c.id}`); },
        deleteServer: async (id: number) => { log.push(`delete:${id}`); if (id === 12) throw new PanelError({ httpStatus: 500, detail: "boom" }); },
        alert: async (c: DeleteCandidate) => { log.push(`alert:${c.id}`); },
        finish: async (c: DeleteCandidate) => { log.push(`finish:${c.id}`); },
        ...over,
      },
    };
  }
  it("only deletes orders it claimed, and reverts plus alerts when the panel delete fails", async () => {
    const { d, log } = deps();
    await expect(runDeletePass(d)).resolves.toEqual({ deleted: 1, failed: 1, skipped: 1 });
    expect(log).not.toContain("delete:11");
    expect(log).toEqual(["claim:a", "delete:10", "finish:a", "claim:b", "claim:c", "delete:12", "revert:c", "alert:c"]);
  });
});
