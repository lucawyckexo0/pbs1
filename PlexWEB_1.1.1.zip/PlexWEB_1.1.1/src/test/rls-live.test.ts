import { describe, expect, it } from "vitest";
import { createClient } from "@supabase/supabase-js";

// Live checks against the real database as an anonymous visitor (and as a second signed-in user
// when RLS_TEST_EMAIL / RLS_TEST_PASSWORD are set). Skipped when no backend is configured.
const url = import.meta.env["VITE_SUPABASE_URL"] as string | undefined;
const key = import.meta.env["VITE_SUPABASE_PUBLISHABLE_KEY"] as string | undefined;
const live = Boolean(url && key && process.env["RLS_LIVE"] === "1");

describe.skipIf(!live)("Row level security (live)", () => {
  const anon = () => createClient(url!, key!, { auth: { persistSession: false, autoRefreshToken: false } });
  const privateTables = ["orders", "refunds", "invoices", "profiles", "coupons", "panel_alerts", "panel_settings", "email_settings", "audit_log", "support_tickets", "ticket_messages", "webhook_events", "rate_limits", "user_roles"] as const;

  for (const t of privateTables) {
    it(`anonymous visitors cannot read ${t}`, async () => {
      const { data, error } = await anon().from(t).select("*").limit(1);
      expect(error !== null || (data ?? []).length === 0).toBe(true);
    });
  }
  it("anonymous visitors can read public site settings", async () => {
    const { error } = await anon().from("site_settings").select("id").eq("id", 1);
    expect(error).toBeNull();
  });
  it("anonymous visitors cannot call money functions", async () => {
    const { error } = await anon().rpc("extend_service", { _order_id: "00000000-0000-0000-0000-000000000000", _months: 1 });
    expect(error).not.toBeNull();
  });

  const email = process.env["RLS_TEST_EMAIL"];
  const password = process.env["RLS_TEST_PASSWORD"];
  it.skipIf(!email || !password)("a signed-in customer only sees their own orders and no alerts or coupons", async () => {
    const c = anon();
    const { data: s, error } = await c.auth.signInWithPassword({ email: email!, password: password! });
    expect(error).toBeNull();
    const { data: orders } = await c.from("orders").select("user_id");
    expect((orders ?? []).every((o) => o.user_id === s.user!.id)).toBe(true);
    const { data: alerts } = await c.from("panel_alerts").select("id");
    expect(alerts ?? []).toEqual([]);
    const { error: couponError } = await c.from("coupons").select("id");
    expect(couponError).not.toBeNull();
  });
});
