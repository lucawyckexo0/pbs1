import { describe, expect, it } from "vitest";
import { canPayWithCredits, creditsErrorMessage, creditsSettingsSchema, defaultCreditsSettings as d, topupProblem } from "@/config/credits";

describe("credit top-ups", () => {
  it("accepts an amount inside the limits", () => {
    expect(topupProblem(500, 0, d)).toBeNull();
  });
  it("rejects amounts below the minimum and above the maximum", () => {
    expect(topupProblem(d.minTopup - 1, 0, d)).toMatch(/minimum/);
    expect(topupProblem(d.maxTopup + 1, 0, d)).toMatch(/maximum/);
  });
  it("rejects fractions, zero and negatives", () => {
    expect(topupProblem(99.5, 0, d)).not.toBeNull();
    expect(topupProblem(0, 0, d)).not.toBeNull();
    expect(topupProblem(-100, 0, d)).not.toBeNull();
  });
  it("never lets a balance go over the balance limit", () => {
    expect(topupProblem(1000, d.maxBalance - 999, d)).toMatch(/balance can hold/);
    expect(topupProblem(1000, d.maxBalance - 1000, d)).toBeNull();
  });
  it("blocks top-ups when credits are switched off", () => {
    expect(topupProblem(500, 0, { ...d, enabled: false })).not.toBeNull();
  });
});

describe("paying with credits", () => {
  it("needs the balance to cover the whole total (no split payments)", () => {
    expect(canPayWithCredits(299, 300, d)).toBe(false);
    expect(canPayWithCredits(300, 300, d)).toBe(true);
  });
  it("is off when the administrator disables it", () => {
    expect(canPayWithCredits(10_000, 300, { payWithCredits: false })).toBe(false);
  });
  it("is blocked for products the administrator switched off", () => {
    const vpsOff = { ...d, disabledProducts: ["vps"] };
    expect(canPayWithCredits(10_000, 300, vpsOff, "vps")).toBe(false);
    expect(canPayWithCredits(10_000, 300, vpsOff, "minecraft")).toBe(true);
  });
  it("keeps old saved settings working (no product list means every product allowed)", () => {
    const parsed = creditsSettingsSchema.parse({ enabled: true, payWithCredits: true, minTopup: 100, maxTopup: 25_000, maxBalance: 100_000, presets: [500] });
    expect(parsed.disabledProducts).toEqual([]);
    expect(canPayWithCredits(500, 300, parsed, "bot")).toBe(true);
  });
  it("never pays a zero or fractional total", () => {
    expect(canPayWithCredits(10_000, 0, d)).toBe(false);
    expect(canPayWithCredits(10_000, 10.5, d)).toBe(false);
  });
  it("shows customer-safe messages for database errors", () => {
    expect(creditsErrorMessage("ERROR: credits_insufficient")).toMatch(/too low/);
    expect(creditsErrorMessage("some internal detail")).not.toMatch(/internal/);
  });
});

describe("credit settings", () => {
  it("defaults are valid", () => {
    expect(creditsSettingsSchema.safeParse(d).success).toBe(true);
  });
  it("rejects a minimum above the maximum and quick amounts outside the limits", () => {
    expect(creditsSettingsSchema.safeParse({ ...d, minTopup: 30_000 }).success).toBe(false);
    expect(creditsSettingsSchema.safeParse({ ...d, presets: [50] }).success).toBe(false);
  });
});
