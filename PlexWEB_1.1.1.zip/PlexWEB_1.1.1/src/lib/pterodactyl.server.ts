import type { DeployValues } from "@/config/plans";
// Server-only Pterodactyl Application API client. Never import from client code.
import { normalizePanelSettings, type PanelSettings } from "@/config/settings";
import { buildEggEnvironment, cryptoRandom, extraPortVariables, parsePortRanges, pickAllocations, portAllowed, withAdminEnv, type FreeAllocation } from "@/config/egg-env";
import type { GameOptions } from "@/config/game-options";

/** Panel actions that raise an admin alert when they fail. */
export type PanelAction = "provision" | "upgrade_resize" | "renewal_unsuspend" | "suspend" | "reserve_ports" | "delete";

export interface PanelErrorInfo {
  /** Code shown to the customer: the panel's HTTP status, 504 timeout, 503 not configured, otherwise 500. */
  code?: number;
  /** HTTP status the panel actually returned, if it answered. */
  httpStatus?: number | null;
  /** Panel error code, e.g. "ValidationException". */
  panelCode?: string | null;
  /** Panel error detail or our own description. Scrubbed before it is stored. */
  detail?: string | null;
  /** Scrubbed panel response body. The request body is never kept. */
  raw?: string | null;
  /** Overrides the alert action (e.g. port reservation failures). */
  action?: PanelAction;
}

/**
 * A failed panel call. `message` is only the harmless customer line ("Error occurred. 500.");
 * everything technical stays on the other fields and is only ever shown to administrators.
 */
export class PanelError extends Error {
  readonly code: number;
  readonly httpStatus: number | null;
  readonly panelCode: string | null;
  readonly detail: string | null;
  readonly raw: string | null;
  readonly action: PanelAction | undefined;
  constructor(info: PanelErrorInfo | string) {
    const i: PanelErrorInfo = typeof info === "string" ? { detail: info } : info;
    const code = i.code ?? customerCode(i.httpStatus ?? null);
    super(`Error occurred. ${code}.`);
    this.name = "PanelError";
    this.code = code;
    this.httpStatus = i.httpStatus ?? null;
    this.panelCode = i.panelCode ? scrubPanelText(i.panelCode).slice(0, 120) : null;
    this.detail = i.detail ? scrubPanelText(i.detail).slice(0, 1000) : null;
    this.raw = i.raw ? scrubPanelText(i.raw).slice(0, 4000) : null;
    this.action = i.action;
  }
}

/** Panel HTTP status → code shown to the customer. Auth failures are never exposed as 401/403. */
export function customerCode(httpStatus: number | null): number {
  if (!httpStatus) return 500;
  if (httpStatus === 401 || httpStatus === 403) return 500;
  if (httpStatus < 400 || httpStatus > 599) return 500;
  return httpStatus;
}

const SECRET_VARS = "RCON_PASSWORD|RCON_PASS|SERVER_PASSWORD|STEAM_GSLT|STEAM_ACC|GSLT|PASSWORD|password|api_key|apiKey|token|secret";

/**
 * Removes RCON / server passwords, Steam tokens, bearer tokens and panel API keys from text
 * before it is stored. `extra` lists exact values known to be secret for this request.
 */
export function scrubPanelText(text: string, extra: readonly (string | undefined | null)[] = []): string {
  let out = text;
  for (const v of extra) if (v && v.length >= 4) out = out.split(v).join("[redacted]");
  return out
    .replace(/Bearer\s+[A-Za-z0-9._~+/=-]+/gi, "Bearer [redacted]")
    .replace(/ptl[acr]_[A-Za-z0-9]+/g, "[redacted]")
    .replace(new RegExp(`("(?:${SECRET_VARS})"\\s*:\\s*)"(?:[^"\\\\]|\\\\.)*"`, "g"), '$1"[redacted]"')
    .replace(new RegExp(`\\b(${SECRET_VARS})(\\s*[=:]\\s*)[^\\s,;"'&]+`, "g"), "$1$2[redacted]")
    .replace(/\b[A-F0-9]{32}\b/g, "[redacted]");
}

function panelEnv() {
  const url = process.env["PTERODACTYL_URL"]?.trim().replace(/\/+$/, "");
  const key = process.env["PTERODACTYL_API_KEY"]?.trim();
  if (!url || !key) throw new PanelError({ code: 503, detail: "Game panel is not connected (address or API key missing)." });
  if (!url.startsWith("https://")) throw new PanelError({ code: 503, detail: "Game panel address must start with https://" });
  return { url, key };
}

export function panelConfigured() {
  return Boolean(process.env["PTERODACTYL_URL"] && process.env["PTERODACTYL_API_KEY"]);
}

type Json = Record<string, any>; // eslint-disable-line @typescript-eslint/no-explicit-any
type PanelResponse = { status: number; json: Json | null; text: string };

async function ptero(path: string, init: { method?: string; body?: unknown } = {}): Promise<PanelResponse> {
  const { url, key } = panelEnv();
  let res: Response;
  try {
    res = await fetch(`${url}${path}`, {
      method: init.method ?? "GET",
      headers: { authorization: `Bearer ${key}`, accept: "application/json", "content-type": "application/json" },
      ...(init.body !== undefined ? { body: JSON.stringify(init.body) } : {}),
      signal: AbortSignal.timeout(20_000),
    });
  } catch (e) {
    const timedOut = e instanceof Error && (e.name === "TimeoutError" || e.name === "AbortError");
    throw new PanelError({ code: timedOut ? 504 : 500, detail: timedOut ? `Panel timed out on ${init.method ?? "GET"} ${path.split("?")[0]}` : `Panel unreachable: ${e instanceof Error ? e.message : String(e)}` });
  }
  const text = await res.text();
  let json: Json | null = null;
  try { json = text ? (JSON.parse(text) as Json) : null; } catch { json = null; }
  return { status: res.status, json, text };
}

/** Builds a PanelError from a non-2xx panel reply (fields: errors[0].code / status / detail). */
export function panelFailure(r: PanelResponse, action?: PanelAction): PanelError {
  const first = (r.json?.["errors"] as Json[] | undefined)?.[0];
  return new PanelError({
    httpStatus: r.status,
    panelCode: typeof first?.["code"] === "string" ? first["code"] : null,
    detail: typeof first?.["detail"] === "string" ? first["detail"] : `Panel replied ${r.status}`,
    raw: r.text,
    ...(action ? { action } : {}),
  });
}

async function pteroOk(path: string, init: { method?: string; body?: unknown } = {}) {
  const r = await ptero(path, init);
  if (r.status >= 200 && r.status < 300) return r.json ?? {};
  throw panelFailure(r);
}

export async function testPanel() {
  const j = await pteroOk("/api/application/locations?per_page=50");
  return ((j["data"] as Json[]) ?? []).map((l) => ({ id: Number(l["attributes"]["id"]), name: String(l["attributes"]["short"] ?? l["attributes"]["long"] ?? "") }));
}

export async function listEggs() {
  const nests = await pteroOk("/api/application/nests?per_page=100");
  const out: { nestId: number; nest: string; eggId: number; egg: string }[] = [];
  for (const n of (nests["data"] as Json[]) ?? []) {
    const nestId = Number(n["attributes"]["id"]);
    const eggs = await pteroOk(`/api/application/nests/${nestId}/eggs?per_page=100`);
    for (const e of (eggs["data"] as Json[]) ?? []) out.push({ nestId, nest: String(n["attributes"]["name"]), eggId: Number(e["attributes"]["id"]), egg: String(e["attributes"]["name"]) });
  }
  return out;
}

async function findOrCreateUser(email: string, name: string, userId: string) {
  const found = await pteroOk(`/api/application/users?filter[email]=${encodeURIComponent(email)}`);
  const results = found["data"] as Json[] | undefined;
  const existing = results?.find((item) => {
    const attributes = item["attributes"] as Record<string, unknown> | undefined;
    return typeof attributes?.["email"] === "string" && attributes["email"].toLowerCase() === email.toLowerCase();
  });
  if (existing) return Number(existing["attributes"]["id"]);
  const base = (email.split("@")[0] ?? "user").toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 16) || "user";
  const random = crypto.getRandomValues(new Uint32Array(1))[0] ?? 0;
  const suffix = random.toString(36).slice(0, 4);
  const first = name.trim().split(/\s+/)[0]?.slice(0, 40) || "PlexScale";
  const created = await pteroOk("/api/application/users", {
    method: "POST",
    body: { email, username: `${base}_${suffix}`, first_name: first, last_name: "Customer", external_id: userId },
  });
  return Number(created["attributes"]["id"]);
}

export interface ProvisionInput {
  orderId: string;
  userId: string;
  email: string;
  name: string;
  product: string;
  software: string;
  version: string;
  location: string;
  serverName: string;
  description: string;
  cpuPercent: number;
  ramMb: number;
  diskMb: number;
  deploy?: DeployValues;
  game?: GameOptions;
}

/** Highest allocation page read per node (500 per page). */
const MAX_ALLOCATION_PAGES = 100;
/** Port reservation attempts before giving up and alerting an admin. */
export const RESERVE_ATTEMPTS = 3;

/**
 * Finds a node in the panel location with room for this server and enough free ports on one IP,
 * using a fresh allocation list. Returns null when nothing fits.
 */
async function reserveAllocations(locationId: number, extra: number, memoryMb: number, diskMb: number, ranges: { from: number; to: number }[]) {
  const nodes = ((await pteroOk("/api/application/nodes?per_page=100"))["data"] as Json[] | undefined) ?? [];
  const candidates: { id: number; freeMemory: number }[] = [];
  for (const n of nodes) {
    const a = n["attributes"] as Json;
    if (Number(a["location_id"]) !== locationId || a["maintenance_mode"]) continue;
    const full = (await pteroOk(`/api/application/nodes/${Number(a["id"])}`))["attributes"] as Json;
    const used = full["allocated_resources"] as Json | undefined;
    if (!used) {
      console.warn(JSON.stringify({ level: "warn", event: "panel.node.no_allocated_resources", node: Number(a["id"]) }));
      continue;
    }
    const cap = (total: unknown, over: unknown) => (Number(over) < 0 ? Infinity : Number(total) * (1 + Number(over || 0) / 100));
    const freeMemory = cap(full["memory"], full["memory_overallocate"]) - Number(used["memory"] ?? 0);
    const freeDisk = cap(full["disk"], full["disk_overallocate"]) - Number(used["disk"] ?? 0);
    if (freeMemory >= memoryMb && freeDisk >= diskMb) candidates.push({ id: Number(a["id"]), freeMemory });
  }
  candidates.sort((x, y) => y.freeMemory - x.freeMemory);
  for (const node of candidates) {
    const free: FreeAllocation[] = [];
    for (let page = 1; page <= MAX_ALLOCATION_PAGES; page++) {
      const j = await pteroOk(`/api/application/nodes/${node.id}/allocations?per_page=500&page=${page}`);
      for (const r of (j["data"] as Json[] | undefined) ?? []) {
        const a = r["attributes"] as Json;
        const port = Number(a["port"]);
        if (!a["assigned"] && portAllowed(port, ranges)) free.push({ id: Number(a["id"]), ip: String(a["ip"]), port });
      }
      const pg = j["meta"]?.["pagination"] as Json | undefined;
      if (!pg || Number(pg["current_page"]) >= Number(pg["total_pages"])) break;
    }
    const picked = pickAllocations(free, extra);
    if (picked) return picked;
  }
  return null;
}

async function findExisting(orderId: string): Promise<{ id: number; identifier: string } | null> {
  const prior = await ptero(`/api/application/servers/external/${encodeURIComponent(orderId)}`);
  if (prior.status === 200 && prior.json?.["attributes"]) return { id: Number(prior.json["attributes"]["id"]), identifier: String(prior.json["attributes"]["identifier"]) };
  return null;
}

/** The panel refused the server because this order's external id is already used. */
function isDuplicateExternalId(e: unknown) {
  return e instanceof PanelError && e.httpStatus === 422 && /external[\s_]?id/i.test(`${e.detail ?? ""} ${e.raw ?? ""}`);
}

/** Allocation taken or invalid: worth retrying with a fresh list. */
function isAllocationConflict(e: unknown) {
  return e instanceof PanelError && e.httpStatus !== null && [400, 409, 422].includes(e.httpStatus);
}

/** Values of secret startup variables (passwords, Steam token) so they can be removed from stored errors. */
export function secretValues(env: Record<string, string> | undefined): string[] {
  return Object.entries(env ?? {}).filter(([k]) => new RegExp(`^(${SECRET_VARS})$`, "i").test(k) || /PASS|TOKEN|GSLT|SECRET/i.test(k)).map(([, v]) => v).filter((v) => v.length >= 4);
}

function withSecretsRemoved(e: unknown, secrets: string[]): unknown {
  if (!(e instanceof PanelError) || secrets.length === 0) return e;
  return new PanelError({
    code: e.code, httpStatus: e.httpStatus, panelCode: e.panelCode,
    detail: e.detail ? scrubPanelText(e.detail, secrets) : null,
    raw: e.raw ? scrubPanelText(e.raw, secrets) : null,
    ...(e.action ? { action: e.action } : {}),
  });
}

export async function createServer(input: ProvisionInput, rawPanel: unknown): Promise<{ id: number; identifier: string }> {
  const panel: PanelSettings = normalizePanelSettings(rawPanel);
  const d = input.deploy ?? {};
  const egg = panel.eggs[`${input.product}:${input.software}`];
  if (!egg) throw new PanelError({ code: 500, detail: `No panel egg is set for ${input.product} / ${input.software}. Add it in Administrator → Panel.` });
  const locationId = panel.locations[input.location];
  if (!locationId) throw new PanelError({ code: 500, detail: `No panel location is set for ${input.location}. Add it in Administrator → Panel.` });

  // Idempotent: the order id is the server's external id, so retries never create duplicates.
  const prior = await findExisting(input.orderId);
  if (prior) return prior;

  const user = await findOrCreateUser(input.email, input.name, input.userId);
  const eggData = await pteroOk(`/api/application/nests/${egg.nestId}/eggs/${egg.eggId}?include=variables`);
  const attrs = eggData["attributes"] as Json;
  const defaults: Record<string, string> = {};
  for (const v of (attrs["relationships"]?.["variables"]?.["data"] as Json[]) ?? []) {
    defaults[String(v["attributes"]["env_variable"])] = String(v["attributes"]["default_value"] ?? "");
  }
  if (egg.versionVariable && egg.versionVariable in defaults && input.version) defaults[egg.versionVariable] = input.version;

  // Games that need more than one port (CS2 SourceTV, Rust RCON / Rust+ / query, Hytale query) get them reserved by variable name.
  const portVars = extraPortVariables(input.product, withAdminEnv(defaults, egg.env));
  const extra = portVars.length;
  const ranges = parsePortRanges(panel.portRanges[input.product]);
  const environment = (ports: number[]) => buildEggEnvironment(defaults, {
    product: input.product, serverName: input.serverName, description: input.description, ramMb: input.ramMb,
    options: input.game ?? {}, ports, adminEnv: egg.env, random: cryptoRandom(),
  });
  const baseAllocations = d.allocations ?? 1 + panel.extraAllocations;
  const common = {
    external_id: input.orderId,
    name: input.serverName,
    description: input.description,
    user,
    egg: egg.eggId,
    docker_image: egg.dockerImage || attrs["docker_image"],
    startup: attrs["startup"],
    limits: { memory: input.ramMb, swap: d.swapMib ?? 0, disk: input.diskMb, io: d.io ?? panel.io, cpu: input.cpuPercent, ...(d.threads ? { threads: d.threads } : {}) },
    feature_limits: { databases: d.databases ?? panel.databases, backups: d.backups ?? panel.backups, allocations: Math.max(baseAllocations, 1 + extra) },
    start_on_completion: true,
  };

  const post = async (body: Record<string, unknown>) => {
    try {
      const server = await pteroOk("/api/application/servers", { method: "POST", body });
      return { id: Number(server["attributes"]["id"]), identifier: String(server["attributes"]["identifier"]) };
    } catch (e) {
      if (isDuplicateExternalId(e)) {
        const existing = await findExisting(input.orderId);
        if (existing) return existing;
      }
      throw withSecretsRemoved(e, secretValues(body["environment"] as Record<string, string>));
    }
  };

  // Minecraft and bots: the panel places the server itself, optionally inside the product's port pool.
  if (extra === 0) {
    return post({ ...common, environment: environment([]), deploy: { locations: [locationId], dedicated_ip: false, port_range: panel.portRanges[input.product] ?? [] } });
  }

  // Extra ports are required: never fall back to panel placement (it would give default ports and no extra allocations).
  let lastError: unknown = null;
  for (let attempt = 1; attempt <= RESERVE_ATTEMPTS; attempt++) {
    if (attempt > 1) {
      const existing = await findExisting(input.orderId);
      if (existing) return existing;
    }
    const reserved = await reserveAllocations(locationId, extra, input.ramMb, input.diskMb, ranges);
    if (!reserved) { lastError = null; continue; }
    try {
      return await post({
        ...common,
        environment: environment(reserved.additional.map((a) => a.port)),
        allocation: { default: reserved.primary.id, additional: reserved.additional.map((a) => a.id) },
      });
    } catch (e) {
      if (!isAllocationConflict(e)) throw e;
      lastError = e;
    }
  }
  const last = lastError instanceof PanelError ? lastError : null;
  throw new PanelError({
    action: "reserve_ports",
    code: last?.code ?? 503,
    httpStatus: last?.httpStatus ?? null,
    panelCode: last?.panelCode ?? null,
    detail: `Could not reserve ${extra} extra port(s) (${portVars.join(", ")}) after ${RESERVE_ATTEMPTS} attempts${last?.detail ? `: ${last.detail}` : ": no node in this location has enough free ports on one IP"}`,
    raw: last?.raw ?? null,
  });
}

export async function setSuspended(serverId: number, suspended: boolean) {
  await pteroOk(`/api/application/servers/${serverId}/${suspended ? "suspend" : "unsuspend"}`, { method: "POST" });
}

/** Permanently deletes a server and its files. A server that is already gone counts as deleted. */
export async function deleteServer(serverId: number) {
  const r = await ptero(`/api/application/servers/${serverId}`, { method: "DELETE" });
  if ((r.status >= 200 && r.status < 300) || r.status === 404) return;
  throw panelFailure(r, "delete");
}

/** Resizes an existing server. Resources only ever grow here; current extras are kept. */
export async function updateServerBuild(serverId: number, target: { cpu: number; memoryMib: number; diskMib: number; deploy?: DeployValues }, rawPanel: unknown) {
  const panel: PanelSettings = normalizePanelSettings(rawPanel);
  const cur = await pteroOk(`/api/application/servers/${serverId}`);
  const a = cur["attributes"] as Json;
  const limits = (a["limits"] ?? {}) as Json;
  const features = (a["feature_limits"] ?? {}) as Json;
  const d = target.deploy ?? {};
  const max = (x: unknown, y: unknown) => Math.max(Number(x) || 0, Number(y) || 0);
  await pteroOk(`/api/application/servers/${serverId}/build`, {
    method: "PATCH",
    body: {
      allocation: Number(a["allocation"]),
      memory: max(limits["memory"], target.memoryMib),
      swap: d.swapMib ?? Number(limits["swap"] ?? 0),
      disk: max(limits["disk"], target.diskMib),
      io: d.io ?? Number(limits["io"] ?? panel.io),
      cpu: max(limits["cpu"], target.cpu),
      threads: d.threads ?? (limits["threads"] ?? null),
      feature_limits: {
        databases: max(features["databases"], d.databases ?? panel.databases),
        allocations: max(features["allocations"], d.allocations ?? 1 + panel.extraAllocations),
        backups: max(features["backups"], d.backups ?? panel.backups),
      },
    },
  });
}

/** Sets a new password on the customer's panel user (matched by billing email, created if missing). */
export async function resetUserPassword(email: string, name: string, userId: string, password: string) {
  const id = await findOrCreateUser(email, name, userId);
  const cur = await pteroOk(`/api/application/users/${id}`);
  const a = cur["attributes"] as Json;
  try {
    await pteroOk(`/api/application/users/${id}`, { method: "PATCH", body: { email: a["email"], username: a["username"], first_name: a["first_name"], last_name: a["last_name"], language: a["language"] ?? "en", password } });
  } catch (e) {
    throw withSecretsRemoved(e, [password]);
  }
}
