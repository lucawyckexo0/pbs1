import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { queryOptions } from "@tanstack/react-query";
import type { Database } from "@/integrations/supabase/types";
import { defaultSiteSettings, normalizeSiteSettings } from "@/config/settings";

/** Public, read-only: site links, banner, status and plan changes. */
export const getPublicSettings = createServerFn({ method: "GET" }).handler(async () => {
  try {
    const url = process.env["SUPABASE_URL"];
    const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
    if (!url || !key) return defaultSiteSettings;
    const client = createClient<Database>(url, key, {
      auth: { persistSession: false, autoRefreshToken: false },
      global: {
        fetch: (input, init) => {
          const h = new Headers(init?.headers);
          if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) h.delete("Authorization");
          h.set("apikey", key);
          return fetch(input, { ...init, headers: h });
        },
      },
    });
    const { data } = await client.from("site_settings").select("data").eq("id", 1).maybeSingle();
    return normalizeSiteSettings(data?.data);
  } catch (e) {
    console.error("Settings load failed", e);
    return defaultSiteSettings;
  }
});

export const settingsQuery = queryOptions({
  queryKey: ["site-settings"],
  queryFn: async () => {
    try { return await getPublicSettings(); } catch { return defaultSiteSettings; }
  },
  staleTime: 60_000,
});
