import { PublicError } from "@/lib/public-error";
import type { DeployValues } from "@/config/plans";
import { pickGameOptions, type GameOptionsInput } from "@/config/game-options";
// Server-only billing, payment and provisioning logic. Never import from client code.
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { addMonthsClamped, isBilling, periodMonths } from "@/config/plans";
import { normalizeSiteSettings, type SiteSettings } from "@/config/settings";
import { createServer, deleteServer, panelConfigured, PanelError, setSuspended, updateServerBuild } from "./pterodactyl.server";
import { reportPanelFailure, resolvePanelAlerts } from "./panel-errors.server";
import { notifyPayment } from "./notify.server";
import { logEvent } from "./log";
import { DELETE_AFTER_EXPIRY_DAYS, DELETE_AFTER_REFUND_HOURS } from "@/config/order-rules";
import { runDeletePass, type DeleteCandidate } from "./server-lifecycle";
import { normalizePanelSettings } from "@/config/settings";
import { createMachine, deleteAccount, deleteMachine, findOrCreateAccount, plexusConfigured, plexusMachineName, setMachineSuspended } from "./plexus.server";

export function razorpayKeys() {
  const keyId = process.env["RAZORPAY_KEY_ID"]?.trim();
  const keySecret = process.env["RAZORPAY_KEY_SECRET"]?.trim();
  if (!keyId || !keySecret) throw new PublicError("Online payments are not set up yet. Please contact support.");
  return { keyId, keySecret };
}

export const razorpayConfigured = () => Boolean(process.env["RAZORPAY_KEY_ID"] && process.env["RAZORPAY_KEY_SECRET"]);
export const razorpayWebhookConfigured = () => Boolean(process.env["RAZORPAY_WEBHOOK_SECRET"]);

export async function rzp(path: string, init: { method?: string; body?: unknown } = {}) {
  const { keyId, keySecret } = razorpayKeys();
  const res = await fetch(`https://api.razorpay.com/v1${path}`, {
    method: init.method ?? "GET",
    headers: { "content-type": "application/json", authorization: `Basic ${btoa(`${keyId}:${keySecret}`)}` },
    ...(init.body !== undefined ? { body: JSON.stringify(init.body) } : {}),
    signal: AbortSignal.timeout(15_000),
  });
  if (!res.ok) {
    console.error("Razorpay error", res.status, (await res.text()).slice(0, 300));
    throw new PublicError("The payment provider did not respond. Please try again.");
  }
  return (await res.json()) as Record<string, unknown>;
}

export { hmacHexPure as hmacHex, safeEqualPure as safeEqual } from "./crypto-utils";

export type CheckoutStart = { orderId: string; razorpayOrderId: string; keyId: string; amount: number; paidWithCredits: false } | { orderId: string; razorpayOrderId: null; keyId: null; amount: number; paidWithCredits: true };

/**
 * Takes payment for a freshly created pending order: from the customer's credits when asked, otherwise by
 * opening a Razorpay order for the exact server-side amount. A failed start closes the order so it never lingers.
 */
export async function startOrderPayment(order: { id: string; amount: number }, opts: { useCredits: boolean; notes?: Record<string, string> }): Promise<CheckoutStart> {
  if (opts.useCredits) {
    const settings = await loadSiteSettings();
    if (!settings.credits.payWithCredits) { await closeUnpaid(order.id); throw new PublicError("Paying with credits is not available right now."); }
    // The product is read from the stored order, so a browser cannot dodge a per-product block.
    const { creditsAllowedFor } = await import("@/config/credits");
    const { data: row } = await supabaseAdmin.from("orders").select("product, kind").eq("id", order.id).maybeSingle();
    if (!row || row.kind === "credits" || !creditsAllowedFor(row.product, settings.credits)) { await closeUnpaid(order.id); throw new PublicError("Credits can't be used for this service. Please pay with Razorpay."); }
    await payWithCredits(order.id);
    return { orderId: order.id, razorpayOrderId: null, keyId: null, amount: order.amount, paidWithCredits: true };
  }
  const { keyId } = razorpayKeys();
  let r: Record<string, unknown>;
  try {
    r = await rzp("/orders", { method: "POST", body: { amount: order.amount * 100, currency: "INR", receipt: order.id.slice(0, 40), notes: { order_id: order.id, ...(opts.notes ?? {}) } } });
  } catch (e) {
    await closeUnpaid(order.id);
    throw e;
  }
  const razorpayOrderId = String(r["id"] ?? "");
  if (!/^order_[A-Za-z0-9]{6,40}$/.test(razorpayOrderId) || Number(r["amount"]) !== order.amount * 100) {
    await closeUnpaid(order.id);
    logEvent("error", "razorpay.order_mismatch", { orderId: order.id });
    throw new PublicError("The payment provider returned an unexpected answer. Nothing was charged.");
  }
  const { error } = await supabaseAdmin.from("orders").update({ razorpay_order_id: razorpayOrderId }).eq("id", order.id).eq("status", "pending").is("razorpay_order_id", null);
  if (error) { logEvent("error", "checkout.order_update_failed", { orderId: order.id }); throw new PublicError("Checkout could not be prepared."); }
  return { orderId: order.id, razorpayOrderId, keyId, amount: order.amount, paidWithCredits: false };
}

/** Closes an order nobody paid. Never touches an order whose credits were already taken; reconcile completes those. */
async function closeUnpaid(orderId: string) {
  await supabaseAdmin.from("orders").update({ status: "failed" }).eq("id", orderId).eq("status", "pending").eq("paid_with", "razorpay").is("razorpay_payment_id", null);
}

/** Pays a pending order from the balance (one locked database call), then completes it like any paid order. */
export async function payWithCredits(orderId: string) {
  const { creditsErrorMessage } = await import("@/config/credits");
  const { data: tx, error } = await supabaseAdmin.rpc("spend_credits", { _order_id: orderId });
  if (error || !tx) {
    await closeUnpaid(orderId);
    throw new PublicError(creditsErrorMessage(error?.message));
  }
  logEvent("info", "credits.spend", { orderId });
  // The ledger row is the payment reference. If completing fails here, the hourly reconcile job finishes it.
  try {
    await markPaid(orderId, `credits_${tx}`);
  } catch (e) {
    logEvent("error", "credits.complete_deferred", { orderId, message: e instanceof Error ? e.message : String(e) });
  }
}

/** Finishes credit-paid orders whose completion was interrupted after the balance was taken. */
export async function completeInterruptedCreditPayments(olderThanMs = 5 * 60_000) {
  const { data: rows } = await supabaseAdmin.from("orders").select("id")
    .eq("status", "pending").eq("paid_with", "credits").is("razorpay_payment_id", null)
    .lt("created_at", new Date(Date.now() - olderThanMs).toISOString()).limit(50);
  let done = 0;
  for (const o of rows ?? []) {
    const { data: tx } = await supabaseAdmin.from("credit_transactions").select("id").eq("order_id", o.id).eq("kind", "spend").maybeSingle();
    if (!tx) continue;
    try { await markPaid(o.id, `credits_${tx.id}`); done++; } catch (e) { logEvent("error", "credits.complete_failed", { orderId: o.id, message: e instanceof Error ? e.message : String(e) }); }
  }
  return done;
}

export async function loadSiteSettings(): Promise<SiteSettings> {
  const { data } = await supabaseAdmin.from("site_settings").select("data").eq("id", 1).maybeSingle();
  return normalizeSiteSettings(data?.data);
}

export async function loadPanelSettings(): Promise<unknown> {
  const { data } = await supabaseAdmin.from("panel_settings").select("data").eq("id", 1).maybeSingle();
  return data?.data ?? {};
}

/** Blocks customer actions while maintenance mode is on. Administrators are never locked out. */
export async function assertNotMaintenance(userId: string) {
  const s = await loadSiteSettings();
  if (!s.maintenance.enabled) return;
  const { data } = await supabaseAdmin.rpc("has_role", { _user_id: userId, _role: "admin" });
  if (data === true) return;
  throw new PublicError("PlexScale is under maintenance. Please try again shortly.");
}

export async function audit(actorId: string | null, action: string, target: string | null, details: Record<string, unknown> = {}) {
  await supabaseAdmin.from("audit_log").insert({ actor_id: actorId, action, target, details: details as never });
}

/** Records an administrator action with the caller's IP. The database keeps the newest 100. */
export async function adminAudit(actorId: string, action: string, target: string | null, details: Record<string, unknown> = {}) {
  const { clientIp } = await import("@/lib/client-ip.server");
  await supabaseAdmin.from("audit_log").insert({ actor_id: actorId, action, target, details: details as never, scope: "admin", ip: clientIp() });
}

/** Confirms with Razorpay that the payment really belongs to this order and amount, capturing it if needed. */
export async function confirmRazorpayPayment(paymentId: string, razorpayOrderId: string, amountRupees: number) {
  if (!/^pay_[A-Za-z0-9]{6,40}$/.test(paymentId)) throw new PublicError("Payment could not be verified.");
  const p = await rzp(`/payments/${paymentId}`);
  if (p["order_id"] !== razorpayOrderId || Number(p["amount"]) !== amountRupees * 100 || p["currency"] !== "INR") throw new PublicError("Payment could not be verified.");
  if (p["status"] === "authorized") {
    await rzp(`/payments/${paymentId}/capture`, { method: "POST", body: { amount: amountRupees * 100, currency: "INR" } });
  } else if (p["status"] !== "captured") {
    throw new PublicError("Payment has not completed yet.");
  }
}

/** Marks an order paid exactly once, then sets up, renews or upgrades the service and emails the invoice. Safe to call from both the browser callback and the webhook. */
export async function markPaid(orderId: string, paymentId: string) {
  await markPaidInner(orderId, paymentId);
  const { data } = await supabaseAdmin.from("orders").select("razorpay_payment_id").eq("id", orderId).maybeSingle();
  if (data?.razorpay_payment_id === paymentId) await notifyPayment(orderId);
}

async function markPaidInner(orderId: string, paymentId: string) {
  const { data: order } = await supabaseAdmin.from("orders").select("*").eq("id", orderId).maybeSingle();
  if (!order) return;
  if (order.kind === "credits") {
    // Claims the order and adds the balance in one database transaction, so replays never add credits twice.
    const { data: balance, error } = await supabaseAdmin.rpc("credit_topup", { _order_id: orderId, _payment_id: paymentId });
    if (error) throw new PublicError("Credit top-up could not be recorded.");
    if (balance === -1) logEvent("warn", "credits.topup_review", { orderId });
    else if (balance !== null) logEvent("info", "credits.topup", { orderId, amount: order.amount });
    return;
  }
  if (!isBilling(order.billing)) return;
  const now = new Date();
  const months = periodMonths(order.billing);

  if (order.kind === "upgrade") {
    const { data: claimed, error } = await supabaseAdmin.from("orders").update({ status: "upgraded", razorpay_payment_id: paymentId, paid_at: now.toISOString() })
      .eq("id", orderId).in("status", ["pending", "failed"]).is("razorpay_payment_id", null).select("id").maybeSingle();
    if (error) throw new PublicError("Upgrade payment could not be recorded.");
    if (claimed) await applyUpgrade(orderId);
    return;
  }

  if (order.kind === "new") {
    const renews = addMonthsClamped(now, months);
    if (order.status === "failed" && !order.razorpay_payment_id) {
      // Late payment for a closed checkout: the database re-checks any coupon before reviving it.
      const { data: result, error } = await supabaseAdmin.rpc("revive_paid_order", { _order_id: orderId, _payment_id: paymentId, _renews_at: renews.toISOString() });
      if (error) throw new PublicError("Payment could not be recorded.");
      if (result === "revived") await provisionOrder(orderId);
      else if (result === "review") logEvent("warn", "payment.late_review", { orderId });
      return;
    }
    const { data: updated, error } = await supabaseAdmin.from("orders")
      .update({ status: "provisioning", razorpay_payment_id: paymentId, paid_at: now.toISOString(), renews_at: renews.toISOString() })
      .eq("id", orderId).eq("status", "pending").is("razorpay_payment_id", null).select("id").maybeSingle();
    if (error) throw new PublicError("Payment could not be recorded.");
    if (updated) await provisionOrder(orderId);
    return;
  }

  if (order.kind !== "renewal") return;
  // One locked database step records the payment and extends the service, so it can never apply twice
  // or at an old plan's price.
  const { data: result, error } = await supabaseAdmin.rpc("apply_renewal", { _order_id: orderId, _payment_id: paymentId });
  if (error) { logEvent("error", "renewal.apply_failed", { orderId }); throw new PublicError("Renewal payment could not be recorded."); }
  if (result === "review") { logEvent("warn", "renewal.review", { orderId }); return; }
  if (result === "extended_suspended" && order.parent_order_id) {
    const { data: parent } = await supabaseAdmin.from("orders").select("id, user_id, product, ptero_server_id, plexus_machine_id").eq("id", order.parent_order_id).maybeSingle();
    if (parent) await resumeService(parent.id, parent.ptero_server_id, parent.user_id, parent.product, parent.plexus_machine_id);
  }
}

/** Unsuspends a renewed service. A panel failure raises an admin alert; the renewal itself stays paid. */
async function resumeService(parentId: string, serverId: number | null, userId: string, product: string, machineId: string | null = null) {
  if (product === "vps" && machineId) {
    try {
      await setMachineSuspended(machineId, false);
      await supabaseAdmin.from("orders").update({ status: "active" }).eq("id", parentId).eq("status", "suspended");
      await resolvePanelAlerts(parentId, ["renewal_unsuspend"]);
    } catch (e) {
      await reportPanelFailure(e, { action: "renewal_unsuspend", orderId: parentId, userId, product });
    }
    return;
  }
  if (!serverId) {
    await supabaseAdmin.from("orders").update({ status: "active" }).eq("id", parentId).eq("status", "suspended");
    return;
  }
  try {
    await setSuspended(serverId, false);
    await supabaseAdmin.from("orders").update({ status: "active" }).eq("id", parentId).eq("status", "suspended");
    await resolvePanelAlerts(parentId, ["renewal_unsuspend"]);
  } catch (e) {
    await reportPanelFailure(e, { action: "renewal_unsuspend", orderId: parentId, userId, product });
  }
}

/** Creates the server on the game panel. Errors are stored on the order so an admin can fix and retry. */
export async function provisionOrder(orderId: string): Promise<{ ok: boolean; message: string }> {
  const { data: order } = await supabaseAdmin.from("orders").select("*").eq("id", orderId).maybeSingle();
  if (!order) return { ok: false, message: "Order not found." };
  if (order.kind !== "new" || order.status !== "provisioning") return { ok: false, message: "Order is not waiting for setup." };
  if (order.ptero_server_id) {
    await supabaseAdmin.from("orders").update({ status: "active", provision_error: null }).eq("id", orderId);
    return { ok: true, message: "Already set up." };
  }
  if (order.product === "vps") return provisionVps(order);
  const fail = async (e: unknown) => {
    const line = await reportPanelFailure(e, { action: "provision", orderId, userId: order.user_id, product: order.product });
    // Only while still provisioning: a losing concurrent attempt must never mark an active order as failed.
    await supabaseAdmin.from("orders").update({ provision_error: line, provision_attempts: (order.provision_attempts ?? 0) + 1 }).eq("id", orderId).eq("status", "provisioning");
    logEvent("error", "provision.failed", { orderId, attempt: (order.provision_attempts ?? 0) + 1 });
    return { ok: false, message: line };
  };
  if (!panelConfigured()) return fail(new PanelError({ code: 503, detail: "Game panel is not connected (address or API key missing)." }));
  try {
    const { data: u } = await supabaseAdmin.auth.admin.getUserById(order.user_id);
    const email = u.user?.email;
    if (!email) throw new PanelError({ code: 500, detail: "Customer has no email address." });
    const { data: profile } = await supabaseAdmin.from("profiles").select("display_name").eq("id", order.user_id).maybeSingle();
    const server = await createServer({
      orderId: order.id,
      userId: order.user_id,
      email,
      name: profile?.display_name ?? "",
      product: order.product,
      software: order.software ?? "default",
      version: order.version ?? "latest",
      location: order.location,
      serverName: order.server_name || `${order.plan_name} ${order.id.slice(0, 6)}`,
      description: order.description,
      cpuPercent: order.cpu_percent ?? 100,
      ramMb: order.ram_mb ?? 1024,
      diskMb: order.disk_mb ?? 10240,
      deploy: ((order.config as Record<string, unknown> | null)?.["deploy"] ?? {}) as DeployValues,
      game: pickGameOptions(order.product, ((order.config as Record<string, unknown> | null)?.["game"] ?? {}) as GameOptionsInput),
    }, await loadPanelSettings());
    await supabaseAdmin.from("orders").update({ status: "active", ptero_server_id: server.id, ptero_identifier: server.identifier, provision_error: null }).eq("id", orderId).eq("status", "provisioning");
    await resolvePanelAlerts(orderId, ["provision", "reserve_ports"]);
    logEvent("info", "provision.ok", { orderId, serverId: server.id });
    return { ok: true, message: "Server created on the panel." };
  } catch (e) {
    return fail(e);
  }
}

type OrderRow = { id: string; user_id: string; product: string; location: string; software: string | null; server_name: string; plan_name: string; cpu_percent: number | null; ram_mb: number | null; disk_mb: number | null; provision_attempts: number | null; plexus_machine_id: string | null };


/** Creates the customer's Plexus account (once) and queues the VPS. Plexus builds it in the background. */
async function provisionVps(order: OrderRow): Promise<{ ok: boolean; message: string }> {
  const fail = async (e: unknown) => {
    const line = await reportPanelFailure(e, { action: "provision", orderId: order.id, userId: order.user_id, product: "vps" });
    await supabaseAdmin.from("orders").update({ provision_error: line, provision_attempts: (order.provision_attempts ?? 0) + 1 }).eq("id", order.id).eq("status", "provisioning");
    logEvent("error", "provision.vps_failed", { orderId: order.id });
    return { ok: false, message: line };
  };
  if (order.plexus_machine_id) {
    await supabaseAdmin.from("orders").update({ status: "active", provision_error: null }).eq("id", order.id).eq("status", "provisioning");
    return { ok: true, message: "Already set up." };
  }
  if (!plexusConfigured()) return fail(new PanelError({ code: 503, detail: "VPS panel (Plexus) is not connected (PLEXUS_URL or PLEXUS_API_KEY missing)." }));
  try {
    const map = normalizePanelSettings(await loadPanelSettings()).plexus;
    const clusterId = map.clusters[order.location];
    if (!clusterId) throw new PanelError({ code: 500, detail: `No Plexus cluster is mapped for location ${order.location}. Add it in Administrator → Plexus.` });
    const imageId = map.images[order.software ?? ""];
    if (!imageId) throw new PanelError({ code: 500, detail: `No Plexus image is mapped for OS ${order.software}. Add it in Administrator → Plexus.` });
    const accountId = await ensurePlexusAccount(order.user_id);
    const machineId = await createMachine({
      ownerId: accountId, clusterId, imageId, name: plexusMachineName(order.server_name || order.plan_name, order.id),
      vcpu: Math.max(1, Math.round((order.cpu_percent ?? 100) / 100)), memoryMb: Math.max(512, order.ram_mb ?? 1024), diskGb: Math.max(5, Math.round((order.disk_mb ?? 10240) / 1024)),
    });
    await supabaseAdmin.from("orders").update({ status: "active", plexus_machine_id: machineId, provision_error: null }).eq("id", order.id).eq("status", "provisioning");
    await resolvePanelAlerts(order.id, ["provision"]);
    logEvent("info", "provision.vps_queued", { orderId: order.id, machineId });
    return { ok: true, message: "VPS queued on Plexus." };
  } catch (e) {
    return fail(e);
  }
}

/** The customer's Plexus account id, created with their billing email on first use. */
export async function ensurePlexusAccount(userId: string): Promise<number> {
  const { data: saved } = await supabaseAdmin.from("plexus_accounts").select("account_id").eq("user_id", userId).maybeSingle();
  if (saved) return saved.account_id;
  const { data: u } = await supabaseAdmin.auth.admin.getUserById(userId);
  const email = u.user?.email;
  if (!email) throw new PanelError({ code: 500, detail: "Customer has no email address." });
  const accountId = await findOrCreateAccount(email);
  await supabaseAdmin.from("plexus_accounts").upsert({ user_id: userId, account_id: accountId }, { onConflict: "user_id" });
  return accountId;
}

/** Moves the parent service to the paid-for plan, then resizes the server on the panel. Never applies twice. */
export async function applyUpgrade(orderId: string): Promise<{ ok: boolean; message: string }> {
  const { data: up } = await supabaseAdmin.from("orders").select("*").eq("id", orderId).maybeSingle();
  if (!up || up.kind !== "upgrade" || up.status !== "upgraded" || !up.parent_order_id) return { ok: false, message: "Upgrade not found." };
  const cfg = (up.config ?? {}) as Record<string, unknown>;
  const fromPlanId = String(cfg["fromPlanId"] ?? "");
  const parentRenewsAt = String(cfg["parentRenewsAt"] ?? "");
  const limits = { cpu: Number(cfg["cpu"]), memoryMib: Number(cfg["memoryMib"]), diskMib: Number(cfg["diskMib"]) };
  const deploy = (cfg["deploy"] ?? {}) as DeployValues;
  const { data: parent } = await supabaseAdmin.from("orders").select("*").eq("id", up.parent_order_id).maybeSingle();

  const review = async (why: string) => {
    await supabaseAdmin.from("orders").update({ provision_error: why.slice(0, 300) }).eq("id", up.id);
    await supabaseAdmin.from("refunds").upsert({ order_id: up.id, user_id: up.user_id, reason: `Upgrade needs administrator review: ${why}`.slice(0, 500), status: "requested" }, { onConflict: "order_id" });
    await audit(null, "order.upgrade.review", up.id, { why });
    return { ok: false, message: "Upgrade needs administrator review." };
  };

  if (!parent || parent.user_id !== up.user_id || !["active", "suspended"].includes(parent.status)) return review("Service is no longer active.");
  if (parent.plan_id === up.plan_id && !cfg["applied"]) {
    const { data: moved } = await supabaseAdmin.from("audit_log").select("id").eq("action", "order.upgrade").eq("target", parent.id).contains("details", { upgrade: up.id }).limit(1).maybeSingle();
    if (!moved) return review("Service was already on this plan when the upgrade was paid.");
  }
  if (parent.plan_id !== up.plan_id) {
    if (parent.plan_id !== fromPlanId) return review("Service plan changed after the quote.");
    if (!parent.renews_at || Date.parse(parent.renews_at) !== Date.parse(parentRenewsAt)) return review("Service expiry changed after the quote.");
    if (![limits.cpu, limits.memoryMib, limits.diskMib].every((n) => Number.isFinite(n) && n > 0)) return review("Upgrade details are incomplete.");
    const parentConfig = (parent.config ?? {}) as Record<string, unknown>;
    const { data: moved, error } = await supabaseAdmin.from("orders").update({
      plan_id: up.plan_id, plan_name: up.plan_name, cpu_percent: limits.cpu, ram_mb: limits.memoryMib, disk_mb: limits.diskMib,
      config: { ...parentConfig, deploy: JSON.parse(JSON.stringify(deploy)) } as never,
    }).eq("id", parent.id).eq("plan_id", fromPlanId).eq("renews_at", parent.renews_at).in("status", ["active", "suspended"]).select("id").maybeSingle();
    if (error || !moved) return review("Service could not be moved to the new plan.");
    await supabaseAdmin.from("orders").update({ config: { ...cfg, applied: true } as never }).eq("id", up.id);
    await audit(up.user_id, "order.upgrade", parent.id, { from: fromPlanId, to: up.plan_id, upgrade: up.id });
  }
  const resizeFailed = async (e: unknown) => {
    const line = await reportPanelFailure(e, { action: "upgrade_resize", orderId: up.id, userId: up.user_id, product: up.product });
    await supabaseAdmin.from("orders").update({ provision_error: line }).eq("id", up.id);
    return { ok: false, message: "Plan updated, but the server resize needs a retry." };
  };
  if (!parent.ptero_server_id) {
    await supabaseAdmin.from("orders").update({ provision_error: null }).eq("id", up.id);
    return { ok: true, message: "Plan updated." };
  }
  if (!panelConfigured()) return resizeFailed(new PanelError({ code: 503, detail: "Game panel is not connected (address or API key missing)." }));
  try {
    await updateServerBuild(parent.ptero_server_id, { cpu: limits.cpu, memoryMib: limits.memoryMib, diskMib: limits.diskMib, deploy }, await loadPanelSettings());
    await supabaseAdmin.from("orders").update({ provision_error: null }).eq("id", up.id);
    await resolvePanelAlerts(up.id, ["upgrade_resize"]);
    return { ok: true, message: "Plan updated and server resized." };
  } catch (e) {
    return resizeFailed(e);
  }
}

/** Lifts a panel suspension without changing the order; used when a renewal races the expiry job. */
export async function resumeOnPanel(order: { id: string; ptero_server_id: number | null; user_id: string; product: string; plexus_machine_id?: string | null }) {
  try {
    if (order.product === "vps") { if (order.plexus_machine_id && plexusConfigured()) await setMachineSuspended(order.plexus_machine_id, false); }
    else if (order.ptero_server_id && panelConfigured()) await setSuspended(order.ptero_server_id, false);
  } catch (e) {
    await reportPanelFailure(e, { action: "renewal_unsuspend", orderId: order.id, userId: order.user_id, product: order.product });
  }
}

/** Suspends a service on the panel; a failure raises an admin alert. Returns false when the panel refused. */
export async function suspendOnPanel(order: { id: string; ptero_server_id: number | null; user_id: string; product: string; plexus_machine_id?: string | null }): Promise<boolean> {
  if (order.product === "vps") {
    if (!order.plexus_machine_id || !plexusConfigured()) return true;
    try {
      await setMachineSuspended(order.plexus_machine_id, true);
      await resolvePanelAlerts(order.id, ["suspend"]);
      return true;
    } catch (e) {
      await reportPanelFailure(e, { action: "suspend", orderId: order.id, userId: order.user_id, product: order.product });
      return false;
    }
  }
  if (!order.ptero_server_id || !panelConfigured()) return true;
  try {
    await setSuspended(order.ptero_server_id, true);
    await resolvePanelAlerts(order.id, ["suspend"]);
    return true;
  } catch (e) {
    await reportPanelFailure(e, { action: "suspend", orderId: order.id, userId: order.user_id, product: order.product });
    return false;
  }
}

const deleteDeps = (reason: "expired" | "refunded") => ({
  deleteServer: async (serverId: number) => {
    if (!panelConfigured()) throw new PanelError({ code: 503, detail: "Game panel is not connected (address or API key missing)." });
    await deleteServer(serverId);
  },
  deleteMachine: async (machineId: string) => {
    if (!plexusConfigured()) throw new PanelError({ code: 503, detail: "VPS panel (Plexus) is not connected (PLEXUS_URL or PLEXUS_API_KEY missing)." });
    await deleteMachine(machineId);
  },
  alert: async (c: DeleteCandidate, e: unknown) => { await reportPanelFailure(e, { action: "delete", orderId: c.id, userId: c.user_id, product: c.product }); },
  finish: async (c: DeleteCandidate) => {
    await supabaseAdmin.from("orders").update({ ptero_server_id: null, ptero_identifier: null, plexus_machine_id: null, server_deleted_at: new Date().toISOString() }).eq("id", c.id);
    await resolvePanelAlerts(c.id, ["delete"]);
    await audit(null, "order.server_deleted", c.id, { reason, ptero_server_id: c.ptero_server_id, plexus_machine_id: c.plexus_machine_id ?? null });
  },
});

/**
 * Day-7 cleanup: services still suspended 7 days after expiry are claimed (suspended → cancelled),
 * then deleted on the panel. A failed delete reverts the claim and raises an alert; the next daily run retries.
 */
export async function deleteExpiredServices(now = Date.now()) {
  const cutoff = new Date(now - DELETE_AFTER_EXPIRY_DAYS * 864e5).toISOString();
  return runDeletePass({
    ...deleteDeps("expired"),
    listDue: async () => (await supabaseAdmin.from("orders").select("id, user_id, product, ptero_server_id, plexus_machine_id").eq("kind", "new").eq("status", "suspended").lt("renews_at", cutoff).limit(100)).data ?? [],
    claim: async (c) => Boolean((await supabaseAdmin.from("orders").update({ status: "cancelled" }).eq("id", c.id).eq("status", "suspended").lt("renews_at", cutoff).select("id").maybeSingle()).data),
    revert: async (c) => { await supabaseAdmin.from("orders").update({ status: "suspended" }).eq("id", c.id).eq("status", "cancelled"); },
  });
}

/** Refunded services lose their server 24 hours after the refund. The claim clears the server id first. */
export async function deleteRefundedServices(now = Date.now()) {
  const cutoff = new Date(now - DELETE_AFTER_REFUND_HOURS * 3600_000).toISOString();
  return runDeletePass({
    ...deleteDeps("refunded"),
    listDue: async () => (await supabaseAdmin.from("orders").select("id, user_id, product, ptero_server_id, plexus_machine_id").eq("status", "refunded").or("ptero_server_id.not.is.null,plexus_machine_id.not.is.null").lt("refunded_at", cutoff).limit(100)).data ?? [],
    claim: async (c) => {
      let q = supabaseAdmin.from("orders").update({ ptero_server_id: null, plexus_machine_id: null }).eq("id", c.id).eq("status", "refunded");
      q = c.ptero_server_id ? q.eq("ptero_server_id", c.ptero_server_id) : q.eq("plexus_machine_id", c.plexus_machine_id!);
      return Boolean((await q.select("id").maybeSingle()).data);
    },
    revert: async (c) => { await supabaseAdmin.from("orders").update({ ptero_server_id: c.ptero_server_id, plexus_machine_id: c.plexus_machine_id ?? null }).eq("id", c.id); },
  });
}

/**
 * Removes Plexus accounts whose customer has no VPS left. Machine deletion is queued, so Plexus answers 409
 * while machines are still being removed; the account is then kept and the next daily run retries.
 */
export async function deleteOrphanPlexusAccounts() {
  let deleted = 0, waiting = 0, failed = 0;
  if (!plexusConfigured()) return { deleted, waiting, failed };
  const { data: accounts } = await supabaseAdmin.from("plexus_accounts").select("user_id, account_id").limit(200);
  for (const a of accounts ?? []) {
    const { count } = await supabaseAdmin.from("orders").select("id", { count: "exact", head: true }).eq("user_id", a.user_id).eq("product", "vps").eq("kind", "new")
      .or("status.in.(pending,provisioning,active,suspended),plexus_machine_id.not.is.null");
    if ((count ?? 0) > 0) continue;
    try {
      if ((await deleteAccount(a.account_id)) === "retry") { waiting++; continue; }
      await supabaseAdmin.from("plexus_accounts").delete().eq("user_id", a.user_id).eq("account_id", a.account_id);
      await audit(null, "plexus.account_deleted", a.user_id, { account_id: a.account_id });
      deleted++;
    } catch (e) {
      await reportPanelFailure(e, { action: "delete", userId: a.user_id, product: "vps" });
      failed++;
    }
  }
  return { deleted, waiting, failed };
}
