import { PublicError } from "@/lib/public-error";
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { assertAdmin } from "@/lib/admin-guard";

/**
 * Administrator → Invoices: every paid order (game servers, VPS, bot hosting, renewals, upgrades and credit top-ups)
 * with its invoice number. Read through the admin's own token, so row level security still applies.
 */
export const adminListInvoices = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    const [orders, invoices] = await Promise.all([
      context.supabase.from("orders").select("id, user_id, kind, product, plan_name, billing, amount, status, paid_at, server_name, paid_with, razorpay_payment_id, discount")
        .not("paid_at", "is", null).not("razorpay_payment_id", "is", null).order("paid_at", { ascending: false }).limit(2000),
      context.supabase.from("invoices").select("order_id, number, issued_at").order("issued_at", { ascending: false }).limit(2000),
    ]);
    const rows = orders.data ?? [];
    const ids = [...new Set(rows.map((o) => o.user_id))];
    const { data: profiles } = ids.length ? await context.supabase.from("profiles").select("id, email, display_name, billing_name").in("id", ids.slice(0, 1000)) : { data: [] };
    const numbers = new Map((invoices.data ?? []).map((i) => [i.order_id, `PX-${i.number}`]));
    const people = new Map((profiles ?? []).map((p) => [p.id, p]));
    return rows.map((o) => {
      const p = people.get(o.user_id);
      return {
        orderId: o.id,
        number: numbers.get(o.id) ?? null,
        paidAt: o.paid_at as string,
        kind: o.kind,
        product: o.product,
        planName: o.plan_name,
        billing: o.billing,
        serverName: o.server_name,
        amount: o.amount,
        discount: o.discount,
        status: o.status,
        paidWith: o.paid_with === "credits" ? ("credits" as const) : ("razorpay" as const),
        paymentRef: o.paid_with === "credits" ? null : o.razorpay_payment_id,
        customerEmail: p?.email ?? "",
        customerName: p?.billing_name || p?.display_name || "",
      };
    });
  });

/** Administrator download of any invoice as a PDF (base64). Creates the invoice record first if it is missing. */
export const adminInvoicePdf = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: { orderId: string }) => ({ orderId: z.string().uuid().parse(d.orderId) }))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { assertRateLimit } = await import("@/lib/rate-limit.server");
    await assertRateLimit("invoice_admin", { userId: context.userId, perUser: 200, windowSeconds: 600, message: "Too many downloads. Please wait a few minutes." });
    const { ensureInvoice } = await import("@/lib/notify.server");
    const { renderInvoicePdf } = await import("@/lib/invoice.server");
    const inv = await ensureInvoice(data.orderId);
    if (!inv) throw new PublicError("Invoice not available.");
    const pdf = await renderInvoicePdf(inv.data);
    let bin = "";
    for (let i = 0; i < pdf.length; i += 0x8000) bin += String.fromCharCode(...pdf.subarray(i, i + 0x8000));
    return { filename: `PlexScale-Invoice-${inv.number}.pdf`, number: inv.number, base64: btoa(bin) };
  });
