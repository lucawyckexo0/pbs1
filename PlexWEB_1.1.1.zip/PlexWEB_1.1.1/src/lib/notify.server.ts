import { logEvent } from "./log";
// Server-only: transactional emails (SMTP), invoices and Discord ticket alerts.
// Every send is best effort: a failed email never blocks a payment, signup or ticket.
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { normalizeEmailSettings, renderHtml, renderSubject, renderText, type EmailSettings, type TemplateKey } from "@/config/email";
import { billingLabel, formatINR, productNames, type ProductKey } from "@/config/plans";
import { site } from "@/config/site";
import { openSecret } from "./secret-box.server";
import { isSafeEmail, sendSmtp, type MailAttachment } from "./smtp.server";
import { smtpFromEnv } from "./smtp-env";
import { renderInvoicePdf, type InvoiceData } from "./invoice.server";

export interface EmailConfig { settings: EmailSettings; smtpPassword: string | null; discordWebhook: string | null; raw: Record<string, unknown> }

export async function loadEmailConfig(): Promise<EmailConfig> {
  const { data } = await supabaseAdmin.from("email_settings").select("data").eq("id", 1).maybeSingle();
  const raw = (data?.data && typeof data.data === "object" ? data.data : {}) as Record<string, unknown>;
  const [smtpPassword, discordWebhook] = await Promise.all([openSecret(raw["smtpPasswordEnc"]), openSecret(raw["discordWebhookEnc"])]);
  const cfg: EmailConfig = { settings: normalizeEmailSettings(raw), smtpPassword, discordWebhook, raw };
  if (smtpReady(cfg)) return cfg;
  // Not configured in Administrator yet: fall back to the server SMTP set during installation.
  const env = smtpFromEnv(process.env);
  if (!env) return cfg;
  const { password, ...smtp } = env;
  return { ...cfg, settings: { ...cfg.settings, smtp: { ...cfg.settings.smtp, ...smtp, enabled: true, replyTo: cfg.settings.smtp.replyTo } }, smtpPassword: password || null };
}

export function smtpReady(c: EmailConfig) {
  const s = c.settings.smtp;
  return s.enabled && Boolean(s.host && s.port && s.fromEmail) && (!s.username || Boolean(c.smtpPassword));
}

const dateIN = (iso: string | null | undefined) => (iso ? new Date(iso).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric", timeZone: "Asia/Kolkata" }) : "-");
// Links in emails point at this installation (SITE_URL), falling back to the brand site.
const siteUrl = () => (/^https:\/\/[a-z0-9.-]+$/i.test(process.env["SITE_URL"] ?? "") ? process.env["SITE_URL"]! : site.url);
const link = (path: string) => `${siteUrl()}${path}`;
const baseVars = () => ({ site_url: siteUrl(), support_url: link("/support"), billing_url: link("/billing") });

/** Claims a one-time send. Returns the event id, or null when it already went out (or is in flight). */
async function claim(dedupeKey: string, kind: string, recipient: string, userId: string | null, orderId: string | null) {
  const { data } = await supabaseAdmin.from("email_events").upsert({ dedupe_key: dedupeKey, kind, recipient, user_id: userId, order_id: orderId, status: "queued" }, { onConflict: "dedupe_key", ignoreDuplicates: true }).select("id");
  if (data && data.length) return data[0]!.id;
  // Earlier attempt failed: allow a retry after a short cool-down.
  const { data: retry } = await supabaseAdmin.from("email_events").update({ status: "queued", error: null }).eq("dedupe_key", dedupeKey).eq("status", "failed").lt("updated_at", new Date(Date.now() - 10 * 60_000).toISOString()).select("id").maybeSingle();
  return retry?.id ?? null;
}

/** Sends one templated email. With a dedupeKey the email goes out at most once. */
export async function sendTemplate(key: TemplateKey, to: string | null | undefined, vars: Record<string, string>, opts: { dedupeKey?: string; userId?: string | null; orderId?: string | null; attachments?: MailAttachment[]; config?: EmailConfig } = {}): Promise<"sent" | "skipped" | "failed"> {
  try {
    const cfg = opts.config ?? (await loadEmailConfig());
    const tpl = cfg.settings.templates[key];
    const recipient = (to ?? "").trim().toLowerCase();
    if (!tpl.enabled || !smtpReady(cfg) || !isSafeEmail(recipient)) return "skipped";
    let eventId: string | null = null;
    if (opts.dedupeKey) {
      eventId = await claim(opts.dedupeKey, key, recipient, opts.userId ?? null, opts.orderId ?? null);
      if (!eventId) return "skipped";
    }
    const all = { ...baseVars(), ...vars };
    const subject = renderSubject(tpl.subject, all);
    try {
      await sendSmtp(
        { host: cfg.settings.smtp.host, port: cfg.settings.smtp.port, security: cfg.settings.smtp.security, username: cfg.settings.smtp.username, password: cfg.smtpPassword ?? "" },
        { fromName: cfg.settings.smtp.fromName || site.name, fromEmail: cfg.settings.smtp.fromEmail, to: recipient, replyTo: cfg.settings.smtp.replyTo || undefined, subject, text: renderText(tpl.body, all), html: renderHtml(tpl.body, all, { preheader: subject, siteUrl: siteUrl() }), attachments: opts.attachments },
      );
      if (eventId) await supabaseAdmin.from("email_events").update({ status: "sent" }).eq("id", eventId);
      return "sent";
    } catch (e) {
      const raw = e instanceof Error ? e.message : "";
      const reason = smtpFailureReason(raw);
      logEvent("error", "email.send_failed", { key, detail: raw.slice(0, 300) });
      if (eventId) await supabaseAdmin.from("email_events").update({ status: "failed", error: reason }).eq("id", eventId);
      else await supabaseAdmin.from("email_events").insert({ dedupe_key: `adhoc:${crypto.randomUUID()}`, kind: key, recipient, user_id: opts.userId ?? null, order_id: opts.orderId ?? null, status: "failed", error: reason });
      return "failed";
    }
  } catch (e) {
    logEvent("error", "email.pipeline_failed", { key, detail: e instanceof Error ? e.message.slice(0, 300) : "unknown" });
    return "failed";
  }
}

async function customer(userId: string) {
  const [{ data: profile }, { data: u }] = await Promise.all([
    supabaseAdmin.from("profiles").select("email, display_name, billing_name, billing_phone, billing_address, gstin, created_at, welcome_sent_at").eq("id", userId).maybeSingle(),
    supabaseAdmin.auth.admin.getUserById(userId),
  ]);
  const email = (u?.user?.email ?? profile?.email ?? "").toLowerCase();
  const name = (profile?.billing_name || profile?.display_name || email.split("@")[0] || "there").slice(0, 60);
  return { email, name, profile };
}

/** Welcome email, sent once per account and only right after the account is created. */
export async function sendWelcome(userId: string) {
  const { data: claimed } = await supabaseAdmin.from("profiles").update({ welcome_sent_at: new Date().toISOString() }).eq("id", userId).is("welcome_sent_at", null).gt("created_at", new Date(Date.now() - 48 * 3600_000).toISOString()).select("id").maybeSingle();
  if (!claimed) return;
  const c = await customer(userId);
  await sendTemplate("welcome", c.email, { name: c.name, email: c.email }, { dedupeKey: `welcome:${userId}`, userId });
}

const serviceName = (o: { server_name: string | null; plan_name: string; product: string }) => o.server_name || `${productNames[o.product as ProductKey] ?? o.product} · ${o.plan_name}`;

/** Creates the invoice for a paid order once; later calls return the same invoice. */
export async function ensureInvoice(orderId: string): Promise<{ number: string; data: InvoiceData } | null> {
  const { data: existing } = await supabaseAdmin.from("invoices").select("number, data").eq("order_id", orderId).maybeSingle();
  if (existing) return { number: `PX-${existing.number}`, data: existing.data as unknown as InvoiceData };
  const { data: o } = await supabaseAdmin.from("orders").select("*").eq("id", orderId).maybeSingle();
  if (!o || !o.paid_at || !o.razorpay_payment_id) return null;
  const cfg = await loadEmailConfig();
  const c = await customer(o.user_id);
  const cfgOrder = (o.config ?? {}) as Record<string, unknown>;
  const product = productNames[o.product as ProductKey] ?? o.product;
  const paidBy = o.paid_with === "credits" ? " Paid with PlexScale Credits." : "";
  const description = o.kind === "credits" ? "PlexScale Credits top-up" : o.kind === "upgrade" ? `${product} plan upgrade: ${String(cfgOrder["fromPlanName"] ?? "")} to ${o.plan_name}` : o.kind === "renewal" ? `${product} ${o.plan_name} renewal` : `${product} ${o.plan_name}`;
  const detail = o.kind === "credits"
    ? `Prepaid account balance: ${o.amount} credits. Credits are used for PlexScale services and are non-refundable and not withdrawable.`
    : o.kind === "upgrade"
      ? `Prorated difference for the remaining period until ${dateIN(String(cfgOrder["parentRenewsAt"] ?? ""))}. Service: ${o.server_name || "-"}.${paidBy}`
      : `Billing: ${billingLabel(o.billing)}. Service: ${o.server_name || "-"}. Location: ${o.location}.${paidBy}`;
  const { data: row, error } = await supabaseAdmin.from("invoices").insert({ order_id: o.id, user_id: o.user_id, amount: o.amount, issued_at: o.paid_at, data: {} }).select("id, number").single();
  if (error || !row) {
    const { data: again } = await supabaseAdmin.from("invoices").select("number, data").eq("order_id", orderId).maybeSingle();
    return again ? { number: `PX-${again.number}`, data: again.data as unknown as InvoiceData } : null;
  }
  const inv: InvoiceData = {
    number: `PX-${row.number}`,
    issuedAt: o.paid_at,
    kind: o.kind as InvoiceData["kind"],
    seller: { name: cfg.settings.invoice.businessName || site.legalName, address: cfg.settings.invoice.address, gstin: cfg.settings.invoice.gstin, email: cfg.settings.invoice.email || cfg.settings.smtp.replyTo || "" },
    buyer: { name: c.profile?.billing_name || c.profile?.display_name || "", email: c.email, address: c.profile?.billing_address || "", phone: c.profile?.billing_phone || "", gstin: c.profile?.gstin || "" },
    items: [{ description, detail, amount: o.amount }],
    total: o.amount,
    paymentId: o.razorpay_payment_id,
    orderId: o.id,
    note: cfg.settings.invoice.note,
  };
  await supabaseAdmin.from("invoices").update({ data: inv as never }).eq("id", row.id);
  return { number: inv.number, data: inv };
}

/** Receipt email with the PDF invoice attached. Safe to call more than once per order. */
export async function notifyPayment(orderId: string) {
  try {
    const inv = await ensureInvoice(orderId);
    if (!inv) return;
    const { data: o } = await supabaseAdmin.from("orders").select("id, user_id, kind, product, plan_name, server_name, billing, amount, renews_at, parent_order_id, config").eq("id", orderId).maybeSingle();
    if (!o) return;
    let expiry = o.renews_at;
    if (o.parent_order_id) {
      const { data: parent } = await supabaseAdmin.from("orders").select("renews_at").eq("id", o.parent_order_id).maybeSingle();
      expiry = parent?.renews_at ?? expiry;
    }
    const c = await customer(o.user_id);
    const pdf = await renderInvoicePdf(inv.data);
    const attachments = [{ filename: `PlexScale-Invoice-${inv.number}.pdf`, contentType: "application/pdf", content: pdf }];
    if (o.kind === "credits") {
      const { data: w } = await supabaseAdmin.from("credit_wallets").select("balance").eq("user_id", o.user_id).maybeSingle();
      await sendTemplate("credits", c.email, { name: c.name, amount: formatINR(o.amount), balance: formatINR(w?.balance ?? o.amount), invoice_number: inv.number },
        { dedupeKey: `receipt:${orderId}`, userId: o.user_id, orderId, attachments });
      return;
    }
    const key: TemplateKey = o.kind === "renewal" ? "renewal" : o.kind === "upgrade" ? "upgrade" : "purchase";
    await sendTemplate(key, c.email, {
      name: c.name, service_name: serviceName(o), plan_name: o.plan_name, previous_plan: String((o.config as Record<string, unknown> | null)?.["fromPlanName"] ?? ""),
      amount: formatINR(o.amount), billing: billingLabel(o.billing), invoice_number: inv.number, expiry_date: dateIN(expiry),
    }, { dedupeKey: `receipt:${orderId}`, userId: o.user_id, orderId, attachments });
  } catch (e) {
    console.error("Payment notification failed", orderId, e);
  }
}

/** Expiry reminders 7 days and 1 day before a service expires. Each goes out once per paid period. */
export async function sendExpiryReminders() {
  const cfg = await loadEmailConfig();
  if (!smtpReady(cfg)) return { sent: 0 };
  const now = Date.now();
  const { data: due } = await supabaseAdmin.from("orders").select("id, user_id, product, plan_name, server_name, amount, renews_at, status")
    .eq("kind", "new").in("status", ["active"]).gt("renews_at", new Date(now).toISOString()).lte("renews_at", new Date(now + 7 * 864e5).toISOString()).limit(500);
  let sent = 0;
  for (const o of due ?? []) {
    if (!o.renews_at) continue;
    const msLeft = Date.parse(o.renews_at) - now;
    const key: TemplateKey = msLeft <= 864e5 ? "expiry1" : "expiry7";
    const c = await customer(o.user_id);
    const r = await sendTemplate(key, c.email, {
      name: c.name, service_name: serviceName(o), plan_name: o.plan_name, expiry_date: dateIN(o.renews_at), days_left: String(Math.max(1, Math.ceil(msLeft / 864e5))), amount: formatINR(o.amount),
    }, { dedupeKey: `${key}:${o.id}:${o.renews_at.slice(0, 10)}`, userId: o.user_id, orderId: o.id, config: cfg });
    if (r === "sent") sent++;
  }
  return { sent };
}

// ---------- Discord ----------

const clip = (s: string, n: number) => (s.length > n ? `${s.slice(0, n - 1)}…` : s);

export async function postDiscord(webhook: string, body: Record<string, unknown>) {
  if (!/^https:\/\/(?:canary\.|ptb\.)?discord(?:app)?\.com\/api\/webhooks\/\d+\/[A-Za-z0-9_-]+$/.test(webhook)) throw new Error("Invalid Discord webhook.");
  const res = await fetch(`${webhook}?wait=true`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body), signal: AbortSignal.timeout(10_000) });
  if (!res.ok) throw new Error("Discord did not accept the alert.");
}

export type TicketEvent = "created" | "customer_reply" | "staff_reply";

/** Ticket notifications: customer email, staff email and Discord, depending on the event. */
export async function notifyTicket(event: TicketEvent, ticketId: string, message: string) {
  try {
    const cfg = await loadEmailConfig();
    const { data: t } = await supabaseAdmin.from("support_tickets").select("id, number, user_id, subject, category, priority, status").eq("id", ticketId).maybeSingle();
    if (!t) return;
    const c = await customer(t.user_id);
    const excerpt = clip(message.replace(/\s+/g, " ").trim(), 600);
    const vars = { name: c.name, customer_email: c.email, ticket_number: String(t.number), ticket_subject: t.subject, ticket_category: t.category, ticket_priority: t.priority, reply_excerpt: excerpt, ticket_url: link(`/support/${t.id}`), admin_url: link("/administrator") };
    const jobs: Promise<unknown>[] = [];
    if (event === "created") jobs.push(sendTemplate("ticketCreated", c.email, vars, { userId: t.user_id, config: cfg }));
    if (event === "staff_reply") jobs.push(sendTemplate("ticketReply", c.email, vars, { userId: t.user_id, config: cfg }));
    if (event !== "staff_reply" && cfg.settings.staffEmail) jobs.push(sendTemplate("staffTicketAlert", cfg.settings.staffEmail, vars, { config: cfg }));
    const d = cfg.settings.discord;
    if (cfg.discordWebhook && d.enabled && ((event === "created" && d.notifyNewTickets) || (event === "customer_reply" && d.notifyReplies))) {
      const color = t.priority === "urgent" ? 0xef4444 : t.priority === "high" ? 0xf59e0b : 0x4d8dff;
      jobs.push(postDiscord(cfg.discordWebhook, {
        username: "PlexScale Support",
        content: d.roleId ? `<@&${d.roleId}>` : undefined,
        allowed_mentions: { parse: [], roles: d.roleId ? [d.roleId] : [] },
        embeds: [{
          title: clip(`${event === "created" ? "New ticket" : "Customer reply"} #${t.number}: ${t.subject}`, 250),
          url: link("/administrator"),
          description: clip(excerpt, 1000),
          color,
          fields: [
            { name: "Category", value: t.category, inline: true },
            { name: "Priority", value: t.priority, inline: true },
            { name: "Customer", value: clip(c.email || "Unknown", 100), inline: true },
          ],
          timestamp: new Date().toISOString(),
        }],
      }).catch((e) => console.error("Discord alert failed", e instanceof Error ? e.message : e)));
    }
    await Promise.allSettled(jobs);
  } catch (e) {
    console.error("Ticket notification failed", ticketId, e);
  }
}

/** A short, safe reason for a failed send. The raw server reply only goes to the logs. */
export function smtpFailureReason(raw: string): string {
  const m = raw.toLowerCase();
  if (/auth|535|534|530|credential|password|username/.test(m)) return "The mail server did not accept the username or password.";
  if (/certificate|tls|ssl|handshake|self.signed/.test(m)) return "A secure connection to the mail server could not be made.";
  if (/timeout|timed out|econnrefused|enotfound|connect|network|socket|dns/.test(m)) return "The mail server could not be reached.";
  if (/550|551|553|554|recipient|sender|relay|mailbox/.test(m)) return "The mail server refused the sender or recipient address.";
  return "Sending failed. Check the SMTP settings.";
}
