// Server SMTP settings read from /etc/plexscale/plexscale.env.
// They are used only while SMTP is not configured in Administrator -> SMTP & emails, so the site can send
// mail from the first minute; settings saved in Administrator always win.
const HOST_RE = /^(?=.{1,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)(\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+$/;
const EMAIL_RE = /^[A-Za-z0-9._%+-]{1,64}@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,24}$/;

export interface EnvSmtp {
  host: string;
  port: number;
  security: "starttls" | "tls";
  username: string;
  password: string;
  fromName: string;
  fromEmail: string;
}

/** Parses SMTP_* variables. Returns null when they are absent or invalid (never a half-working config). */
export function smtpFromEnv(env: Record<string, string | undefined>): EnvSmtp | null {
  const host = (env["SMTP_HOST"] ?? "").trim().toLowerCase();
  if (!host || !HOST_RE.test(host)) return null;
  const port = Number(env["SMTP_PORT"] ?? "587");
  if (port !== 587 && port !== 465 && port !== 2525) return null;
  const security = (env["SMTP_SECURITY"] ?? (port === 465 ? "tls" : "starttls")).trim();
  if (security !== "starttls" && security !== "tls") return null;
  const fromEmail = (env["SMTP_FROM_EMAIL"] ?? "").trim();
  if (!EMAIL_RE.test(fromEmail) || fromEmail.length > 254) return null;
  const username = (env["SMTP_USER"] ?? "").trim();
  const password = env["SMTP_PASSWORD"] ?? "";
  if (username && !password) return null;
  if (/[\r\n\0]/.test(username + password)) return null;
  const fromName = (env["SMTP_FROM_NAME"] ?? "PlexScale").replace(/[\r\n\0]/g, " ").trim().slice(0, 80) || "PlexScale";
  return { host, port, security, username, password, fromName, fromEmail };
}
