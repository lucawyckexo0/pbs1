// Server-only fixed-window rate limits stored in the database (works across stateless workers).
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { clientIp } from "./client-ip.server";
import { cloudflareIp } from "./ip";
import { logEvent } from "./log";
import { PublicError } from "./public-error";

/**
 * Counts one hit. True while under the limit. When the database cannot be reached it fails open for
 * ordinary reads, and fails closed (refuses) when `failClosed` is set, which money and auth paths use.
 */
export async function hitRateLimit(key: string, limit: number, windowSeconds: number, failClosed = false): Promise<boolean> {
  try {
    const { data, error } = await supabaseAdmin.rpc("hit_rate_limit", { _key: key.slice(0, 200), _limit: limit, _window_seconds: windowSeconds });
    if (error) throw error;
    return data === true;
  } catch {
    logEvent("warn", "rate_limit.unavailable", { key: key.split(":")[0], failClosed });
    return !failClosed;
  }
}

export class RateLimitError extends PublicError {}

/**
 * Throws a friendly error when the caller is over the limit. Checks the signed-in user (if any)
 * and the visitor's IP separately, so one shared IP does not lock out a whole office.
 */
export async function assertRateLimit(scope: string, opts: { userId?: string | null; perUser?: number; perIp?: number; windowSeconds: number; message?: string; failClosed?: boolean }) {
  const message = opts.message ?? "Too many requests. Please wait a moment and try again.";
  const closed = opts.failClosed ?? false;
  if (opts.userId && opts.perUser) {
    if (!(await hitRateLimit(`${scope}:u:${opts.userId}`, opts.perUser, opts.windowSeconds, closed))) throw new RateLimitError(message);
  }
  const ip = clientIp();
  if (ip && opts.perIp) {
    if (!(await hitRateLimit(`${scope}:ip:${ip}`, opts.perIp, opts.windowSeconds, closed))) throw new RateLimitError(message);
  }
}

/** For raw server routes: the visitor IP from Cloudflare's header only (other forwarded headers are ignored). */
export function requestIp(request: Request): string | null {
  return cloudflareIp(request.headers);
}
