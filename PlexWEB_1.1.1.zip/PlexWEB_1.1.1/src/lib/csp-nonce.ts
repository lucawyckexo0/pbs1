import { createIsomorphicFn } from "@tanstack/react-start";
import { getRequestHeader } from "@tanstack/react-start/server";

/** Header src/server.ts sets on every request (any client-sent value is overwritten). */
export const NONCE_HEADER = "x-plexscale-csp-nonce";

/** Per-request CSP nonce for SSR script tags. Browsers never need it after hydration. */
export const getCspNonce = createIsomorphicFn()
  .server(() => getRequestHeader(NONCE_HEADER) || undefined)
  .client((): string | undefined => undefined);
