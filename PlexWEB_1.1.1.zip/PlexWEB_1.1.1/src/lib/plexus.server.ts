// Server-only Plexus Virtualization Panel API client (/api/v1). Never import from client code.
// Create and delete return 202: success means "queued", not "finished".
import { PanelError, scrubPanelText } from "./pterodactyl.server";

type Json = Record<string, any>; // eslint-disable-line @typescript-eslint/no-explicit-any
type PlexusResponse = { status: number; json: Json | null; text: string; retryAfter: string | null };

function plexusEnv() {
  const url = process.env["PLEXUS_URL"]?.trim().replace(/\/+$/, "");
  const key = process.env["PLEXUS_API_KEY"]?.trim();
  if (!url || !key) throw new PanelError({ code: 503, detail: "VPS panel (Plexus) is not connected (address or API key missing)." });
  if (!url.startsWith("https://")) throw new PanelError({ code: 503, detail: "Plexus address must start with https://" });
  return { url, key };
}

export const plexusConfigured = () => Boolean(process.env["PLEXUS_URL"] && process.env["PLEXUS_API_KEY"]);

async function call(path: string, init: { method?: string; body?: unknown } = {}): Promise<PlexusResponse> {
  const { url, key } = plexusEnv();
  let res: Response;
  try {
    res = await fetch(`${url}/api/v1${path}`, {
      method: init.method ?? "GET",
      headers: { authorization: `Bearer ${key}`, accept: "application/json", "content-type": "application/json" },
      ...(init.body !== undefined ? { body: JSON.stringify(init.body) } : {}),
      signal: AbortSignal.timeout(20_000),
    });
  } catch (e) {
    const timedOut = e instanceof Error && (e.name === "TimeoutError" || e.name === "AbortError");
    throw new PanelError({ code: timedOut ? 504 : 500, detail: timedOut ? `Plexus timed out on ${init.method ?? "GET"} ${path.split("?")[0]}` : `Plexus unreachable: ${e instanceof Error ? e.message : String(e)}` });
  }
  const text = await res.text();
  let json: Json | null = null;
  try { json = text ? (JSON.parse(text) as Json) : null; } catch { json = null; }
  return { status: res.status, json, text, retryAfter: res.headers.get("retry-after") };
}

const reasons: Record<number, string> = {
  401: "Plexus rejected the API key (invalid key).",
  403: "The Plexus API key is missing a required permission (scope).",
  409: "Plexus conflict: duplicate machine name, or the machine is busy / has another operation pending.",
  422: "Plexus refused the request: a quota is reached or a value is invalid (weak password, inactive image).",
  429: "Plexus rate limit reached.",
};

/** Builds a PanelError from a Plexus error reply ({ detail }). Passwords are scrubbed. */
export function plexusFailure(r: PlexusResponse, secrets: string[] = []): PanelError {
  const d = r.json?.["detail"];
  const detail = typeof d === "string" ? d : Array.isArray(d) ? JSON.stringify(d).slice(0, 600) : null;
  const base = reasons[r.status] ?? `Plexus replied ${r.status}`;
  const extra = r.status === 429 && r.retryAfter ? ` Retry after ${r.retryAfter}s.` : "";
  return new PanelError({ httpStatus: r.status, panelCode: `plexus_${r.status}`, detail: scrubPanelText(`${base}${extra}${detail ? ` ${detail}` : ""}`, secrets), raw: scrubPanelText(r.text, secrets) });
}

async function ok(path: string, init: { method?: string; body?: unknown } = {}, secrets: string[] = []) {
  const r = await call(path, init);
  if (r.status >= 200 && r.status < 300) return r.json ?? {};
  throw plexusFailure(r, secrets);
}

export interface PlexusCatalog {
  clusters: { id: number; name: string; location: string | null; state: string; maintenance: boolean; free_ipv4: number }[];
  images: { id: number; name: string; os_family: string | null; username: string | null }[];
}

export async function plexusCatalog(): Promise<PlexusCatalog> {
  const j = await ok("/catalog");
  return { clusters: (j["clusters"] as PlexusCatalog["clusters"]) ?? [], images: (j["images"] as PlexusCatalog["images"]) ?? [] };
}

/** Finds the customer's Plexus account by email or creates it. Returns the account id. */
export async function findOrCreateAccount(email: string): Promise<number> {
  const found = await ok(`/accounts?email=${encodeURIComponent(email.toLowerCase())}`);
  const hit = ((found["accounts"] as Json[]) ?? []).find((a) => String(a["email"]).toLowerCase() === email.toLowerCase());
  if (hit) return Number(hit["id"]);
  const created = await ok("/accounts", { method: "POST", body: { email } });
  return Number(created["id"]);
}

export async function accountExists(accountId: number): Promise<boolean> {
  const r = await call(`/accounts/${accountId}`);
  if (r.status === 404) return false;
  if (r.status >= 200 && r.status < 300) return true;
  throw plexusFailure(r);
}

export interface MachineInput { ownerId: number; clusterId: number; imageId: number; name: string; vcpu: number; memoryMb: number; diskGb: number }

/** Queues a new machine (202). The password Plexus generates is ignored. */
export async function createMachine(m: MachineInput): Promise<string> {
  const j = await ok("/machines", { method: "POST", body: { owner_id: m.ownerId, cluster_id: m.clusterId, image_id: m.imageId, name: m.name, vcpu: m.vcpu, memory_mb: m.memoryMb, disk_gb: m.diskGb } });
  const id = j["id"] ?? (j["machine"] as Json | undefined)?.["id"];
  if (!id) throw new PanelError({ code: 500, detail: "Plexus accepted the machine but returned no id." });
  return String(id);
}

/** Billing suspension. Already suspended / unsuspended counts as done. */
export async function setMachineSuspended(machineId: string, suspended: boolean) {
  const r = await call(`/machines/${encodeURIComponent(machineId)}/${suspended ? "suspend" : "unsuspend"}`, { method: "POST", ...(suspended ? { body: { reason: "billing" } } : {}) });
  if (r.status >= 200 && r.status < 300) return;
  throw plexusFailure(r);
}

/** Queues machine deletion (202). A machine that is already gone counts as deleted. */
export async function deleteMachine(machineId: string) {
  const r = await call(`/machines/${encodeURIComponent(machineId)}`, { method: "DELETE" });
  if ((r.status >= 200 && r.status < 300) || r.status === 404) return;
  throw plexusFailure(r);
}

/** Deletes the account. Returns "retry" on 409 (machines still being removed) so the next daily run tries again. */
export async function deleteAccount(accountId: number): Promise<"deleted" | "retry"> {
  const r = await call(`/accounts/${accountId}`, { method: "DELETE" });
  if ((r.status >= 200 && r.status < 300) || r.status === 404) return "deleted";
  if (r.status === 409) return "retry";
  throw plexusFailure(r);
}

export async function setAccountPassword(accountId: number, password: string) {
  await ok(`/accounts/${accountId}`, { method: "PATCH", body: { password } }, [password]);
}

/** Strong password with upper, lower, digits and symbols. */
export function strongPassword(length = 20): string {
  const sets = ["ABCDEFGHJKLMNPQRSTUVWXYZ", "abcdefghijkmnopqrstuvwxyz", "23456789", "!@#%^*-_=+"];
  const all = sets.join("");
  const rnd = crypto.getRandomValues(new Uint32Array(length));
  const chars = Array.from(rnd, (n, i) => { const set = i < sets.length ? sets[i]! : all; return set[n % set.length]!; });
  for (let i = chars.length - 1; i > 0; i--) { const j = rnd[i]! % (i + 1); [chars[i], chars[j]] = [chars[j]!, chars[i]!]; }
  return chars.join("");
}

/** Plexus machine names: lowercase letters, numbers and dashes, unique per order. */
export function plexusMachineName(serverName: string, orderId: string) {
  const base = serverName.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 40) || "vps";
  return `${base}-${orderId.slice(0, 8)}`;
}
