// Server-only: encrypts stored credentials (SMTP password, Discord webhook) at rest with AES-256-GCM.
// The key never leaves the server environment; the database only ever holds ciphertext.
// Format is versioned: v2 (HKDF-SHA256 key) is written; v1 (legacy single SHA-256) stays readable.

const enc = new TextEncoder();
const dec = new TextDecoder();

function rawKey() {
  const raw = process.env["SETTINGS_ENCRYPTION_KEY"];
  if (!raw || raw.length < 32) throw new Error("Encryption is not configured.");
  return raw;
}

async function keyV1() {
  const digest = await crypto.subtle.digest("SHA-256", enc.encode(`plexscale-settings-v1:${rawKey()}`));
  return crypto.subtle.importKey("raw", digest, { name: "AES-GCM" }, false, ["encrypt", "decrypt"]);
}

async function keyV2() {
  const ikm = await crypto.subtle.importKey("raw", enc.encode(rawKey()), "HKDF", false, ["deriveKey"]);
  return crypto.subtle.deriveKey(
    { name: "HKDF", hash: "SHA-256", salt: enc.encode("plexscale-settings-salt"), info: enc.encode("plexscale-settings-v2") },
    ikm, { name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"],
  );
}

const toB64 = (b: Uint8Array) => { let s = ""; for (const x of b) s += String.fromCharCode(x); return btoa(s); };
const fromB64 = (s: string) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));

export async function sealSecret(plain: string): Promise<string> {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv }, await keyV2(), enc.encode(plain)));
  const out = new Uint8Array(iv.length + ct.length);
  out.set(iv); out.set(ct, iv.length);
  return `v2:${toB64(out)}`;
}

export async function openSecret(sealed: unknown): Promise<string | null> {
  if (typeof sealed !== "string") return null;
  const version = sealed.slice(0, 3);
  if (version !== "v1:" && version !== "v2:") return null;
  try {
    const buf = fromB64(sealed.slice(3));
    const key = version === "v2:" ? await keyV2() : await keyV1();
    const pt = await crypto.subtle.decrypt({ name: "AES-GCM", iv: buf.slice(0, 12) }, key, buf.slice(12));
    return dec.decode(pt);
  } catch {
    console.error("Stored credential could not be decrypted.");
    return null;
  }
}
