// Build config: TanStack Start (SSR + server functions), React, Tailwind and path aliases.
// The output is a plain Node build: dist/client (static files) and dist/server/server.js (a fetch
// handler) which server/index.mjs serves on 127.0.0.1.
import { defineConfig, type Plugin } from "vite";
import { tanstackStart } from "@tanstack/react-start/plugin/vite";
import viteReact from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

// Scrambles browser bundles in production builds. Server code is left readable for logs.
function obfuscateClient(): Plugin {
  return {
    name: "px-obfuscate-client",
    apply: "build",
    enforce: "post",
    applyToEnvironment: (env) => env.name === "client",
    async renderChunk(code, chunk) {
      if (!chunk.fileName.endsWith(".js")) return null;
      const { default: JavaScriptObfuscator } = await import("javascript-obfuscator");
      const out = JavaScriptObfuscator.obfuscate(code, {
        compact: true,
        target: "browser",
        identifierNamesGenerator: "mangled-shuffled",
        renameGlobals: false,
        stringArray: true,
        stringArrayThreshold: 0.6,
        stringArrayEncoding: ["base64"],
        stringArrayRotate: true,
        stringArrayShuffle: true,
        splitStrings: false,
        controlFlowFlattening: false,
        deadCodeInjection: false,
        selfDefending: false,
        debugProtection: false,
        disableConsoleOutput: false,
        transformObjectKeys: false,
        unicodeEscapeSequence: false,
        sourceMap: false,
        ignoreImports: true,
      });
      return { code: out.getObfuscatedCode(), map: null };
    },
  };
}

export default defineConfig({
  // "@/..." imports resolve from tsconfig.json paths.
  resolve: { tsconfigPaths: true },
  server: { host: "127.0.0.1", port: 3000, strictPort: true },
  preview: { host: "127.0.0.1", port: 3000, strictPort: true },
  plugins: [
    tailwindcss(),
    // src/server.ts wraps every response with security headers. Server functions live under /_px.
    tanstackStart({ server: { entry: "server" }, serverFns: { base: "/_px" } }),
    viteReact(),
    obfuscateClient(),
  ],
  // Bundle every dependency into the server build so production never resolves packages at runtime.
  ssr: { noExternal: true },
  build: { sourcemap: false },
  environments: {
    // Browser files get opaque hashed names; the server build keeps its default entry (dist/server/server.js).
    client: {
      build: {
        rollupOptions: {
          output: {
            entryFileNames: "assets/[hash].js",
            chunkFileNames: "assets/[hash].js",
            assetFileNames: "assets/[hash][extname]",
          },
        },
      },
    },
  },
});
