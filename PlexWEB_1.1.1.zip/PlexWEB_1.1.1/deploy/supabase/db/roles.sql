-- Runs once, when the database volume is first created (docker-entrypoint-initdb.d).
-- Each service gets its own password; roles PlexScale does not use cannot log in.
\set authenticator_pass `echo "$AUTHENTICATOR_PASSWORD"`
\set auth_admin_pass `echo "$AUTH_ADMIN_PASSWORD"`
\set pgpass `echo "$POSTGRES_PASSWORD"`

ALTER USER authenticator WITH PASSWORD :'authenticator_pass';
ALTER USER supabase_auth_admin WITH PASSWORD :'auth_admin_pass';
ALTER USER postgres WITH PASSWORD :'pgpass';

-- Not used by PlexScale (no pooler, edge functions or storage service in this stack).
ALTER ROLE pgbouncer NOLOGIN;
ALTER ROLE supabase_functions_admin NOLOGIN;
ALTER ROLE supabase_storage_admin NOLOGIN;
