# Manual setup reference

PlexScale Web has no installer. The unit files and compose file in `deploy/` expect this layout:

| Path | What it is |
|---|---|
| `/opt/plexscale/current` | The unpacked release (run `pnpm install --frozen-lockfile && pnpm build` here). |
| `/opt/plexscale/runtime/node/bin/node` | Node.js 26 (see `engines` in `package.json`). Change `ExecStart` in the units if yours is elsewhere. |
| `/etc/plexscale/plexscale.env` | Website settings; copy from `.env.example`. Mode 600, owned by root. |
| `/etc/plexscale/jobs.env` | Only `CRON_SECRET=...` (same value as in `plexscale.env`). |
| `/etc/plexscale/supabase.env` | Database stack settings (list below). |
| `/etc/plexscale/cloudflared.env` | `TUNNEL_TOKEN=...` |
| `/var/lib/plexscale/supabase` | A copy of `deploy/supabase/` (compose file, `kong.yml`, `kong-entrypoint.sh`, `db/`). |
| `plexscale` system user | Runs the website and the job units. |

## Database stack (`supabase.env`)
`POSTGRES_PASSWORD`, `AUTHENTICATOR_PASSWORD`, `AUTH_ADMIN_PASSWORD`, `JWT_SECRET` (40+ letters and digits),
`ANON_KEY`, `SERVICE_ROLE_KEY`, `API_EXTERNAL_URL` (`https://api.<domain>`), `SITE_URL`,
`GOOGLE_CLIENT_ID`, `GOOGLE_SECRET`, `DISCORD_CLIENT_ID`, `DISCORD_SECRET`, optional `JWT_EXPIRY` (default 3600).

Create the two API keys from the JWT secret: `printf '%s' "$JWT_SECRET" | node deploy/bin/gen-keys.mjs`.

## Order of work
1. Start the database stack (`plexscale-supabase.service`).
2. Apply migrations: `DATABASE_URL=... pnpm migrate` (`--status` and `--dry-run` are available).
3. Build and start `plexscale-web.service`, then `plexscale-cloudflared.service` (see CLOUDFLARE.md).
4. Enable the job timers: `plexscale-job-expire-services.timer` and `plexscale-job-reconcile-payments.timer`.

Migrations are add-only; never edit one that has already been applied.
