# Cloudflare tunnel

PlexScale uses a remotely managed tunnel: the token is stored in `/etc/plexscale/cloudflared.env` (root only, `TUNNEL_TOKEN=...`) and
`plexscale-cloudflared.service` runs `cloudflared tunnel run` as a throw-away system user with no access to
PlexScale files. Auto-update is off, so update cloudflared yourself when Cloudflare publishes a new release.

## Public hostnames
Zero Trust -> Networks -> Tunnels -> your tunnel -> Public hostname -> Add:

| Subdomain / domain | Type | URL |
|---|---|---|
| `<domain>` | HTTP | `127.0.0.1:3000` |
| `api.<domain>` | HTTP | `127.0.0.1:8000` |

Do not add a hostname for the database (54322) or anything else. The scheduled-job socket is not a TCP port and
cannot be published.

## Recommended Cloudflare settings
- SSL/TLS: Full; Always Use HTTPS on; minimum TLS 1.2; HSTS is sent by the site.
- WAF: enable the managed rules; add a rate-limiting rule for `/_px/*` and `api.<domain>/auth/v1/*`.
- Turnstile: one widget for `<domain>`, Managed mode.
- The site trusts only the `CF-Connecting-IP` header for visitor addresses. Because the tunnel is the only way in,
  that header is always set by Cloudflare.
