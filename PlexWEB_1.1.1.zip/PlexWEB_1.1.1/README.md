# PlexScale Web 1.1.1

Self-hosted storefront and billing system for PlexScale game servers, VPS and bot hosting.

- Customer area: orders, renewals, upgrades, invoices, PlexScale Credits and support tickets.
- Payments through Razorpay, servers through Pterodactyl and Plexus.
- Sign-in with Google or Discord.
- Administrator: orders, refunds, plans, coupons, credits, invoices, emails, panel settings and alerts.

## Install

Needs Node.js 26 and pnpm 12.18.0.

```bash
pnpm install --frozen-lockfile
nano .env            # fill in the values
pnpm build
pnpm migrate         # applies database migrations
pnpm start           # 127.0.0.1:3000
```

Production runs under systemd behind a Cloudflare tunnel: see [deploy/docs/SETUP.md](deploy/docs/SETUP.md).

## Develop

```bash
pnpm install --frozen-lockfile
pnpm dev
```

| Command | What it does |
|---|---|
| `pnpm dev` | Development server on 127.0.0.1:3000 |
| `pnpm build` | Production build (`dist/`) |
| `pnpm start` | Production server (`server/index.mjs`) |
| `pnpm test` | Test suite, including money rules and migrations against a real Postgres engine |
| `pnpm lint` / `pnpm typecheck` | Lint / type check |
| `pnpm audit:high` | Fails on any high or critical advisory |
| `pnpm migrate` | Apply pending migrations to `DATABASE_URL` (`--status`, `--dry-run`) |

What changed in this release: [CHANGELOG.md](CHANGELOG.md). Security notes: [SECURITY.md](SECURITY.md).
